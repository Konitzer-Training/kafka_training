# Kafka-Lab – Generali, 02.–03.11.2026 (Apache Kafka 4.4)

Ein Kafka-Cluster mit drei Knoten plus Monitoring, komplett in Docker. Für Tag 2 kommt ein zweiter Standort (DR) mit MirrorMaker 2 dazu.

Werkzeuge: nur Kafka-Bordmittel und das Monitoring aus dem Buch (Anhang B: JMX-Exporter, Prometheus, Alertmanager, Grafana) sowie Kafbat UI (Kap. 2.5, 14.1.2).

## 1. Starten

Voraussetzung: Docker Desktop läuft (unten links „Engine running“).

```powershell
cd $HOME\Desktop\kafka-lab
docker compose up -d
docker compose ps
```

Nach etwa 30 Sekunden sind sieben Container „Up“: `kafka1`, `kafka2`, `kafka3`, `kafka-ui`, `prometheus`, `alertmanager`, `grafana` (`jmx-init` steht auf „Exited (0)“ – das ist richtig).

Für das Desaster-Recovery-Lab an Tag 2 zusätzlich:

```powershell
docker compose --profile dr up -d
```

Das startet `kafka-dr` (zweiter Cluster) und `mirror-maker`.

## 2. Oberflächen im Browser

| Was | Adresse |
| --- | --- |
| Kafbat UI (Topics, Nachrichten, Consumer Groups; Cluster „primary“ und „dr“) | http://localhost:8080 |
| Grafana, Dashboard „Kafka Broker“ | http://localhost:3000 |
| Prometheus (PromQL, Targets, Alerts) | http://localhost:9090 |
| Alertmanager | http://localhost:9093 |

## 3. Kafka-Befehle ausführen

Alle Kafka-Befehle laufen **im Container**:

```powershell
docker exec -it kafka1 bash
cd /opt/kafka/bin
./kafka-topics.sh --bootstrap-server kafka1:9092 --list
```

Mit `exit` verlassen Sie den Container wieder. Alle Befehle stehen im Cheat-Sheet.

Neu in Kafka 4.4 – die alten Namen funktionieren noch, erzeugen aber Warnungen:

| Alt | Neu |
| --- | --- |
| `--producer-property`, `--consumer-property`, `--producer-props` | `--command-property` |
| `--property` beim Console-Producer | `--reader-property` |
| `--property` beim Console-Consumer | `--formatter-property` |
| `--messages` beim Consumer-Perf-Test | `--num-records` |

Topics werden **nicht automatisch** angelegt (`auto.create.topics.enable=false`, wie im Buch für Produktion empfohlen). Ein Tippfehler im Topic-Namen führt deshalb zu `UNKNOWN_TOPIC_OR_PARTITION`.

Programme auf dem Windows-Rechner (IntelliJ, Spring Boot) verbinden sich mit `localhost:19092,localhost:19093,localhost:19094`.

## 4. Lab-Hilfsskripte

| Skript | Zweck |
| --- | --- |
| `bash /opt/lab/bin/mit-metriken <port> <werkzeug> [optionen]` | startet ein Kafka-Werkzeug mit JMX-Exporter, damit die Client-Metriken in Grafana erscheinen. Ports: 9201–9203 für Producer, 9211–9213 für Consumer |
| `bash /opt/lab/bin/bestandsverwaltung <1-3> [ms] [topic]` | simuliert eine Instanz der Bestandsverwaltung: Gruppe `bestand`, 20 ms Verarbeitung pro Änderung (max. 50/s), Metriken auf Port 9211–9213 |

Beispiel (Fallstudie):

```bash
./kafka-topics.sh --bootstrap-server kafka1:9092 --create --topic bestand.aenderungen --partitions 6 --replication-factor 3
bash /opt/lab/bin/mit-metriken 9201 kafka-producer-perf-test.sh --bootstrap-server kafka1:9092 --topic bestand.aenderungen --num-records 100000 --record-size 500 --throughput 100 --record-key-range 1000 --key-distribution random --command-property client.id=quelle
bash /opt/lab/bin/bestandsverwaltung 1
```

Meldet `mit-metriken` „Port ist schon belegt“, läuft dort noch ein Client. Beenden aus PowerShell:

```powershell
docker exec kafka1 pkill -f ConsoleConsumer
docker exec kafka1 pkill -f ProducerPerformance
```

Spring-Boot-Demo der Fallstudie: Ordner `bestand-demo` (eigene README). Prometheus holt ihre Metriken als Job `bestand-demo` von `host.docker.internal:8081` und `:8082`; die Ziele sind „down“, solange die App nicht läuft.

Client-Metriken verschwinden, sobald der Client endet – das ist gewollt. Den Lag einer Gruppe zeigen dann `kafka-consumer-groups.sh` und Kafbat UI.

## 5. Labs im Überblick

| Lab | Kern |
| --- | --- |
| Erste Schritte | Topic `products.prices.changelog`, Console-Producer und -Consumer |
| Partitionen | Topic `orders` (6 Partitionen, RF 3), Keys, `--describe` mit Elr-Spalten |
| Broker-Ausfall | `min.insync.replicas=2`, `docker stop kafka3`, `min.insync.replicas=3` → NotEnoughReplicas, danach `kafka-leader-election.sh` |
| Consumer Groups | Gruppe `analytics`, Lag, Offset-Reset, `kafka-groups.sh` |
| Monitoring I | Dashboard lesen, Broker-Ausfall live, `kafka-jmx.sh` |
| Performance | Perf-Tests mit `mit-metriken`, `kafka-e2e-latency.sh` |
| Monitoring II | Lag-Alert mit `bestandsverwaltung 1` |
| Fallstudie | 1–3 Instanzen der Bestandsverwaltung, Share Group als Gegenbeispiel |
| Desaster Recovery | `--profile dr`, Spiegelung `primary.*`, Failover der Gruppe `bestand` |

Den Befehl `docker stop kafka3` führen Sie in PowerShell aus, **nicht** im Container. Stoppen Sie **nie zwei** der drei Knoten gleichzeitig: Broker und Controller laufen kombiniert, das KRaft-Quorum ginge verloren. (In Produktion: eigene Controller-Knoten.)

Beim Anlegen von Topics mit Punkt im Namen erscheint eine Warnung zu Metriknamen. Sie ist harmlos.

## 6. Alert-Regel für die Demo verkürzen

In `prometheus\rules.yml` bei `ConsumerLagHigh` den Wert `for: 10m` auf `for: 1m` ändern, dann neu laden:

```powershell
curl.exe -X POST http://localhost:9090/-/reload
```

## 7. Aufräumen

```powershell
docker compose --profile dr down       # stoppt und entfernt alle Container – Topics und Nachrichten sind danach weg
docker compose --profile dr down -v    # zusätzlich den heruntergeladenen JMX-Agenten entfernen
```

Über Nacht von Tag 1 auf Tag 2 **nicht** `down` ausführen – dann bleiben die Topics erhalten. Wurde doch aufgeräumt, die Topics `orders` und `bestand.aenderungen` einfach neu anlegen.

Speicher sparen nach Perf-Tests:

```powershell
docker exec kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 --delete --topic perf
```

## 8. Wenn etwas hakt

| Symptom | Lösung |
| --- | --- |
| `docker` meldet „failed to connect to the docker API“ | Docker Desktop starten und warten, bis „Engine running“ steht |
| Ein Container ist nicht „Up“ | `docker compose logs kafka1` (bzw. Name des Containers) ansehen, dann `docker compose up -d` |
| Grafana zeigt „No data“ | 1–2 Minuten warten; in Prometheus unter Status → Targets prüfen. Client-Slots (9201–9213) und `bestand-demo` sind „down“, solange kein Client läuft – das ist normal |
| `UNKNOWN_TOPIC_OR_PARTITION` | Topic fehlt – mit `kafka-topics.sh --create` anlegen |
| Neue Instanz der Bestandsverwaltung bekommt keine Partition | einige Sekunden warten; `kafka-consumer-groups.sh --describe --group bestand --members` |
| Port belegt | `docker compose down`, prüfen, ob noch ein anderer Kafka läuft (`docker ps`) |
