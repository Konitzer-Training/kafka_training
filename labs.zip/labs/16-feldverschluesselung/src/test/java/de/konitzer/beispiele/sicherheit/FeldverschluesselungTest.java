package de.konitzer.beispiele.sicherheit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Map;

import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.Test;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** Ohne Kafka: Serializer und Deserializer direkt aufrufen. */
class FeldverschluesselungTest {

    private final IbanVerschluesselung serializer = new IbanVerschluesselung();
    private final IbanEntschluesselung deserializer = new IbanEntschluesselung();

    FeldverschluesselungTest() {
        Map<String, Object> config = Map.of("app.master-schluessel", "test-master",
                "spring.json.trusted.packages", "de.konitzer.beispiele.ereignisse");
        serializer.configure(config, false);
        deserializer.configure(config, false);
    }

    @Test
    void ibanLiegtVerschluesseltImTopicUndKommtEntschluesseltAn() {
        var aenderung = new Vertragsaenderung("V-1001", 1, "BANKVERBINDUNG",
                Map.of("kundennummer", "K-100", "iban", "DE02120300000000202051"), Instant.parse("2026-11-03T09:00:00Z"));
        var headers = new RecordHeaders();

        byte[] bytes = serializer.serialize("t", headers, aenderung);
        String imTopic = new String(bytes, StandardCharsets.UTF_8);

        assertThat(imTopic).doesNotContain("DE02120300000000202051").contains("\"kundennummer\":\"K-100\"");
        assertThat(new String(headers.lastHeader("dek-id").value())).isEqualTo("kunde-K-100");
        assertThat(deserializer.deserialize("t", headers, bytes)).isEqualTo(aenderung);
    }

    @Test
    void gleicheIbanErgibtJedesMalAnderesChiffrat() {
        var aenderung = new Vertragsaenderung("V-1001", 1, "BANKVERBINDUNG",
                Map.of("kundennummer", "K-100", "iban", "DE02120300000000202051"), Instant.now());

        String erstes = new String(serializer.serialize("t", new RecordHeaders(), aenderung), StandardCharsets.UTF_8);
        String zweites = new String(serializer.serialize("t", new RecordHeaders(), aenderung), StandardCharsets.UTF_8);

        // zufälliger IV: deshalb taugt ein verschlüsseltes Feld nie als Key
        assertThat(erstes).isNotEqualTo(zweites);
    }

    @Test
    void cryptoShreddingMachtDatenUnlesbar() {
        var aenderung = new Vertragsaenderung("V-1001", 1, "BANKVERBINDUNG",
                Map.of("kundennummer", "K-200", "iban", "DE02120300000000202051"), Instant.now());
        var headers = new RecordHeaders();
        byte[] bytes = serializer.serialize("t", headers, aenderung);

        Schluesseldienst.instanz().loescheSchluessel("kunde-K-200");

        assertThatThrownBy(() -> deserializer.deserialize("t", headers, bytes))
                .hasMessageContaining("Crypto-Shredding");
    }
}
