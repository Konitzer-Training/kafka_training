package de.konitzer.beispiele.sicherheit;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.serialization.Deserializer;
import org.springframework.kafka.support.serializer.JacksonJsonDeserializer;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** Gegenstück: liest die Schlüssel-ID aus dem Header und entschlüsselt das Feld "iban". */
public class IbanEntschluesselung implements Deserializer<Vertragsaenderung> {

    private final JacksonJsonDeserializer<Vertragsaenderung> json = new JacksonJsonDeserializer<>(Vertragsaenderung.class);
    private final Schluesseldienst schluessel = Schluesseldienst.instanz();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        json.configure(configs, isKey);
        Object master = configs.get("app.master-schluessel");
        if (master != null) {
            schluessel.setzeMasterschluessel(master.toString());
        }
    }

    @Override
    public Vertragsaenderung deserialize(String topic, byte[] data) {
        return json.deserialize(topic, data);
    }

    @Override
    public Vertragsaenderung deserialize(String topic, Headers headers, byte[] data) {
        Vertragsaenderung aenderung = json.deserialize(topic, headers, data);
        Header header = headers.lastHeader(IbanVerschluesselung.HEADER);
        if (aenderung == null || header == null) {
            return aenderung;
        }
        String id = new String(header.value(), StandardCharsets.UTF_8);
        Map<String, String> daten = new HashMap<>(aenderung.daten());
        daten.put(IbanVerschluesselung.FELD, schluessel.entschluessele(id, daten.get(IbanVerschluesselung.FELD)));
        return new Vertragsaenderung(aenderung.vertragsnummer(), aenderung.version(), aenderung.art(), daten,
                aenderung.zeitpunkt());
    }

    @Override
    public void close() {
        json.close();
    }
}
