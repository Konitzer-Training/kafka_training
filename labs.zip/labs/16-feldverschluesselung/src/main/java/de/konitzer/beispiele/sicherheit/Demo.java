package de.konitzer.beispiele.sicherheit;

import java.time.Instant;
import java.util.Map;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** Producer und Consumer in einer Anwendung: Die Konsole zeigt die IBAN entschlüsselt; das Topic enthält das Chiffrat. */
@Configuration
class Demo {

    @Bean
    NewTopic sicher(@Value("${app.topic}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic).partitions(3).replicas(rf).build();
    }

    @KafkaListener(id = "sicher", idIsGroup = false, topics = "${app.topic}")
    void empfangen(ConsumerRecord<String, Vertragsaenderung> datensatz) {
        var aenderung = datensatz.value();
        var dekId = datensatz.headers().lastHeader(IbanVerschluesselung.HEADER);
        System.out.printf("empfangen %s v%d %s  iban=%s  (Header dek-id=%s)%n", aenderung.vertragsnummer(),
                aenderung.version(), aenderung.art(), aenderung.daten().getOrDefault("iban", "-"),
                dekId == null ? "-" : new String(dekId.value()));
    }

    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "app.demo", havingValue = "true", matchIfMissing = true)
    CommandLineRunner demoLauf(KafkaTemplate<String, Vertragsaenderung> kafka, @Value("${app.topic}") String topic) {
        return args -> {
            Thread.sleep(3000);
            System.out.println();
            System.out.println("Demo Feldverschlüsselung. Beenden mit Strg+C.");
            kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 1, "BANKVERBINDUNG",
                    Map.of("kundennummer", "K-100", "iban", "DE02120300000000202051"), Instant.now()));
            kafka.send(topic, "V-1002", new Vertragsaenderung("V-1002", 1, "ADRESSE",
                    Map.of("kundennummer", "K-101", "plz", "50667"), Instant.now()));   // nichts zu verschlüsseln
            kafka.flush();
        };
    }
}
