package de.konitzer.beispiele.sicherheit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kapitel 16: Die IBAN wird im Producer verschlüsselt und erst im Consumer wieder entschlüsselt.
 * Broker, Backups und Kafbat UI sehen nur das Chiffrat.
 *
 * Start: java -jar 16-feldverschluesselung.jar
 * Vergleich: kafka-console-consumer.sh … --topic bestand.vertragsaenderungen.sicher --from-beginning
 */
@SpringBootApplication
public class SicherheitApp {

    public static void main(String[] args) {
        SpringApplication.run(SicherheitApp.class, args);
    }
}
