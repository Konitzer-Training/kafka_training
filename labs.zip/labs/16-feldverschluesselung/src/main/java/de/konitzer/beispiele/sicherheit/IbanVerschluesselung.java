package de.konitzer.beispiele.sicherheit;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.serialization.Serializer;
import org.springframework.kafka.support.serializer.JacksonJsonSerializer;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Serializer, der das Feld "iban" vor dem Senden verschlüsselt und die Schlüssel-ID in den Header schreibt.
 * Alles andere bleibt Klartext-JSON – der Key (Vertragsnummer) sowieso, denn ein verschlüsselter Key
 * würde Partitionierung und Compaction brechen.
 */
public class IbanVerschluesselung implements Serializer<Vertragsaenderung> {

    static final String FELD = "iban";
    static final String HEADER = "dek-id";
    static final String KUNDE = "kundennummer";

    private final JacksonJsonSerializer<Vertragsaenderung> json = new JacksonJsonSerializer<>();
    private final Schluesseldienst schluessel = Schluesseldienst.instanz();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        json.configure(configs, isKey);
        Object master = configs.get("app.master-schluessel");
        if (master != null) {
            schluessel.setzeMasterschluessel(master.toString());
        }
    }

    @Override
    public byte[] serialize(String topic, Vertragsaenderung aenderung) {
        throw new UnsupportedOperationException("Header nötig – Kafka ruft die Variante mit Headers auf");
    }

    @Override
    public byte[] serialize(String topic, Headers headers, Vertragsaenderung aenderung) {
        if (aenderung != null && aenderung.daten().containsKey(FELD)) {
            String id = schluessel.schluesselIdFuer(aenderung.daten().getOrDefault(KUNDE, aenderung.vertragsnummer()));
            Map<String, String> daten = new HashMap<>(aenderung.daten());
            daten.put(FELD, schluessel.verschluessele(id, daten.get(FELD)));
            headers.add(HEADER, id.getBytes(StandardCharsets.UTF_8));
            aenderung = new Vertragsaenderung(aenderung.vertragsnummer(), aenderung.version(), aenderung.art(),
                    daten, aenderung.zeitpunkt());
        }
        return json.serialize(topic, headers, aenderung);
    }

    @Override
    public void close() {
        json.close();
    }
}
