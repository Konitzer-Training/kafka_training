package de.konitzer.beispiele.sicherheit;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Envelope Encryption, stark vereinfacht: Aus einem Master-Schlüssel (in Produktion im KMS oder HSM)
 * wird je Kunde ein Daten-Schlüssel abgeleitet. Die Schlüssel-ID wandert im Header mit.
 *
 * Crypto-Shredding: Wird der Schlüssel eines Kunden gesperrt, sind seine Daten in allen Topics,
 * Backups und DR-Clustern unlesbar – auch wenn das Log unveränderlich bleibt.
 *
 * Eine statische Instanz, weil Kafka Serializer per Klassenname und ohne Spring erzeugt.
 */
public final class Schluesseldienst {

    private static final Schluesseldienst INSTANZ = new Schluesseldienst();
    private static final SecureRandom ZUFALL = new SecureRandom();

    private final Map<String, byte[]> datenschluessel = new ConcurrentHashMap<>();
    private final Set<String> gesperrt = ConcurrentHashMap.newKeySet();
    private volatile byte[] masterschluessel;

    private Schluesseldienst() {
    }

    public static Schluesseldienst instanz() {
        return INSTANZ;
    }

    /** Wird vom Serializer aus der Kafka-Konfiguration gesetzt (app.master-schluessel). */
    public void setzeMasterschluessel(String master) {
        this.masterschluessel = master.getBytes(StandardCharsets.UTF_8);
    }

    /** Daten-Schlüssel je Kunde: HMAC(master, kundennummer). In Produktion: vom KMS erzeugt und verschlüsselt gespeichert. */
    public String schluesselIdFuer(String kundennummer) {
        return "kunde-" + kundennummer;
    }

    public String verschluessele(String schluesselId, String klartext) {
        try {
            byte[] iv = new byte[12];
            ZUFALL.nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, schluessel(schluesselId), new GCMParameterSpec(128, iv));
            byte[] chiffrat = cipher.doFinal(klartext.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(iv) + ":" + Base64.getEncoder().encodeToString(chiffrat);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Verschlüsseln fehlgeschlagen", e);
        }
    }

    public String entschluessele(String schluesselId, String chiffrat) {
        if (gesperrt.contains(schluesselId)) {
            throw new IllegalStateException("Schlüssel " + schluesselId + " ist gelöscht (Crypto-Shredding)");
        }
        try {
            String[] teile = chiffrat.split(":", 2);
            byte[] iv = Base64.getDecoder().decode(teile[0]);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, schluessel(schluesselId), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(Base64.getDecoder().decode(teile[1])), StandardCharsets.UTF_8);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Entschlüsseln fehlgeschlagen", e);
        }
    }

    /** Crypto-Shredding: Schlüssel des Kunden löschen – ab jetzt sind seine Daten unlesbar. */
    public void loescheSchluessel(String schluesselId) {
        gesperrt.add(schluesselId);
        datenschluessel.remove(schluesselId);
    }

    private SecretKeySpec schluessel(String schluesselId) throws GeneralSecurityException {
        if (masterschluessel == null) {
            throw new IllegalStateException("Kein Master-Schlüssel konfiguriert (app.master-schluessel)");
        }
        byte[] dek = datenschluessel.computeIfAbsent(schluesselId, id -> {
            try {
                Mac mac = Mac.getInstance("HmacSHA256");
                mac.init(new SecretKeySpec(masterschluessel, "HmacSHA256"));
                return mac.doFinal(id.getBytes(StandardCharsets.UTF_8));
            } catch (GeneralSecurityException e) {
                throw new IllegalStateException(e);
            }
        });
        return new SecretKeySpec(dek, "AES");   // 32 Byte = AES-256
    }
}
