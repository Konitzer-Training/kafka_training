package de.konitzer.beispiele.plain;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;

/**
 * Test gegen einen echten Broker im Docker-Container (Testcontainers, Kapitel 13).
 * Prüft: Key und Wert kommen an, gleicher Key landet in derselben Partition.
 */
@Testcontainers
class PlainProducerIT {

    @Container
    static KafkaContainer kafka = new KafkaContainer("apache/kafka:4.4.0");

    @Test
    void gleicherKeyLandetInDerselbenPartition() throws Exception {
        // Topic mit 3 Partitionen anlegen (im Lab macht das 01-shell/01-topic-anlegen.sh)
        try (Admin admin = Admin.create(verbindung(kafka.getBootstrapServers()))) {
            admin.createTopics(List.of(new NewTopic("beitraege", 3, (short) 1))).all().get();
        }

        var props = verbindung(kafka.getBootstrapServers());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        try (var producer = new KafkaProducer<String, String>(props)) {
            var erste = PlainProducer.sende(producer, "beitraege", "V-1001:Beitrag 42,50").get();
            var zweite = PlainProducer.sende(producer, "beitraege", "V-1001:Beitrag 44,00").get();
            assertThat(zweite.partition()).isEqualTo(erste.partition());
            assertThat(zweite.offset()).isEqualTo(erste.offset() + 1);
            // Die Rechnung des Producers lässt sich vorab nachvollziehen (für Werkzeuge, nicht für Consumer)
            assertThat(PlainProducer.partitionFuer("V-1001", 3)).isEqualTo(erste.partition());
        }

        // Nachlesen wie mit 01-shell/03-consumer.sh
        var leser = verbindung(kafka.getBootstrapServers());
        leser.put(ConsumerConfig.GROUP_ID_CONFIG, "test");
        leser.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        leser.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        leser.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        try (var consumer = new KafkaConsumer<String, String>(leser)) {
            consumer.subscribe(List.of("beitraege"));
            var gelesen = new java.util.ArrayList<ConsumerRecord<String, String>>();
            long ende = System.currentTimeMillis() + 10_000;
            while (gelesen.size() < 2 && System.currentTimeMillis() < ende) {
                consumer.poll(Duration.ofMillis(200)).forEach(gelesen::add);
            }
            assertThat(gelesen).hasSize(2);
            assertThat(gelesen.get(0).key()).isEqualTo("V-1001");
            assertThat(gelesen.get(0).value()).isEqualTo("Beitrag 42,50");
            assertThat(gelesen.get(1).value()).isEqualTo("Beitrag 44,00");
        }
    }

    private static Properties verbindung(String bootstrap) {
        var p = new Properties();
        p.put("bootstrap.servers", bootstrap);
        return p;
    }
}
