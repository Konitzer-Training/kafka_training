package de.konitzer.beispiele.plain;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.clients.producer.internals.BuiltInPartitioner;
import org.apache.kafka.common.serialization.StringSerializer;

/**
 * Der Console Producer als Java-Programm – ohne Spring, nur mit dem Kafka-Client.
 *
 * Das Shell-Skript 01-shell/02-producer.sh macht dasselbe: Zeilen "key:wert" einlesen und
 * als Nachrichten in ein Topic schreiben. Dieses Programm zeigt zusätzlich, in welcher
 * Partition und unter welchem Offset jede Nachricht gelandet ist – das kann der Console
 * Producer nicht.
 *
 * Starten:   java -jar target/02-producer-plain-app.jar
 *            dann Zeilen eintippen, z. B.  V-1001:Beitrag 42,50   – leere Zeile beendet.
 * Oder die Nachrichten gleich mitgeben:
 *            java -jar target/02-producer-plain-app.jar "V-1001:Beitrag 42,50" "V-1002:Beitrag 19,90"
 * Anderes Topic oder anderer Cluster:
 *            java -Dtopic=test -Dbootstrap=localhost:19092 -jar target/02-producer-plain-app.jar
 * Nur ausrechnen, in welche Partition ein Key fällt (nichts wird gesendet):
 *            java -Drechne=V-1001 -jar target/02-producer-plain-app.jar
 */
public class PlainProducer {

    public static void main(String[] args) throws Exception {
        // -Dtopic=... beim Start überschreibt den Standard "beitraege"
        String topic = System.getProperty("topic", "beitraege");

        // 1. Konfiguration: ein Properties-Objekt, Schlüssel wie in der Kafka-Dokumentation.
        //    Die Konstanten aus ProducerConfig sind nur die Namen als String, z. B.
        //    ProducerConfig.ACKS_CONFIG == "acks". Beides ist erlaubt.
        Properties einstellungen = new Properties();
        // Wo ist der Cluster? Mehrere Adressen, damit der Start auch klappt, wenn ein Broker fehlt.
        // Von außen heißen die Lab-Broker localhost:19092/19093/19094 (im Container: kafka1:9092).
        einstellungen.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                System.getProperty("bootstrap", "localhost:19092,localhost:19093,localhost:19094"));
        // Kafka kennt nur Bytes. Der Serializer wandelt unseren Key und Wert (hier Text) in Bytes um.
        einstellungen.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        einstellungen.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        // Auf die Bestätigung aller Kopien im ISR warten (wie --command-property acks=all im Skript)
        einstellungen.put(ProducerConfig.ACKS_CONFIG, "all");
        // Sprechender Name: so erscheint dieser Producer in Metriken und Broker-Logs
        einstellungen.put(ProducerConfig.CLIENT_ID_CONFIG, "producer-plain");

        // 2. Den Producer erzeugen. Er hält eine Verbindung zum Cluster und einen Sendepuffer.
        //    try-with-resources: close() am Ende sendet den Puffer leer und trennt die Verbindung.
        try (Producer<String, String> producer = new KafkaProducer<>(einstellungen)) {
            // Sonderfall -Drechne=KEY: nur zeigen, wohin der Key gehört, ohne zu senden
            String rechne = System.getProperty("rechne");
            if (rechne != null) {
                int partitionen = producer.partitionsFor(topic).size();
                for (String key : rechne.split(",")) {
                    System.out.printf("Key %-10s -> Partition %d  (Topic %s hat %d Partitionen)%n",
                            key.trim(), partitionFuer(key.trim(), partitionen), topic, partitionen);
                }
                return;
            }
            System.out.println("Producer bereit. Topic: " + topic);

            if (args.length > 0) {
                // Variante A: Nachrichten als Programmargumente
                for (String zeile : args) {
                    sende(producer, topic, zeile);
                }
            } else {
                // Variante B: Zeilen von der Tastatur, wie beim Console Producer
                System.out.println("Eingabe: key:wert, z. B.  V-1001:Beitrag 42,50   (leere Zeile beendet)");
                var eingabe = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
                String zeile;
                while ((zeile = eingabe.readLine()) != null && !zeile.isBlank()) {
                    sende(producer, topic, zeile);
                }
            }
            // 3. send() kehrt sofort zurück und sammelt im Puffer. flush() schickt alles ab und
            //    wartet auf die Antworten – erst danach stimmen die Ausgaben der Callbacks.
            producer.flush();
            System.out.println("Producer beendet.");
        }
    }

    /**
     * Dieselbe Rechnung, die der Producer beim Senden macht: murmur2-Hash der Key-Bytes, modulo
     * Partitionsanzahl. Deshalb landet gleicher Key immer in derselben Partition – bei jedem Producer,
     * in jeder Sprache. Ein Consumer muss das nie rechnen: Er liest die Partition aus der Nachricht.
     * Die Funktion ist nur für Werkzeuge nützlich, etwa um vor dem Lesen zu wissen, wo V-1001 liegt.
     */
    static int partitionFuer(String key, int partitionen) {
        byte[] bytes = key.getBytes(StandardCharsets.UTF_8);
        return BuiltInPartitioner.partitionForKey(bytes, partitionen);
    }

    /**
     * Eine Zeile "key:wert" senden. Ohne Doppelpunkt wird ohne Key gesendet; dann verteilt
     * der Producer die Nachricht selbst (Round Robin über die Partitionen).
     */
    static Future<RecordMetadata> sende(Producer<String, String> producer, String topic, String zeile) {
        int trenner = zeile.indexOf(':');
        String key = trenner > 0 ? zeile.substring(0, trenner).trim() : null;
        String wert = trenner > 0 ? zeile.substring(trenner + 1).trim() : zeile.trim();

        // Eine Nachricht = ein ProducerRecord: Topic, Key, Wert. Die Partition wählt der Producer
        // aus dem Key (gleicher Key -> gleiche Partition), wir geben sie nicht an.
        var nachricht = new ProducerRecord<>(topic, key, wert);

        // send() ist asynchron. Der Callback läuft, sobald der Broker geantwortet hat.
        // Ohne Callback (oder ohne get() auf dem Future) würden Fehler still verloren gehen!
        return producer.send(nachricht, (meta, fehler) -> {
            if (fehler != null) {
                System.out.printf("FEHLER   key=%-8s \"%s\" -> %s%n", key, wert, fehler.getMessage());
            } else {
                // meta sagt uns, wo die Nachricht liegt: Partition und Offset
                System.out.printf("gesendet key=%-8s \"%s\" -> Partition %d, Offset %d%n",
                        key, wert, meta.partition(), meta.offset());
            }
        });
    }
}
