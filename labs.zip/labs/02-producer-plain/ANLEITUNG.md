# 02-producer-plain – Arbeitsanweisung

**Was es zeigt:** Das Shell-Skript `01-shell/02-producer.sh` als Java-Programm. Eine Klasse, keine Frameworks, nur der Kafka-Client. Neu gegenüber der Shell: Das Programm sieht das **Ergebnis** jedes Sendens (Partition, Offset, Fehler).

**Buch:** Kapitel 3 (Erste Schritte) und 4 (Keys bestimmen die Partition).

## Ausprobieren (5 Minuten)

Voraussetzung: Lab läuft, Topic existiert (`01-shell/01-topic-anlegen`), das Projekt ist gebaut (`.\mvnw.cmd verify` im Ordner `labs`, einmalig).

1. In einem Fenster den Shell-Consumer starten: `01-shell\03-consumer.ps1` (macOS: `./03-consumer.sh`).
2. In einem zweiten Fenster den Producer starten:
   ```powershell
   java -jar 02-producer-plain\target\02-producer-plain-app.jar
   ```
3. Eintippen, Enter:
   ```text
   V-1001:Beitrag 42,50
   V-1002:Beitrag 19,90
   V-1001:Beitrag 44,00
   ```
   Beobachten: Der Producer meldet `Partition n, Offset m`. Beide V-1001-Zeilen liegen in derselben Partition, der Offset zählt hoch. Der Shell-Consumer zeigt dieselben Nummern.
4. Leere Zeile beendet.

Ohne Tippen, zum Beispiel für ein Skript:

```powershell
java -jar 02-producer-plain\target\02-producer-plain-app.jar "V-1003:Beitrag 9,99" "ohne Key"
```

`ohne Key` hat keinen Doppelpunkt und wird ohne Key gesendet: Der Producer verteilt selbst.

Nur ausrechnen, wohin ein Key gehört, ohne zu senden (dieselbe Funktion, die `send()` benutzt):

```powershell
java -Drechne=V-1001,V-1002 -jar 02-producer-plain\target\02-producer-plain-app.jar
```

Als Skript: `01-shell\10-partition-fuer-key.ps1`. Ein Consumer braucht diese Rechnung nicht, er liest die Partition aus jeder Nachricht.

## Was im Code zu sehen ist

| Zeile im Code | Entsprechung im Shell-Skript |
| --- | --- |
| `BOOTSTRAP_SERVERS_CONFIG` | `--bootstrap-server` |
| `KEY_SERIALIZER_CLASS_CONFIG` | nicht nötig, die Shell kann nur Text |
| `ACKS_CONFIG = all` | `--command-property acks=all` |
| `new ProducerRecord<>(topic, key, wert)` | eine Zeile `key:wert` |
| Callback in `sende()` | gibt es nicht – die Shell zeigt kein Ergebnis |
| `producer.flush()` | passiert beim Beenden automatisch |

## Aufgaben

1. Senden Sie fünf Nachrichten mit fünf verschiedenen Keys. Wie verteilen sie sich auf die drei Partitionen? Ist die Verteilung gleichmäßig?
2. Entfernen Sie den Callback in `sende()` (nur `producer.send(nachricht)` zurückgeben) und starten Sie mit `-Dbootstrap=localhost:1`. Was sehen Sie? Was sehen Sie nicht? Das ist „Fire and forget“ aus Kapitel 7.
3. Setzen Sie `ACKS_CONFIG` auf `"0"` und senden Sie noch einmal. Was steht jetzt im Offset?
4. Rechnen Sie mit `-Drechne=V-1001` die Partition aus, senden Sie dann `V-1001:Test`. Stimmt es? Legen Sie ein Topic mit 6 Partitionen an (`01-shell\01-topic-anlegen.ps1 -Topic test6 -Partitionen 6`) und rechnen Sie mit `-Dtopic=test6` erneut.

## Ändern und bauen

- **IntelliJ:** `File → Open` auf den Ordner `labs` (das Wurzel-POM). Dann im Projektbaum `02-producer-plain → PlainProducer` öffnen, Rechtsklick auf `main` → Run. Argumente und `-Dtopic=…` unter `Run → Edit Configurations`.
- **Nur dieses Modul bauen** (im Ordner `labs`):
  ```powershell
  .\mvnw.cmd -pl 02-producer-plain package -DskipTests
  ```
  Ergebnis: `02-producer-plain\target\02-producer-plain-app.jar`. Dauer nach dem ersten Mal etwa 10 Sekunden.
- **Mit Test bauen** (braucht Docker, startet einen eigenen Kafka-Container):
  ```powershell
  .\mvnw.cmd -pl 02-producer-plain verify
  ```
- Der Test `PlainProducerIT` prüft, dass gleicher Key in derselben Partition landet. Wenn Sie `sende()` ändern, sagt er Ihnen, ob es noch stimmt.
