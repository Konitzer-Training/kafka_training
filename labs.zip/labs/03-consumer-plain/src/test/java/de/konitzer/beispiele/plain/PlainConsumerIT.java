package de.konitzer.beispiele.plain;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;

/** Die Leseschleife liest alles, was vorher geschrieben wurde, und committet. */
@Testcontainers
class PlainConsumerIT {

    @Container
    static KafkaContainer kafka = new KafkaContainer("apache/kafka:4.4.0");

    @Test
    void liestAlleNachrichtenVonAnfangAn() throws Exception {
        var p = new Properties();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getBootstrapServers());
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        try (var producer = new KafkaProducer<String, String>(p)) {
            producer.send(new ProducerRecord<>("beitraege", "V-1001", "Beitrag 42,50")).get();
            producer.send(new ProducerRecord<>("beitraege", "V-1002", "Beitrag 19,90")).get();
        }

        var c = new Properties();
        c.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getBootstrapServers());
        c.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        c.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        c.put(ConsumerConfig.GROUP_ID_CONFIG, "test");
        c.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        c.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        var gelesen = new CopyOnWriteArrayList<ConsumerRecord<String, String>>();
        try (var consumer = new KafkaConsumer<String, String>(c)) {
            consumer.subscribe(List.of("beitraege"));
            // Die Schleife läuft in einem eigenen Thread, der Test stoppt sie nach 2 Nachrichten
            var leser = new Thread(() -> PlainConsumer.lies(consumer, gelesen::add));
            leser.start();
            long ende = System.currentTimeMillis() + 15_000;
            while (gelesen.size() < 2 && System.currentTimeMillis() < ende) {
                Thread.sleep(100);
            }
            PlainConsumer.stoppe(consumer);
            leser.join(5_000);
        }
        assertThat(gelesen).extracting(ConsumerRecord::key).containsExactlyInAnyOrder("V-1001", "V-1002");
    }
}
