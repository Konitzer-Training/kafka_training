package de.konitzer.beispiele.plain;

import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;

/**
 * Der Console Consumer als Java-Programm – ohne Spring, nur mit dem Kafka-Client.
 *
 * Das Shell-Skript 01-shell/05-consumer-gruppe.sh macht dasselbe: Nachrichten eines Topics
 * lesen, Partition/Offset/Key/Wert ausgeben, Offsets für die Gruppe merken. Hier sieht man
 * die drei Schritte, die jeder Consumer macht: subscribe – poll – commit.
 *
 * Starten:   java -jar target/03-consumer-plain-app.jar       (Beenden mit Strg+C)
 * Optionen:  -Dtopic=beitraege -Dgruppe=beitragsrechner-plain -Dbootstrap=localhost:19092
 */
public class PlainConsumer {

    // Flag, über das Strg+C die Leseschleife sauber beendet
    private static final AtomicBoolean laeuft = new AtomicBoolean(true);

    public static void main(String[] args) {
        String topic = System.getProperty("topic", "beitraege");
        String gruppe = System.getProperty("gruppe", "beitragsrechner-plain");

        // 1. Konfiguration – Gegenstück zum Producer
        Properties einstellungen = new Properties();
        einstellungen.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
                System.getProperty("bootstrap", "localhost:19092,localhost:19093,localhost:19094"));
        // Bytes zurück in Text. Muss zum Serializer des Producers passen!
        einstellungen.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        einstellungen.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        // Pflicht bei subscribe(): die Consumer Group. Kafka merkt sich je Gruppe und Partition,
        // bis wohin gelesen wurde. (Der Console Consumer ohne --group erfindet eine Wegwerf-Gruppe.)
        einstellungen.put(ConsumerConfig.GROUP_ID_CONFIG, gruppe);
        // Startposition, wenn die Gruppe noch keinen Offset hat: earliest = von Anfang an
        // (wie --from-beginning). Default wäre latest = nur neue Nachrichten.
        einstellungen.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        // Offsets nicht automatisch im Hintergrund committen, sondern selbst – nach der Verarbeitung.
        // Sonst gilt eine Nachricht als erledigt, obwohl das Programm beim Verarbeiten abstürzt.
        einstellungen.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        // Neues Gruppenprotokoll (KIP-848), wie --command-property group.protocol=consumer
        einstellungen.put(ConsumerConfig.GROUP_PROTOCOL_CONFIG, "consumer");
        einstellungen.put(ConsumerConfig.CLIENT_ID_CONFIG, "consumer-plain");

        // 2. Den Consumer erzeugen. Achtung: Ein KafkaConsumer gehört genau einem Thread.
        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(einstellungen)) {
            // Strg+C: wakeup() unterbricht ein laufendes poll() mit einer WakeupException
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                laeuft.set(false);
                consumer.wakeup();
            }));

            // 3. subscribe: "Ich will dieses Topic lesen." Welche Partitionen dieser Consumer
            //    bekommt, entscheidet die Gruppe (Rebalance) – nicht wir.
            consumer.subscribe(List.of(topic));
            System.out.println("Consumer bereit. Topic: " + topic + ", Gruppe: " + gruppe + " – Strg+C beendet.");

            lies(consumer, nachricht -> System.out.printf("P%d @%-3d key=%-8s %s%n",
                    nachricht.partition(), nachricht.offset(), nachricht.key(), nachricht.value()));
        }
        System.out.println("Consumer beendet.");
    }

    /**
     * Die Leseschleife: poll holt ein Paket Nachrichten (oder wartet bis zu einer Sekunde),
     * wir verarbeiten sie, dann committen wir die Offsets. Wenn das Programm zwischen
     * Verarbeitung und Commit abstürzt, kommen diese Nachrichten nach dem Neustart noch einmal
     * ("at least once", Kapitel 5).
     */
    static void lies(KafkaConsumer<String, String> consumer, Consumer<ConsumerRecord<String, String>> verarbeitung) {
        try {
            while (laeuft.get()) {
                // poll ist DER Aufruf im Consumer: holt Nachrichten, sendet Heartbeats, macht Rebalances
                ConsumerRecords<String, String> paket = consumer.poll(Duration.ofSeconds(1));
                for (ConsumerRecord<String, String> nachricht : paket) {
                    verarbeitung.accept(nachricht);
                }
                if (!paket.isEmpty()) {
                    // Synchron committen: "Bis hierher bin ich fertig." Das Skript 06-gruppe-ansehen.sh
                    // zeigt diesen Stand als CURRENT-OFFSET.
                    consumer.commitSync();
                }
            }
        } catch (WakeupException e) {
            // erwartet beim Beenden – kein Fehler
        }
    }

    /** Für Tests: die Schleife von außen beenden. */
    static void stoppe(KafkaConsumer<String, String> consumer) {
        laeuft.set(false);
        consumer.wakeup();
    }
}
