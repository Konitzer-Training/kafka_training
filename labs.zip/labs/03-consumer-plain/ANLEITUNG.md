# 03-consumer-plain – Arbeitsanweisung

**Was es zeigt:** Das Shell-Skript `01-shell/05-consumer-gruppe.sh` als Java-Programm: subscribe, poll, commit. Eine Klasse, kein Spring.

**Buch:** Kapitel 3 (Erste Schritte) und 6 (Consumer Groups und Offsets).

## Ausprobieren (5 Minuten)

1. Consumer starten:
   ```powershell
   java -jar 03-consumer-plain\target\03-consumer-plain-app.jar
   ```
   Beim ersten Start liest er alles, was im Topic liegt (`auto.offset.reset=earliest`), und wartet dann.
2. Im zweiten Fenster Nachrichten schreiben, mit der Shell (`01-shell\02-producer.ps1`) oder mit Java (`02-producer-plain`). Jede erscheint im Consumer als `P<Partition> @<Offset> key=… wert`.
3. Consumer mit Strg+C beenden, drei weitere Nachrichten schreiben, Consumer neu starten: Er zeigt **nur die drei neuen**. Das ist der Unterschied zu `03-consumer.sh`: Die Gruppe `beitragsrechner-plain` hat sich den Offset gemerkt.
4. Nachsehen, was Kafka gespeichert hat:
   ```powershell
   01-shell\06-gruppe-ansehen.ps1 -Gruppe beitragsrechner-plain
   ```
   `CURRENT-OFFSET` ist der Stand aus `commitSync()`.

## Was im Code zu sehen ist

| Zeile im Code | Entsprechung im Shell-Skript |
| --- | --- |
| `GROUP_ID_CONFIG` | `--group` |
| `AUTO_OFFSET_RESET_CONFIG = earliest` | `--from-beginning` (nur beim allerersten Start der Gruppe) |
| `ENABLE_AUTO_COMMIT_CONFIG = false` + `commitSync()` | die Shell committet automatisch alle 5 Sekunden |
| `subscribe(List.of(topic))` | `--topic` |
| `poll(Duration.ofSeconds(1))` | passiert im Skript unsichtbar in einer Schleife |

## Aufgaben

1. Starten Sie den Consumer **zweimal** (zwei Fenster, gleiche Gruppe) und schreiben Sie Nachrichten mit verschiedenen Keys. Welches Fenster zeigt welche Partition? Beenden Sie ein Fenster: Was passiert im anderen?
2. Starten Sie einen dritten Consumer mit `-Dgruppe=statistik`. Warum bekommt er alle Nachrichten noch einmal?
3. Kommentieren Sie `consumer.commitSync()` aus, bauen Sie neu und starten Sie den Consumer zweimal hintereinander. Was passiert beim zweiten Start? Warum ist das trotzdem kein Fehler von Kafka?
4. Bauen Sie in `lies()` vor `commitSync()` ein `Thread.sleep(2000)` ein und beobachten Sie `06-gruppe-ansehen` während des Lesens: Der LAG wird sichtbar.

## Ändern und bauen

- **IntelliJ:** Projekt `labs` öffnen, `03-consumer-plain → PlainConsumer → main` starten. VM-Optionen wie `-Dgruppe=test` unter `Run → Edit Configurations`.
- **Nur dieses Modul bauen:**
  ```powershell
  .\mvnw.cmd -pl 03-consumer-plain package -DskipTests
  ```
- **Mit Test** (startet einen Kafka-Container, braucht Docker):
  ```powershell
  .\mvnw.cmd -pl 03-consumer-plain verify
  ```
