package de.konitzer.beispiele.ereignisse;

import java.math.BigDecimal;
import java.time.Instant;

/** Eine gemeldete Schadensumme zu einem Vertrag. Key der Nachricht: die Schadennummer. */
public record Schadenmeldung(
        String schadennummer,
        String vertragsnummer,
        BigDecimal betrag,
        Instant zeitpunkt) {
}
