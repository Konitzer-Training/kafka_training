package de.konitzer.beispiele.ereignisse;

import java.math.BigDecimal;

/** Die Rückstellung, die eine Schadenmeldung auslöst – berechnet und wieder nach Kafka geschrieben. */
public record Reserve(
        String schadennummer,
        BigDecimal betrag,
        String regel) {
}
