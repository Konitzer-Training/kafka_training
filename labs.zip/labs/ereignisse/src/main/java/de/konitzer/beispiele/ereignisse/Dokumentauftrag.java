package de.konitzer.beispiele.ereignisse;

/** Auftrag, ein Dokument zu erzeugen – unabhängige Aufträge, Reihenfolge egal. */
public record Dokumentauftrag(
        String vertragsnummer,
        String vorlage) {
}
