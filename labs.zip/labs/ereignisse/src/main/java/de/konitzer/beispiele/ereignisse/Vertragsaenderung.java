package de.konitzer.beispiele.ereignisse;

import java.time.Instant;
import java.util.Map;

/**
 * Eine Änderung an einem Vertrag – das zentrale Ereignis des Buchs.
 *
 * Key der Kafka-Nachricht ist die Vertragsnummer (Reihenfolge pro Vertrag),
 * der Wert ist dieses Record als JSON.
 *
 * @param vertragsnummer z. B. "V-1001"; zugleich der Kafka-Key
 * @param version        fortlaufend je Vertrag – damit erkennt der Consumer Duplikate und Lücken
 * @param art            ADRESSE, BEITRAG, BANKVERBINDUNG, TARIF, KUENDIGUNG …
 * @param daten          die geänderten Felder, z. B. {"plz": "50667"}
 * @param zeitpunkt      wann die Änderung im Quellsystem passiert ist
 */
public record Vertragsaenderung(
        String vertragsnummer,
        int version,
        String art,
        Map<String, String> daten,
        Instant zeitpunkt) {
}
