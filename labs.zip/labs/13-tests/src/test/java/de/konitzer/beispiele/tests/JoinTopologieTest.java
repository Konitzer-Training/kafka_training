package de.konitzer.beispiele.tests;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.time.Instant;
import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.TopologyTestDriver;
import org.junit.jupiter.api.Test;

import de.konitzer.beispiele.streams.Topologien;

/** Kafka Streams ohne Broker: synchron, mit kontrollierter Zeit. Weitere Topologie-Tests im Modul 11-streams. */
class JoinTopologieTest {

    @Test
    void antragUndPruefungErgebenPolice() {
        StreamsBuilder builder = new StreamsBuilder();
        Topologien.antragUndPruefung(builder, Duration.ofMinutes(5));

        Properties config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
        config.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        config.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);

        try (var treiber = new TopologyTestDriver(builder.build(), config)) {
            var antraege = treiber.createInputTopic("antraege", new StringSerializer(), new StringSerializer());
            var pruefungen = treiber.createInputTopic("pruefungen", new StringSerializer(), new StringSerializer());
            var policen = treiber.createOutputTopic("policen", new StringDeserializer(), new StringDeserializer());

            antraege.pipeInput("V-2001", "Antrag KFZ", Instant.parse("2026-11-03T09:00:00Z"));
            pruefungen.pipeInput("V-2001", "geprüft", Instant.parse("2026-11-03T09:03:00Z"));
            pruefungen.pipeInput("V-2002", "geprüft", Instant.parse("2026-11-03T09:04:00Z"));   // kein Antrag

            assertThat(policen.readKeyValuesToList()).containsExactly(
                    KeyValue.pair("V-2001", "Police aus Antrag \"Antrag KFZ\" und Prüfung \"geprüft\""));
        }
    }
}
