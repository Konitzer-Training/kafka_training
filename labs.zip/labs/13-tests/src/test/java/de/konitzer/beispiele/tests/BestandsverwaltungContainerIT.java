package de.konitzer.beispiele.tests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.kafka.core.KafkaTemplate;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;

import de.konitzer.beispiele.consumer.Bestand;
import de.konitzer.beispiele.consumer.ConsumerApp;
import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Integrationstest mit Testcontainers: ein Container mit demselben Broker-Image wie im Lab und in Produktion.
 * @ServiceConnection setzt spring.kafka.bootstrap-servers automatisch auf den Container. Braucht Docker.
 */
@SpringBootTest(classes = ConsumerApp.class, properties = {
        "app.replikation=1",
        "spring.kafka.producer.value-serializer=org.springframework.kafka.support.serializer.JacksonJsonSerializer",
        "spring.kafka.producer.properties.spring.json.add.type.headers=false"
})
@Testcontainers
class BestandsverwaltungContainerIT {

    @Container
    @ServiceConnection
    static KafkaContainer kafka = new KafkaContainer("apache/kafka:4.4.0");

    @Autowired KafkaTemplate<String, Object> template;
    @Autowired Bestand bestand;

    @Test
    void verbuchtAenderung() {
        template.send("bestand.vertragsaenderungen", "V-1001",
                new Vertragsaenderung("V-1001", 1, "ADRESSE", Map.of("plz", "50667"), Instant.now()));

        await().atMost(Duration.ofSeconds(30)).untilAsserted(() ->
                assertThat(bestand.letzteVersion("V-1001")).isEqualTo(1));
    }
}
