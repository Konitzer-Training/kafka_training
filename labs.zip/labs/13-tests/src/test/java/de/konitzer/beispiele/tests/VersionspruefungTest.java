package de.konitzer.beispiele.tests;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;

import de.konitzer.beispiele.consumer.Bestand;
import de.konitzer.beispiele.consumer.Verbuchung;
import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** Unterste Ebene der Pyramide: Fachlogik ohne Kafka, ohne Spring – Millisekunden. */
class VersionspruefungTest {

    private final Bestand bestand = new Bestand();
    private final Verbuchung verbuchung = new Verbuchung(bestand);

    @Test
    void duplikatWirdUebersprungen() {
        verbuchung.verarbeite(aenderung("V-1001", 1));
        // zweite Zustellung derselben Änderung (at-least-once)
        Verbuchung.Ergebnis ergebnis = verbuchung.verarbeite(aenderung("V-1001", 1));

        assertThat(ergebnis).isEqualTo(Verbuchung.Ergebnis.DUPLIKAT);
        assertThat(bestand.letzteVersion("V-1001")).isEqualTo(1);
        assertThat(verbuchung.duplikate()).isEqualTo(1);
        assertThat(verbuchung.verbucht()).isEqualTo(1);
    }

    @Test
    void lueckeWirdErkannt() {
        verbuchung.verarbeite(aenderung("V-1001", 1));
        // v2 fehlt
        Verbuchung.Ergebnis ergebnis = verbuchung.verarbeite(aenderung("V-1001", 3));

        assertThat(ergebnis).isEqualTo(Verbuchung.Ergebnis.LUECKE);
        assertThat(verbuchung.luecken()).isEqualTo(1);
        assertThat(bestand.letzteVersion("V-1001")).isEqualTo(3);
    }

    private static Vertragsaenderung aenderung(String vertrag, int version) {
        return new Vertragsaenderung(vertrag, version, "ADRESSE", Map.of("plz", "50667"), Instant.now());
    }
}
