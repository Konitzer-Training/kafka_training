package de.konitzer.beispiele.tests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;

import de.konitzer.beispiele.consumer.Bestand;
import de.konitzer.beispiele.consumer.ConsumerApp;
import de.konitzer.beispiele.consumer.Verbuchung;
import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Integrationstest mit eingebettetem Broker: @EmbeddedKafka startet einen KRaft-Broker in der Test-JVM,
 * spring.embedded.kafka.brokers enthält seine Adresse. Asynchrones wird mit Awaitility abgewartet, nie mit sleep.
 */
@SpringBootTest(classes = ConsumerApp.class, properties = {
        "app.replikation=1",
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "spring.kafka.consumer.auto-offset-reset=earliest",
        "spring.kafka.producer.value-serializer=org.springframework.kafka.support.serializer.JacksonJsonSerializer",
        "spring.kafka.producer.properties.spring.json.add.type.headers=false"
})
@EmbeddedKafka(partitions = 3, topics = "bestand.vertragsaenderungen")
class BestandsverwaltungIT {

    @Autowired KafkaTemplate<String, Object> kafka;
    @Autowired Bestand bestand;
    @Autowired Verbuchung verbuchung;

    @Test
    void aenderungenWerdenInReihenfolgeVerbuchtUndDuplikatErkannt() {
        kafka.send("bestand.vertragsaenderungen", "V-1001", aenderung(1, "ADRESSE"));
        kafka.send("bestand.vertragsaenderungen", "V-1001", aenderung(2, "BANKVERBINDUNG"));
        kafka.send("bestand.vertragsaenderungen", "V-1001", aenderung(2, "BANKVERBINDUNG"));   // Duplikat

        await().atMost(Duration.ofSeconds(15)).untilAsserted(() -> {
            assertThat(bestand.letzteVersion("V-1001")).isEqualTo(2);
            assertThat(verbuchung.duplikate()).isEqualTo(1);
        });
    }

    @Test
    void kaputtesJsonWirdUebersprungenUndDieNaechsteNachrichtVerarbeitet() {
        kafka.send("bestand.vertragsaenderungen", "V-2001", "das ist kein JSON");
        kafka.send("bestand.vertragsaenderungen", "V-2001", aenderung("V-2001", 1, "ADRESSE"));

        await().atMost(Duration.ofSeconds(15)).untilAsserted(() ->
                assertThat(bestand.letzteVersion("V-2001")).isEqualTo(1));
    }

    private static Vertragsaenderung aenderung(int version, String art) {
        return aenderung("V-1001", version, art);
    }

    private static Vertragsaenderung aenderung(String vertrag, int version, String art) {
        return new Vertragsaenderung(vertrag, version, art, Map.of(), Instant.now());
    }
}
