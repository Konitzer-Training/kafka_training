/** Kapitel 13: Dieses Modul enthält nur Tests – für die Fachlogik aus 08-consumer-json und die Topologien aus 11-streams. */
package de.konitzer.beispiele.tests;
