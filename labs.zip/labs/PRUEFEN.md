# Prüfen auf dem Dozentenrechner

Zwei Wege: von Hand (Abschnitt 1) oder mit Claude Code (Abschnitt 2, Prompt zum Kopieren).

Voraussetzungen: JDK 17 oder neuer (`java -version`), Docker Desktop läuft, das Lab aus `kafka-lab` läuft (`docker compose ps` zeigt kafka1–3, prometheus, grafana, alertmanager als Up). Maven ist nicht nötig, der Wrapper `mvnw.cmd` lädt es.

## 1. Von Hand

```powershell
cd labs
.\mvnw.cmd verify
```

Erwartet am Ende: `BUILD SUCCESS` und diese Zeilen (Reihenfolge kann abweichen):

| Modul | Tests |
| --- | --- |
| 02-producer-plain | `Tests run: 1` (Testcontainers) |
| 03-consumer-plain | `Tests run: 1` (Testcontainers) |
| 04-producer-spring | `Tests run: 1` |
| 05-consumer-spring | `Tests run: 1` |
| 06-consumer-groups | `Tests run: 1` |
| 07-producer-json | `Tests run: 4` – BestandssystemIT 3, BrokerNichtErreichbarIT 1 |
| 09a-fehlerbehandlung | `Tests run: 4` – AnhaltenIT 1, DeadLetterIT 3 |
| 09b-outbox | `Tests run: 2` |
| 09c-transaktionen | `Tests run: 1` |
| 11a-join-einfach | `Tests run: 1` (Surefire) |
| 11-streams | `Tests run: 4` (Surefire) |
| 13-tests | `Tests run: 2` (Surefire) und `Tests run: 3` (Failsafe) |
| 14-monitoring | `Tests run: 1` |
| 15-performance | `Tests run: 1` |
| 16-feldverschluesselung | `Tests run: 3` (Surefire) |
| 18-fallstudie | `Tests run: 1` |

Zusammen 33 Tests. Der erste Lauf lädt Abhängigkeiten und das Image `apache/kafka:4.4.0` (liegt vom Lab schon vor) – rechne mit 5–10 Minuten, danach etwa 5 Minuten.

Dann die Konsolen-Demos: Stufe 0 nach `01-shell/ANLEITUNG.md` und den Anleitungen in 02 bis 06; Stufe 2 nach den Anleitungen 07 bis 16; Fallstudie nach `18-fallstudie/ANLEITUNG.md`.

## 2. Mit Claude Code

Im Ordner `labs` eine Claude-Code-Sitzung starten und diesen Prompt geben:

```text
Prüfe das Projekt in diesem Ordner (labs) auf diesem Windows-Rechner. Ändere keinen Code, außer ich sage es. Berichte am Ende tabellarisch, was bestanden hat und was nicht, mit den genauen Fehlermeldungen.

1. Umgebung: java -version, docker compose ps im Ordner kafka-lab (kafka1, kafka2, kafka3, prometheus, grafana, alertmanager müssen Up sein). Falls nicht, sage es und stoppe.

2. Build und Tests: .\mvnw.cmd verify im Ordner labs. Vergleiche die "Tests run"-Zeilen mit der Tabelle in PRUEFEN.md, Abschnitt 1. Jede Abweichung ist ein Befund.

3. Konsolen-Demos gegen den Lab-Cluster, nacheinander, jede höchstens 60 Sekunden laufen lassen, dann beenden. Die JARs liegen unter <modul>\target\<modul>-app.jar. Kafka-Befehle laufen im Container: docker exec kafka1 /opt/kafka/bin/<befehl> --bootstrap-server kafka1:9092 …
   0) Vorher aufräumen: Diese Topics löschen, falls vorhanden: beitraege, antraege, pruefungen, policen, perf, bestand.vertragsaenderungen, bestand.vertragsaenderungen.fehler, bestand.vertragsaenderungen.fehler-dlt, bestand.vertragsaenderungen.fehler2, bestand.vertragsaenderungen.fehler2-dlt, dokumente.erzeugen (plus -retry-1000, -retry-2000, -retry-4000, -dlt), schaden.meldungen, schaden.reserven, kunden.stammdaten, bestand.vertragsaenderungen.angereichert, schaden.anzahl-je-vertrag, schaden.auffaelligkeiten, bestand.vertragsaenderungen.sicher sowie alle Topics mit Präfix streams-beispiele- und join-einfach-. Die Apps legen ihre Topics beim Start neu an.

   Stufe 0 (Shell → Java):
   a) .\01-shell\01-topic-anlegen.ps1 – erwartet "Created topic beitraege".
   b) 02-producer-plain-app.jar mit Argumenten "V-1001:Beitrag 42,50" "V-1002:Beitrag 19,90" "V-1001:Beitrag 44,00". Erwartet: drei Zeilen "gesendet … Partition n, Offset m"; beide V-1001 in derselben Partition, Offsets 0 und 1.
   c) 03-consumer-plain-app.jar, 10 Sekunden. Erwartet: die drei Nachrichten als "P<n> @<m> key=… wert". Dann docker exec … kafka-consumer-groups.sh --describe --group beitragsrechner-plain: CURRENT-OFFSET gesetzt, LAG 0.
   d) 04-producer-spring-app.jar ohne Argumente. Erwartet: fünf "gesendet"-Zeilen, V-1001 und V-1002 je zweimal in derselben Partition.
   e) 05-consumer-spring-app.jar, 12 Sekunden. Erwartet: acht Zeilen "P<n> @<m> key=…" (drei aus b plus fünf aus d). Gruppe beitragsrechner-spring existiert danach.
   f) 06-consumer-groups-app.jar --app.threads=3 --app.von-anfang=true, 12 Sekunden. Erwartet: "ZUGEWIESEN" mit beitraege-0, -1, -2, "von Anfang: Leseposition auf 0 gesetzt", dann alle acht Nachrichten mit "(Nr. k aus dieser Partition)". Währenddessen oder danach: kafka-consumer-groups.sh --describe --group beitragsrechner zeigt drei Partitionen.
   g) 11a-join-einfach-app.jar im Hintergrund; dann 04-producer-spring-app.jar --app.topic=antraege "V-2001:Antrag KFZ" und 04-producer-spring-app.jar --app.topic=pruefungen "V-2001:geprüft ok". Erwartet im Join: "Antrag … wartet", "Prüfung … wartet", "ZUSAMMEN key=V-2001 Police aus …".

   Stufe 2:
   h) 08-consumer-json-app.jar im Hintergrund starten; dann 07-producer-json-app.jar. Erwartet: Producer meldet 8 Nachrichten mit Partition und Offset, Consumer meldet ZUGEWIESEN und 8-mal VERBUCHT.
   i) 09a-fehlerbehandlung-app.jar, etwa 40 Sekunden. Erwartet: "Versuch 1 fehlgeschlagen" für V-1001, dann ANHALTEN; "V-1002 v1 BEITRAG verbucht (Versuch 3)"; für KAPUTT mehrere "Vorlage kaputt"-Zeilen und zuletzt "DLT: Dokument KAPUTT … endgültig nicht erzeugbar". V-1001 v3 darf NICHT verbucht werden.
   j) 09a noch einmal mit --app.recoverer=dlt --app.topic=bestand.vertragsaenderungen.fehler2. Erwartet: V-1001 v3 wird verbucht, v2 liegt in bestand.vertragsaenderungen.fehler2-dlt (kafka-console-consumer.sh --from-beginning --max-messages 1 --timeout-ms 10000).
   k) 09b-outbox-app.jar. Erwartet: zwei "Outbox -> Kafka"-Zeilen für V-1001, die Rollback-Zeile für V-1002, "ungesendet: 0".
   l) 09c-transaktionen-app.jar. Erwartet: Reserven für S-5001 (1800.00) und S-5003 (300.00); S-5002 dreimal Fehlversuch und "ÜBERSPRUNGEN". Dann kafka-console-consumer.sh auf schaden.reserven mit --isolation-level read_committed (2 Nachrichten) und read_uncommitted (5), je --from-beginning --timeout-ms 10000.
   m) 11-streams-app.jar. Erwartet innerhalb von 20 Sekunden: POLICE für V-2001, ANGEREICHERT für K-100 mit "Erika Mustermann", SCHAEDEN 1, 2, 3 für V-1001, AUFFAELLIG für V-1001.
   n) 14-monitoring-app.jar im Hintergrund, nach 15 Sekunden: curl.exe -s http://localhost:8085/actuator/prometheus | findstr "beitraege_verbuchungen_total records_lag_max". Erwartet: drei Zähler-Zeilen (verbucht 8.0 nach den Nachrichten aus b und d, duplikat 0.0, fehler 0.0 – oder verbucht 0.0, wenn die Gruppe beitragsrechner-monitoring schon alles gelesen hatte) und eine kafka_consumer_fetch_manager_records_lag_max-Zeile. Dann bash 14-monitoring/shell/04-promql.sh (Git Bash) oder in PowerShell: curl.exe -s --get http://localhost:9090/api/v1/query --data-urlencode "query=sum(kafka_server_replicamanager_underreplicatedpartitions)" – erwartet Wert 0.
   o) 15-performance-app.jar --app.anzahl=20000, danach dasselbe mit --spring.kafka.producer.properties.linger.ms=100 --spring.kafka.producer.batch-size=100000 --spring.kafka.producer.compression-type=lz4. Erwartet: beide "Fehler: 0", der zweite Lauf deutlich mehr Nachrichten/s.
   p) 16-feldverschluesselung-app.jar. Erwartet: "empfangen V-1001 v1 BANKVERBINDUNG iban=DE02120300000000202051 (Header dek-id=kunde-K-100)". Danach kafka-console-consumer.sh auf bestand.vertragsaenderungen.sicher --from-beginning --timeout-ms 10000: Die IBAN darf dort NICHT im Klartext stehen.
   q) 18-fallstudie-app.jar im Hintergrund, nach 20 Sekunden: curl.exe -X POST "http://localhost:8081/api/quelle/last?anzahl=100&proSekunde=200". Erwartet: {"gestartet":true}; im Log der App "verbucht"-Zeilen; http://localhost:8081 zeigt die Seite.

4. Aufräumen: Alle gestarteten Java-Prozesse beenden. Die Topics stehen lassen.

Hinweise: Wenn ein Port-Konflikt (8081, 8085) oder ein Rebalance länger als 30 Sekunden dauert, warte und versuche es einmal erneut, bevor du es als Befund meldest. Die .sh-Skripte brauchen Git Bash; in PowerShell die .ps1-Varianten in 01-shell nehmen, für 14/15/19 die docker-exec-Zeile aus dem Skript kopieren.
```
