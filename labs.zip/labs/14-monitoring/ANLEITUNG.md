# 14-monitoring – Arbeitsanweisung

**Was es zeigt:** Was im Seminar mit Grafana, Prometheus und `kafka-jmx.sh` von außen zu sehen war, jetzt aus der eigenen Anwendung: Spring Boot liefert die Kafka-Client-Metriken (Lag, Fetch, Commit) ohne eine Zeile Code an `/actuator/prometheus`; dazu kommen eigene fachliche Zähler (`Verbuchungsmetriken`, Buch Kapitel 14). Die Shell-Skripte in `shell/` sind die Monitoring-Befehle aus Tag 2.

**Buch:** Kapitel 14 (Monitoring und Alerting), Cheat-Sheet.

## Teil A: Cluster lesen (Shell, 10 Minuten)

| Skript | Zeigt |
| --- | --- |
| `shell/01-gesundheit.sh` | unterreplizierte, unter-min-ISR und leaderlose Partitionen, KRaft-Quorum |
| `shell/02-jmx.sh` | eine Metrik roh per JMX, ohne Prometheus |
| `shell/03-leader.sh` | Preferred Leader Election nach einem Broker-Neustart |
| `shell/04-promql.sh` | die PromQL-Zeilen aus dem Seminar per API |
| `shell/05-alerts.sh` | Zustand aller Alert-Regeln und was im Alertmanager liegt |
| `shell/06-regeln-neu-laden.sh` | Prometheus nach Änderung an `rules.yml` neu laden |
| `shell/07-lag-erzeugen.sh` | Quelle mit 100 Nachrichten/s gegen einen Consumer mit 50/s |
| `shell/08-metriken-ansehen.sh` (auch `.ps1`) | die Metriken der Folie „Woran sehe ich das im Betrieb?“ aus Deck 04 in einem Lauf: Broker-Werte per `kafka-jmx.sh`, Lag und Gruppenstatus per `kafka-consumer-groups.sh`, Client-Metriken vom Shell-Consumer (Port 9211) oder der Spring-App (8085) |

Ablauf: `01-gesundheit` (alles leer), `docker stop kafka3`, `01-gesundheit` erneut, Grafana „Kafka Broker“ anschauen, `docker start kafka3`, `03-leader`, `05-alerts` (UnderReplicatedPartitions war `pending`, jetzt `inactive`).

Windows ohne Bash: Die Befehle in den Skripten sind einzelne `docker exec`- und `curl`-Zeilen und laufen genauso in PowerShell (`curl.exe` statt `curl`, `python` statt `python3`).

## Teil B: Metriken aus der App (10 Minuten)

1. App starten:
   ```powershell
   java -jar 14-monitoring\target\14-monitoring-app.jar --app.dauer-ms=200
   ```
2. Im Browser: http://localhost:8085/actuator/prometheus. Suchen nach `records_lag_max`, `beitraege_verbuchungen_total`, `rebalance_total`.
3. Producer in Automatik mit 10 Nachrichten/s, der Consumer schafft 5/s:
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.automatisch=true --app.intervall-ms=100
   ```
4. Endpunkt neu laden: `kafka_consumer_fetch_manager_records_lag_max` steigt. Dasselbe mit `01-shell\06-gruppe-ansehen.ps1 -Gruppe beitragsrechner-monitoring` als `LAG`.
5. Prometheus holt die App ab (Job `spring-apps` in `kafka-lab/prometheus/prometheus.yml`, Ziel `host.docker.internal:8085`). In Prometheus: `max by (client_id) (kafka_consumer_records_lag_max)` zeigt jetzt `monitoring-1` neben den Shell-Clients. Das Relabeling in der Prometheus-Config macht aus den Micrometer-Namen die Namen des JMX-Exporters, damit Dashboard und Alert beide bedienen.
6. Nach einer Minute über 1000 Lag (mit `for: 1m` in `rules.yml`): `shell/05-alerts.sh` zeigt `ConsumerLagHigh firing`.

## Aufgaben

1. Ergänzen Sie in `Verbuchungsmetriken` ein `Gauge` für die Größe des Bestands (`registry.gauge("beitraege.bestand.groesse", bestand, Map::size)`). Wo steht es im Endpunkt?
2. Lassen Sie `verarbeite` bei `Beitrag 99,00` eine Exception werfen und zählen Sie sie als `fehler`. Welche Kafka-Metrik ändert sich **zusätzlich**, wenn Spring die Nachricht wiederholt?
3. Schreiben Sie in `rules.yml` einen Alert `KeineVerbuchungen`: `rate(beitraege_verbuchungen_total[5m]) == 0` für 5 Minuten. Laden Sie neu (`06-regeln-neu-laden`) und prüfen Sie mit `05-alerts`. Warum ist das ein besserer Alert als „Lag > 1000“, wenn der Consumer ganz steht?

## Ändern und bauen

- **IntelliJ:** `14-monitoring → MonitoringApp → main`. Der Endpunkt läuft dann ebenfalls auf 8085.
- **Bauen:** `.\mvnw.cmd -pl 14-monitoring -am package -DskipTests`
- **Mit Test** (EmbeddedKafka plus HTTP-Aufruf des Endpunkts, ca. 20 Sekunden): `.\mvnw.cmd -pl 14-monitoring -am verify`
- Zweite Instanz: `--server.port=8086 --spring.kafka.consumer.client-id=monitoring-2`. Beide teilen sich die Gruppe; im Endpunkt jeder Instanz steht nur ihr eigener Lag.
