package de.konitzer.beispiele.monitoring;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;

/** Der Prometheus-Endpunkt zeigt die Kafka-Client-Metriken und unsere eigenen Zähler. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}")
@EmbeddedKafka(partitions = 3, topics = "beitraege")
class MetrikenIT {

    @Autowired EmbeddedKafkaBroker broker;
    @Autowired Verbuchungsmetriken metriken;
    @Autowired Environment env;

    // Spring Boot 4: TestRestTemplate liegt in einem eigenen Modul; RestClient aus spring-web reicht hier
    private RestClient http() {
        return RestClient.create("http://localhost:" + env.getProperty("local.server.port"));
    }

    @Test
    void zaehlerUndClientMetrikenStehenImPrometheusEndpunkt() {
        var props = KafkaTestUtils.producerProps(broker);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        try (var producer = new KafkaProducer<String, String>(props)) {
            producer.send(new ProducerRecord<>("beitraege", "V-1001", "Beitrag 42,50"));
            producer.send(new ProducerRecord<>("beitraege", "V-1001", "Beitrag 42,50"));   // Duplikat
            producer.send(new ProducerRecord<>("beitraege", "V-1002", "Beitrag 19,90"));
            producer.flush();
        }
        await().atMost(Duration.ofSeconds(10)).untilAsserted(() -> {
            assertThat(metriken.anzahlVerbucht()).isEqualTo(2);
            assertThat(metriken.anzahlDuplikate()).isEqualTo(1);
        });

        String text = http().get().uri("/actuator/prometheus").retrieve().body(String.class);
        assertThat(text)
                .contains("beitraege_verbuchungen_total{")
                .contains("ergebnis=\"verbucht\"")
                .contains("beitraege_verbuchung_dauer_seconds_count")
                // Kafka-Client-Metrik, von Spring Boot automatisch eingebunden
                .contains("kafka_consumer_fetch_manager_records_lag_max{");
    }
}
