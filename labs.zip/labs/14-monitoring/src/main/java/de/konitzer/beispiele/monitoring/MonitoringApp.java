package de.konitzer.beispiele.monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Consumer mit Metriken. Nach dem Start:
 *   http://localhost:8085/actuator/prometheus   – alle Metriken im Prometheus-Textformat
 *   http://localhost:8085/actuator/metrics/kafka.consumer.fetch.manager.records.lag.max – eine einzelne
 *
 * Was Spring Boot automatisch liefert (ohne eine Zeile Code):
 *  - kafka_consumer_fetch_manager_records_lag_max   Lag dieses Consumers (Buch Tabelle 15.4)
 *  - kafka_consumer_fetch_manager_records_consumed_total, _fetch_latency_avg, …
 *  - kafka_consumer_coordinator_commit_latency_avg, _rebalance_total, …
 *  - jvm_*, process_*, system_cpu_usage, …
 * Dazu kommen unsere eigenen Zähler aus Verbuchungsmetriken.
 *
 * Starten:  java -jar target/14-monitoring-app.jar          (Strg+C beendet)
 *           --app.dauer-ms=200   langsam verarbeiten, damit Lag entsteht
 */
@SpringBootApplication
public class MonitoringApp {

    public static void main(String[] args) {
        SpringApplication.run(MonitoringApp.class, args);
    }
}
