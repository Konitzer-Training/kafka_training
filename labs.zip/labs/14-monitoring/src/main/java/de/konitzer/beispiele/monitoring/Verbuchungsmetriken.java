package de.konitzer.beispiele.monitoring;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.stereotype.Component;

/**
 * Eigene, fachliche Metriken (Buch Kapitel 14 "Metriken aus der Anwendung").
 *
 * Die Kafka-Client-Metriken sagen, WIE VIEL gelesen wird. Sie sagen nicht, ob die Verarbeitung
 * fachlich gut ging. Dafür zählen wir selbst: verbucht, Duplikat, Fehler – und wie lange eine
 * Verbuchung dauert. In Prometheus heißen sie dann
 *   beitraege_verbuchungen_total{ergebnis="verbucht"}
 *   beitraege_verbuchungen_total{ergebnis="duplikat"}
 *   beitraege_verbuchung_dauer_seconds_{count,sum,max}
 *
 * MeterRegistry ist die zentrale Sammelstelle von Micrometer; Spring Boot stellt sie bereit und
 * hängt den Prometheus-Endpunkt dran.
 */
@Component
public class Verbuchungsmetriken {

    private final Counter verbucht;
    private final Counter duplikate;
    private final Counter fehler;
    private final Timer dauer;

    public Verbuchungsmetriken(MeterRegistry registry) {
        // Gleicher Name, verschiedener Tag "ergebnis": In PromQL lässt sich so summieren oder filtern
        verbucht = registry.counter("beitraege.verbuchungen", "ergebnis", "verbucht");
        duplikate = registry.counter("beitraege.verbuchungen", "ergebnis", "duplikat");
        fehler = registry.counter("beitraege.verbuchungen", "ergebnis", "fehler");
        dauer = registry.timer("beitraege.verbuchung.dauer");
    }

    public void verbucht() { verbucht.increment(); }
    public void duplikat() { duplikate.increment(); }
    public void fehler() { fehler.increment(); }
    public Timer dauer() { return dauer; }

    // Für den Test
    public double anzahlVerbucht() { return verbucht.count(); }
    public double anzahlDuplikate() { return duplikate.count(); }
}
