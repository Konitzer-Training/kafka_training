package de.konitzer.beispiele.monitoring;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Der Listener aus 05, mit zwei Ergänzungen: Er erkennt Duplikate (gleicher Vertrag, gleicher
 * Wert wie zuletzt) und meldet jedes Ergebnis an die Verbuchungsmetriken.
 */
@Component
public class Beitragsverarbeitung {

    private static final Logger log = LoggerFactory.getLogger(Beitragsverarbeitung.class);

    private final Verbuchungsmetriken metriken;
    private final long dauerMs;
    // letzter Wert je Vertrag – reicht hier als "Bestand"
    private final Map<String, String> bestand = new ConcurrentHashMap<>();

    public Beitragsverarbeitung(Verbuchungsmetriken metriken, @Value("${app.dauer-ms}") long dauerMs) {
        this.metriken = metriken;
        this.dauerMs = dauerMs;
    }

    @KafkaListener(id = "beitraege", idIsGroup = false, topics = "${app.topic}")
    public void verarbeite(ConsumerRecord<String, String> nachricht) {
        // Timer.record misst, wie lange der Block dauert – landet im Histogramm beitraege_verbuchung_dauer
        metriken.dauer().record(() -> {
            if (dauerMs > 0) {
                try { Thread.sleep(dauerMs); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
            String vorher = bestand.put(nachricht.key(), nachricht.value());
            if (nachricht.value().equals(vorher)) {
                metriken.duplikat();
                log.info("P{} @{} key={} {}  -> DUPLIKAT", nachricht.partition(), nachricht.offset(), nachricht.key(), nachricht.value());
            } else {
                metriken.verbucht();
                log.info("P{} @{} key={} {}  -> verbucht", nachricht.partition(), nachricht.offset(), nachricht.key(), nachricht.value());
            }
        });
    }
}
