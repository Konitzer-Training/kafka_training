# Aufruf in PowerShell:  .\08-metriken-ansehen.ps1   (optional -Gruppe name)
# 08 – Die Metriken der Folie "Woran sehe ich das im Betrieb?" (Deck 04) in einem Lauf
#
# Zwei Orte: Broker-Metriken liegen im Broker (JMX, Port 9999) und sind immer da.
# Client-Metriken (records-lag-max, Rebalances) liegen im Consumer-PROZESS und sind nur da,
# solange er läuft und sie herausgibt (Shell: mit-metriken auf Port 9211; Spring: Actuator 8085).

param([string]$Gruppe = "beitragsrechner")

$JMX = "--jmx-url", "service:jmx:rmi:///jndi/rmi://kafka1:9999/jmxrmi", "--one-time", "true"

Write-Host "== Broker: UnderReplicatedPartitions (Soll 0)"
docker exec kafka1 /opt/kafka/bin/kafka-jmx.sh @JMX --object-name kafka.server:type=ReplicaManager,name=UnderReplicatedPartitions | Select-Object -Last 1
Write-Host "== Broker: UnderMinIsrPartitionCount (Soll 0)"
docker exec kafka1 /opt/kafka/bin/kafka-jmx.sh @JMX --object-name kafka.server:type=ReplicaManager,name=UnderMinIsrPartitionCount | Select-Object -Last 1
Write-Host "== Broker: IsrShrinksPerSec, OneMinuteRate (Soll 0 ausser bei Ausfaellen)"
docker exec kafka1 /opt/kafka/bin/kafka-jmx.sh @JMX --object-name kafka.server:type=ReplicaManager,name=IsrShrinksPerSec --attributes OneMinuteRate | Select-Object -Last 1
Write-Host "== Broker: betroffene Partitionen als Liste"
docker exec kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-replicated-partitions
docker exec kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-min-isr-partitions

Write-Host "== Gruppe $Gruppe : Lag von aussen (aus den Commits, auch ohne laufenden Consumer)"
docker exec kafka1 /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group $Gruppe
Write-Host "== Gruppe $Gruppe : Status und Mitglieder"
docker exec kafka1 /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group $Gruppe --state
docker exec kafka1 /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group $Gruppe --members

Write-Host "== Client: records-lag-max und Rebalances - nur sichtbar, wenn ein Consumer sie herausgibt"
Write-Host "   Shell-Consumer mit Metriken: bash /opt/lab/bin/mit-metriken 9211 kafka-console-consumer.sh ... --group $Gruppe"
docker exec kafka1 curl -s kafka1:9211/metrics 2>$null | Select-String "^kafka_consumer_(records_lag_max|coordinator_rebalance)" | Select-Object -First 5
Write-Host "   Spring-App 14-monitoring (Port 8085):"
try { (Invoke-WebRequest -UseBasicParsing http://localhost:8085/actuator/prometheus).Content -split "`n" | Select-String "^kafka_consumer_(fetch_manager_records_lag_max|coordinator_rebalance_total)" | Select-Object -First 5 } catch { Write-Host "   (14-monitoring laeuft nicht)" }
