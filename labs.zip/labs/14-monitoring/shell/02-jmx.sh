#!/usr/bin/env bash
# 02 – Eine Metrik direkt per JMX lesen, ohne Prometheus (Soll: 0)
#
# Alles, was Prometheus im Lab sieht, holt der JMX-Exporter aus diesen MBeans. kafka-jmx.sh zeigt
# den Rohwert; der Name hier ist derselbe wie in Grafana (kafka_server_replicamanager_underreplicatedpartitions).

docker exec -it kafka1 /opt/kafka/bin/kafka-jmx.sh \
    --jmx-url service:jmx:rmi:///jndi/rmi://kafka1:9999/jmxrmi \
    --object-name kafka.server:type=ReplicaManager,name=UnderReplicatedPartitions \
    --one-time true

# Weitere Kandidaten (--object-name):
#   kafka.controller:type=KafkaController,name=ActiveControllerCount
#   kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec
#   kafka.server:type=KafkaRequestHandlerPool,name=RequestHandlerAvgIdlePercent

# ---- Varianten für die Vorführung ----
# Laufend, alle 3 Sekunden, zwei Attribute (Strg+C beendet); daneben einen Producer laufen lassen:
#   docker exec -it kafka1 /opt/kafka/bin/kafka-jmx.sh \
#       --jmx-url service:jmx:rmi:///jndi/rmi://kafka1:9999/jmxrmi \
#       --object-name kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec \
#       --attributes Count,OneMinuteRate --reporting-interval 3000
#
# Dieselbe Metrik nach der Übersetzung durch den JMX-Exporter (Port 9101 ist zum Host gemappt):
#   curl -s http://localhost:9101/metrics | grep underreplicated
#
# Client-Metriken ohne Prometheus: jconsole (aus dem JDK) starten, den lokalen Java-Prozess
# der App wählen (Attach, kein Port nötig), MBeans -> kafka.consumer -> consumer-fetch-manager-metrics.
