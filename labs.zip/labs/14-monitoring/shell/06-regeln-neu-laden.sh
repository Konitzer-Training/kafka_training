#!/usr/bin/env bash
# 06 – Prometheus-Regeln neu laden, nachdem kafka-lab/prometheus/rules.yml geändert wurde
# (PowerShell: curl.exe -X POST http://localhost:9090/-/reload)
curl -X POST http://localhost:9090/-/reload && echo "neu geladen"
