#!/usr/bin/env bash
# 07 – Lag erzeugen wie im Seminar (Abschnitt 8): Quelle mit 100 Nachrichten/s, Consumer schafft 50/s
#
# Fenster 1: dieses Skript (Producer im Container, Metriken auf Port 9201)
# Fenster 2: bash /opt/lab/bin/bestandsverwaltung 1   (im Container)  – oder die Spring-App:
#            java -jar 14-monitoring/target/14-monitoring-app.jar --app.topic=bestand.aenderungen --app.dauer-ms=20
# Fenster 3: 01-shell/06-gruppe-ansehen.sh bestand   bzw.  ... beitragsrechner-monitoring
# Grafana: records-lag-max steigt; nach 1 min über 1000: Alert ConsumerLagHigh (05-alerts.sh)

TOPIC=${1:-bestand.aenderungen}

docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 \
    --create --if-not-exists --topic "$TOPIC" --partitions 6 --replication-factor 3

docker exec -it kafka1 bash /opt/lab/bin/mit-metriken 9201 kafka-producer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic "$TOPIC" \
    --num-records 100000 --record-size 500 --throughput 100 \
    --record-key-range 1000 --key-distribution random \
    --command-property client.id=quelle
