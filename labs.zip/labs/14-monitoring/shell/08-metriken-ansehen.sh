#!/usr/bin/env bash
# 08 – Die Metriken der Folie "Woran sehe ich das im Betrieb?" (Deck 04) in einem Lauf
#
# Zwei Orte: Broker-Metriken liegen im Broker (JMX, Port 9999) und sind immer da.
# Client-Metriken (records-lag-max, Rebalances) liegen im Consumer-PROZESS und sind nur da,
# solange er läuft und sie herausgibt (Shell: mit-metriken auf Port 9211; Spring: Actuator 8085).

GRUPPE=${1:-beitragsrechner}
B="docker exec -i kafka1 /opt/kafka/bin"
JMX="--jmx-url service:jmx:rmi:///jndi/rmi://kafka1:9999/jmxrmi --one-time true"

echo "== Broker: UnderReplicatedPartitions (Soll 0)"
$B/kafka-jmx.sh $JMX --object-name kafka.server:type=ReplicaManager,name=UnderReplicatedPartitions 2>/dev/null | tail -1
echo "== Broker: UnderMinIsrPartitionCount (Soll 0)"
$B/kafka-jmx.sh $JMX --object-name kafka.server:type=ReplicaManager,name=UnderMinIsrPartitionCount 2>/dev/null | tail -1
echo "== Broker: IsrShrinksPerSec, OneMinuteRate (Soll 0 außer bei Ausfällen)"
$B/kafka-jmx.sh $JMX --object-name kafka.server:type=ReplicaManager,name=IsrShrinksPerSec --attributes OneMinuteRate 2>/dev/null | tail -1
echo "== Broker: betroffene Partitionen als Liste"
$B/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-replicated-partitions
$B/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-min-isr-partitions

echo "== Gruppe $GRUPPE: Lag von außen (aus den Commits, auch ohne laufenden Consumer)"
$B/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group "$GRUPPE" 2>/dev/null
echo "== Gruppe $GRUPPE: Status (Stable, PreparingRebalance, Empty, Dead) und Mitglieder"
$B/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group "$GRUPPE" --state 2>/dev/null
$B/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 --describe --group "$GRUPPE" --members 2>/dev/null

echo "== Client: records-lag-max und Rebalances – nur sichtbar, wenn ein Consumer sie herausgibt"
echo "   Shell-Consumer mit Metriken: bash /opt/lab/bin/mit-metriken 9211 kafka-console-consumer.sh ... --group $GRUPPE"
docker exec -i kafka1 curl -s kafka1:9211/metrics 2>/dev/null | grep -E "^kafka_consumer_(records_lag_max|coordinator_rebalance)" | head -5 || true
echo "   Spring-App 14-monitoring (Port 8085):"
curl -s localhost:8085/actuator/prometheus 2>/dev/null | grep -E "^kafka_consumer_(fetch_manager_records_lag_max|coordinator_rebalance_total)" | head -5 || echo "   (14-monitoring läuft nicht)"
