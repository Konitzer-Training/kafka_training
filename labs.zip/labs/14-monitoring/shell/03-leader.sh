#!/usr/bin/env bash
# 03 – Leader wieder gleichmäßig verteilen (nach einem Broker-Neustart)
# Dashboard: PreferredReplicaImbalance geht auf 0; Alert LeaderImbalance verschwindet.

docker exec -it kafka1 /opt/kafka/bin/kafka-leader-election.sh \
    --bootstrap-server kafka1:9092 \
    --election-type preferred \
    --all-topic-partitions
