#!/usr/bin/env bash
# 04 – PromQL-Abfragen gegen das Lab-Prometheus (http://localhost:9090), ohne Browser
#
# Jede Abfrage ist eine Zeile aus dem Seminar. Die HTTP-API liefert JSON; python3 kürzt es auf
# Metrik + Wert. Dieselben Ausdrücke kann man in Prometheus → Graph oder in Grafana eintragen.

frage() {
    echo "== $1"
    curl -s --get http://localhost:9090/api/v1/query --data-urlencode "query=$1" \
      | python3 -c 'import json,sys
text = sys.stdin.read()
if not text:
    print("   Prometheus unter localhost:9090 nicht erreichbar"); sys.exit()
ergebnis = json.loads(text)["data"]["result"]
if not ergebnis:
    print("   (keine Werte – Metrik fehlt oder kein Client aktiv)")
for r in ergebnis:
    labels = {k: v for k, v in r["metric"].items() if k in ("instance", "broker", "client_id", "topic", "ergebnis")}
    print("  ", labels, r["value"][1])'
}

frage 'sum(kafka_server_replicamanager_underreplicatedpartitions)'          # Soll 0
frage 'sum(kafka_controller_kafkacontroller_activecontrollercount)'         # Soll 1
frage 'sum by (instance) (rate(kafka_server_brokertopicmetrics_bytesin_total[1m]))'   # Last je Broker
frage 'min(kafka_server_kafkarequesthandlerpool_requesthandleravgidlepercent)'        # Soll > 0.3
frage 'max by (client_id) (kafka_consumer_records_lag_max)'                 # Lag je Consumer (Shell-Clients, Spring-Apps)
frage 'sum by (ergebnis) (beitraege_verbuchungen_total)'                    # unsere Zähler aus 14-monitoring
