#!/usr/bin/env bash
# 01 – Gesundheitscheck per CLI (Buch 14.2, Cheat-Sheet). Alle drei Listen sollen leer sein.

B="docker exec -it kafka1 /opt/kafka/bin"

echo "== Unterrepliziert (ISR kleiner als Replicas) – Alert UnderReplicatedPartitions"
$B/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-replicated-partitions

echo "== Unter min.insync.replicas – acks=all-Producer blockiert – Alert UnderMinIsr"
$B/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --under-min-isr-partitions

echo "== Ohne Leader (nicht lesbar, nicht schreibbar)"
$B/kafka-topics.sh --bootstrap-server kafka1:9092 --describe --unavailable-partitions

echo "== KRaft-Quorum: Leader, Voter, Observer"
$B/kafka-metadata-quorum.sh --bootstrap-server kafka1:9092 describe --status

# Probieren: docker stop kafka3 – dann liefert die erste Liste alle Partitionen mit Kopie auf Broker 3.
# docker start kafka3, danach bleibt Broker 3 nirgends Leader: kafka-leader-election.sh (03-leader.sh)
