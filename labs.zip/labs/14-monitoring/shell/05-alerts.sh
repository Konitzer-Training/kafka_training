#!/usr/bin/env bash
# 05 – Welche Alerts sind gerade aktiv? (Prometheus und Alertmanager)
#
# Die Regeln stehen in kafka-lab/prometheus/rules.yml. Für die Demo dort bei ConsumerLagHigh
# "for: 10m" auf "for: 1m" setzen und mit 06-regeln-neu-laden.sh aktivieren.

echo "== Prometheus: Regeln mit Zustand (inactive / pending / firing)"
curl -s http://localhost:9090/api/v1/rules | python3 -c 'import json,sys
text = sys.stdin.read()
if not text:
    print("   Prometheus unter localhost:9090 nicht erreichbar"); sys.exit()
for g in json.loads(text)["data"]["groups"]:
    for r in g["rules"]:
        if r["type"] == "alerting":
            print("   %-9s %s" % (r["state"], r["name"]))'

echo "== Alertmanager: zugestellte Alerts"
curl -s http://localhost:9093/api/v2/alerts | python3 -c 'import json,sys
text = sys.stdin.read()
if not text:
    print("   Alertmanager unter localhost:9093 nicht erreichbar"); sys.exit()
alerts = json.loads(text)
if not alerts:
    print("   (keine aktiven Alerts)")
for a in alerts:
    print("  ", a["labels"].get("alertname"), a["labels"].get("severity"), a["annotations"].get("summary"))'
