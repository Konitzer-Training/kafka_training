package de.konitzer.beispiele.performance;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * kafka-producer-perf-test.sh als Spring-Boot-Programm: n Nachrichten fester Größe so schnell wie
 * möglich senden und messen, wie viele pro Sekunde durchgehen. Der Sinn ist der VERGLEICH:
 * dieselbe App mit anderen Werten für linger.ms, batch.size, compression.type, acks.
 *
 *   java -jar target/15-performance-app.jar
 *   java -jar target/15-performance-app.jar --spring.kafka.producer.properties.linger.ms=100 \
 *        --spring.kafka.producer.batch-size=100000 --spring.kafka.producer.compression-type=lz4
 *   java -jar target/15-performance-app.jar --spring.kafka.producer.acks=1
 *
 * Die Zahlen sind von Rechner, Docker und Platte abhängig – es zählt der Unterschied zwischen zwei Läufen.
 */
@SpringBootApplication
public class LasttestApp {

    public static void main(String[] args) {
        SpringApplication.run(LasttestApp.class, args);
    }

    @Bean
    NewTopic perfTopic(@Value("${app.topic}") String name, @Value("${app.partitionen}") int partitionen,
                       @Value("${app.replikation}") short replikation) {
        return TopicBuilder.name(name).partitions(partitionen).replicas(replikation).build();
    }

    @Bean
    CommandLineRunner lasttest(KafkaTemplate<String, String> kafka,
                               @Value("${app.topic}") String topic,
                               @Value("${app.anzahl}") int anzahl,
                               @Value("${app.groesse}") int groesse,
                               @Value("${app.keys}") int keys,
                               @Value("${spring.kafka.producer.properties.linger.ms}") String linger,
                               @Value("${spring.kafka.producer.batch-size}") String batch,
                               @Value("${spring.kafka.producer.compression-type}") String kompression,
                               @Value("${spring.kafka.producer.acks}") String acks) {
        return args -> {
            System.out.printf("Lasttest: %d Nachrichten à %d Byte, %d Keys -> %s%n", anzahl, groesse, keys, topic);
            System.out.printf("Einstellungen: linger.ms=%s batch.size=%s compression=%s acks=%s%n", linger, batch, kompression, acks);

            Ergebnis e = sende(kafka, topic, anzahl, groesse, keys);
            System.out.printf("%n%d Nachrichten in %.1f s = %.0f Nachrichten/s, %.1f MB/s, Fehler: %d%n",
                    anzahl, e.sekunden(), e.proSekunde(), e.mbProSekunde(groesse), e.fehler());
        };
    }

    /** Alle Nachrichten absetzen, dann auf alle Bestätigungen warten. Gibt die Messwerte zurück. */
    static Ergebnis sende(KafkaTemplate<String, String> kafka, String topic, int anzahl, int groesse, int keys) {
        // Nutzlast: ein fester Text der gewünschten Länge. Zufallsdaten ließen sich nicht komprimieren –
        // kafka-producer-perf-test.sh nimmt deshalb ebenfalls wiederholbare Bytes.
        char[] zeichen = new char[groesse];
        Arrays.fill(zeichen, 'x');
        String nutzlast = new String(zeichen);

        AtomicLong fehler = new AtomicLong();
        long start = System.nanoTime();
        @SuppressWarnings("unchecked")
        CompletableFuture<Void>[] offen = new CompletableFuture[anzahl];
        for (int i = 0; i < anzahl; i++) {
            // Mit Keys verteilt der Hash die Nachrichten, ohne Key der Sticky Partitioner (ganze Batches je Partition)
            String key = keys > 0 ? "K-" + (i % keys) : null;
            // send() blockiert nur, wenn der Puffer (buffer.memory) voll ist – sonst sammelt es
            offen[i] = kafka.send(topic, key, nutzlast)
                    .handle((meta, fehlerBeimSenden) -> {
                        if (fehlerBeimSenden != null) fehler.incrementAndGet();
                        return null;
                    });
        }
        kafka.flush();
        CompletableFuture.allOf(offen).join();
        double sekunden = (System.nanoTime() - start) / 1_000_000_000.0;
        return new Ergebnis(anzahl, sekunden, fehler.get());
    }

    record Ergebnis(int anzahl, double sekunden, long fehler) {
        double proSekunde() { return anzahl / sekunden; }
        double mbProSekunde(int groesse) { return anzahl * (double) groesse / sekunden / 1_000_000; }
    }
}
