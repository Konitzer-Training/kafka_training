package de.konitzer.beispiele.performance;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;

/** Der Lasttest kommt ohne Fehler durch und misst eine plausible Rate. */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "app.replikation=1", "app.anzahl=2000", "app.groesse=200"})
@EmbeddedKafka(partitions = 3, topics = "perf")
class LasttestIT {

    @Autowired KafkaTemplate<String, String> kafka;

    @Test
    void sendetAlleNachrichtenOhneFehler() {
        var e = LasttestApp.sende(kafka, "perf", 2000, 200, 100);
        assertThat(e.fehler()).isZero();
        assertThat(e.sekunden()).isPositive();
        assertThat(e.proSekunde()).isGreaterThan(100);
    }
}
