#!/usr/bin/env bash
# 09 – Perf-Topic löschen (200 MB je Lauf, das Lab-Volume ist nicht unendlich)
docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 --delete --topic perf
