#!/usr/bin/env bash
# 06 – Consumer-Test: Wie schnell wird gelesen? (Metriken auf Port 9211)
docker exec -it kafka1 bash /opt/lab/bin/mit-metriken 9211 kafka-consumer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic perf --num-records 200000
# Spalten: data.consumed.in.MB, MB.sec, nMsg.sec, fetch.time.ms
