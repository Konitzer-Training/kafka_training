#!/usr/bin/env bash
# 01 – Topic für die Messungen: 6 Partitionen, damit alle drei Broker mitarbeiten
docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka1:9092 \
    --create --if-not-exists --topic perf --partitions 6 --replication-factor 3
