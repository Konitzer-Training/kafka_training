#!/usr/bin/env bash
# 03 – Gleicher Test, getunt: größere Batches, kurz warten, komprimieren. Durchsatz mit 02 vergleichen.
docker exec -it kafka1 bash /opt/lab/bin/mit-metriken 9201 kafka-producer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic perf \
    --num-records 200000 --record-size 1000 --throughput -1 --warmup-records 20000 \
    --command-property acks=all batch.size=100000 linger.ms=100 compression.type=lz4
# Grafana "Clients": batch-size-avg steigt, records-per-request-avg steigt, compression-rate-avg < 1
