#!/usr/bin/env bash
# 04 – Zum Vergleich acks=1: schneller, aber bei Leader-Ausfall können bestätigte Nachrichten fehlen
docker exec -it kafka1 bash /opt/lab/bin/mit-metriken 9201 kafka-producer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic perf \
    --num-records 200000 --record-size 1000 --throughput -1 --warmup-records 20000 \
    --command-property acks=1 batch.size=100000 linger.ms=100 compression.type=lz4
