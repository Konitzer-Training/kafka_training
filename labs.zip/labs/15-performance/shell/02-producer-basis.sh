#!/usr/bin/env bash
# 02 – Producer-Test mit Standardwerten: die Basislinie. Metriken erscheinen in Grafana unter "Clients".
#
# mit-metriken hängt den JMX-Exporter an das Werkzeug (Port 9201), damit Prometheus die Client-Metriken sieht.
# --throughput -1       so schnell wie möglich
# --warmup-records      die ersten 20000 zählen nicht (JIT, Verbindungsaufbau)
docker exec -it kafka1 bash /opt/lab/bin/mit-metriken 9201 kafka-producer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic perf \
    --num-records 200000 --record-size 1000 --throughput -1 --warmup-records 20000 \
    --command-property acks=all
# Am Ende: "... records sent, N records/sec (M MB/sec), avg latency, max latency, 50th/95th/99th/99.9th"
