#!/usr/bin/env bash
# 08 – Quota: einen Client auf 1 MB/s bremsen (Kapitel 15, "laute Nachbarn")
docker exec -it kafka1 /opt/kafka/bin/kafka-configs.sh --bootstrap-server kafka1:9092 \
    --alter --entity-type clients --entity-name perf-client \
    --add-config producer_byte_rate=1048576

echo "Gebremster Test (client.id=perf-client): erwartet ca. 1 MB/s"
docker exec -it kafka1 /opt/kafka/bin/kafka-producer-perf-test.sh \
    --bootstrap-server kafka1:9092 --topic perf \
    --num-records 20000 --record-size 1000 --throughput -1 \
    --command-property client.id=perf-client

# Quota wieder entfernen:
#   kafka-configs.sh ... --alter --entity-type clients --entity-name perf-client --delete-config producer_byte_rate
