#!/usr/bin/env bash
# 07 – Ende-zu-Ende-Latenz: 1000 Nachrichten einzeln senden und sofort zurücklesen
# Argumente: broker topic anzahl acks nachrichtengröße
docker exec -it kafka1 /opt/kafka/bin/kafka-e2e-latency.sh kafka1:9092 perf 1000 all 1000
# Zum Vergleich mit acks=1:  ... perf 1000 1 1000
