# 15-performance – Arbeitsanweisung

**Was es zeigt:** Die Performance-Messungen aus Tag 2 (Abschnitt 7) als Skripte, und derselbe Versuch als Spring-Boot-Producer: Wie wirken `linger.ms`, `batch.size`, `compression.type` und `acks` auf den Durchsatz?

**Buch:** Kapitel 15 (Performance).

## Teil A: Die Kafka-Werkzeuge (Shell, 15 Minuten)

Reihenfolge `shell/01` bis `shell/09`. Jeder Lauf meldet am Ende Nachrichten/s, MB/s und Latenz-Perzentile. In Grafana „Clients“ die Metriken `batch-size-avg`, `records-per-request-avg`, `compression-rate-avg`, `request-latency-avg` vergleichen.

| Skript | Frage |
| --- | --- |
| `02-producer-basis` | Wie schnell sind die Defaults? |
| `03-producer-getunt` | Was bringen 100 KB Batches, 100 ms Sammeln, lz4? (typisch 2- bis 4-mal mehr Durchsatz) |
| `04-producer-acks1` | Was kostet `acks=all` gegenüber `acks=1`? |
| `05-producer-keys` | Was kosten Keys? (kleinere Batches je Partition) |
| `06-consumer` | Wie schnell liest ein Consumer? (meist schneller als der Producer schreibt) |
| `07-latenz` | Wie lange braucht eine einzelne Nachricht hin und zurück? |
| `08-quota` | Wie bremst man einen Client? |

Zahlen sind von Rechner und Docker abhängig. Es zählt der Unterschied zwischen zwei Läufen, nicht der Absolutwert.

## Teil B: Dasselbe in Java (10 Minuten)

1. Basislinie:
   ```powershell
   java -jar 15-performance\target\15-performance-app.jar
   ```
2. Getunt:
   ```powershell
   java -jar 15-performance\target\15-performance-app.jar --spring.kafka.producer.properties.linger.ms=100 --spring.kafka.producer.batch-size=100000 --spring.kafka.producer.compression-type=lz4
   ```
3. `acks=1`: `--spring.kafka.producer.acks=1`
4. Ohne Keys: `--app.keys=0` (Sticky Partitioner füllt ganze Batches je Partition)
5. Mehr Daten: `--app.anzahl=500000 --app.groesse=200`

Die App gibt die vier Einstellungen und das Ergebnis (Nachrichten/s, MB/s, Fehler) aus.

## Aufgaben

1. Finden Sie den `linger.ms`-Wert, ab dem der Durchsatz nicht mehr steigt. Was passiert mit der Latenz (`07-latenz` mit demselben Wert als `--command-property linger.ms=…`)?
2. Setzen Sie `--spring.kafka.producer.buffer-memory=1000000` (1 MB). Was ändert sich? Welche Metrik zeigt es (`bufferpool-wait-ratio`)?
3. Vergleichen Sie `gzip`, `lz4` und `zstd` bei `app.groesse=5000`. Welche ist am schnellsten, welche am kleinsten? Die Kompressionsrate steht in Grafana.

## Ändern und bauen

- **IntelliJ:** `15-performance → LasttestApp → main`, Programmargumente wie oben.
- **Bauen:** `.\mvnw.cmd -pl 15-performance -am package -DskipTests`
- **Mit Test** (EmbeddedKafka, 2000 Nachrichten): `.\mvnw.cmd -pl 15-performance -am verify`
- Die Methode `sende()` ist bewusst statisch und ohne Spring aufrufbar: Wer einen eigenen Lasttest braucht, kopiert sie.
