# 05-consumer-spring – Arbeitsanweisung

**Was es zeigt:** Der Consumer aus `03-consumer-plain` mit Spring Boot. Die poll-Schleife verschwindet, übrig bleibt eine Methode mit `@KafkaListener`.

**Buch:** Kapitel 6 (Consumer Groups) und der Einstieg in Kapitel 8.

## Ausprobieren (5 Minuten)

1. Consumer starten:
   ```powershell
   java -jar 05-consumer-spring\target\05-consumer-spring-app.jar
   ```
   Beim ersten Start liest die Gruppe `beitragsrechner-spring` alles von Anfang an.
2. Im zweiten Fenster senden: `04-producer-spring` (ohne Argumente) oder `01-shell\02-producer.ps1`.
3. Jede Nachricht erscheint als `P<Partition> @<Offset> key=… wert`, genau wie in 03.
4. Consumer beenden, senden, neu starten: Nur die neuen Nachrichten kommen. Der Offset ist gespeichert (`01-shell\06-gruppe-ansehen.ps1 -Gruppe beitragsrechner-spring`).

## Plain gegen Spring – was sich geändert hat

| 03-consumer-plain | 05-consumer-spring |
| --- | --- |
| `Properties` + `einstellungen.put(...)` | `application.properties` |
| `new KafkaConsumer<>(…)`, `subscribe(…)` | `@KafkaListener(topics = "${app.topic}")` |
| `while (laeuft) { poll(); … commitSync(); }` | der Listener Container von Spring Kafka |
| Shutdown-Hook mit `wakeup()` | Spring stoppt den Container beim Beenden |
| `verarbeitung.accept(nachricht)` | die annotierte Methode `verarbeite(...)` |
| `commitSync()` nach dem Paket | `ack-mode=record`: Commit nach jeder Nachricht |

## Aufgaben

1. Ändern Sie die Signatur zu `public void verarbeite(String wert)`. Was bekommt die Methode jetzt? Woher weiß Spring, dass der Wert gemeint ist?
2. Holen Sie Key und Partition mit `@Header(KafkaHeaders.RECEIVED_KEY) String key` und `@Header(KafkaHeaders.RECEIVED_PARTITION) int partition` (Kapitel 8). 
3. Werfen Sie in `verarbeite` eine `RuntimeException`, wenn der Wert `Beitrag 99,00` enthält. Senden Sie diese Nachricht. Was macht Spring? Wie oft? Beenden Sie die App und schauen Sie mit `06-gruppe-ansehen`, ob der Offset committet wurde. Das ist der Einstieg in Kapitel 9.
4. Starten Sie die App zweimal mit `--spring.kafka.listener.concurrency=3` **oder** zweimal als Prozess. Welche Partition landet wo? (`06-consumer-groups` zeigt das ausführlich.)

## Ändern und bauen

- **IntelliJ:** Projekt `labs` öffnen, `05-consumer-spring → ConsumerApp → main` starten.
- **Nur dieses Modul bauen:**
  ```powershell
  .\mvnw.cmd -pl 05-consumer-spring -am package -DskipTests
  ```
- **Mit Test** (EmbeddedKafka, kein Docker):
  ```powershell
  .\mvnw.cmd -pl 05-consumer-spring -am verify
  ```
- Der Test `BeitragsverarbeitungIT` schreibt zwei Nachrichten und prüft `empfangen()`. Wenn Sie in Aufgabe 1 die Signatur ändern, muss `empfangen.add(...)` den Wert weiter sammeln, sonst wird der Test rot – ein guter Schutz.
- Properties von der Kommandozeile: `--spring.kafka.consumer.group-id=statistik --app.topic=beitraege-test`.

## Fehlerbilder

| Meldung | Ursache |
| --- | --- |
| nichts passiert, kein `P0 @…` | Topic leer, oder die Gruppe hat alles schon gelesen (Reset: `07-offsets-zuruecksetzen … ausfuehren`) |
| `Topic beitraege not present in metadata` | Topic fehlt: `01-shell\01-topic-anlegen` oder `04-producer-spring` einmal starten |
| Nachrichten als `ÜBERSPRUNGEN` oder Deserialisierungsfehler | im Topic liegen keine Textnachrichten (z. B. JSON aus Modul 07) |
