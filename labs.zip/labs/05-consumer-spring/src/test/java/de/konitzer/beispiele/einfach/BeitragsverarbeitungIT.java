package de.konitzer.beispiele.einfach;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;

/** Der Listener bekommt, was in das Topic geschrieben wird – in Reihenfolge je Key. */
@SpringBootTest(properties = "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}")
@EmbeddedKafka(partitions = 3, topics = "beitraege")
class BeitragsverarbeitungIT {

    @Autowired EmbeddedKafkaBroker broker;
    @Autowired Beitragsverarbeitung verarbeitung;

    @Test
    void listenerEmpfaengtNachrichtenInReihenfolge() {
        var props = KafkaTestUtils.producerProps(broker);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        try (var producer = new KafkaProducer<String, String>(props)) {
            producer.send(new ProducerRecord<>("beitraege", "V-1001", "Beitrag 42,50"));
            producer.send(new ProducerRecord<>("beitraege", "V-1001", "Beitrag 44,00"));
            producer.flush();
        }
        await().atMost(Duration.ofSeconds(10)).untilAsserted(() ->
                assertThat(verarbeitung.empfangen()).containsExactly("Beitrag 42,50", "Beitrag 44,00"));
    }
}
