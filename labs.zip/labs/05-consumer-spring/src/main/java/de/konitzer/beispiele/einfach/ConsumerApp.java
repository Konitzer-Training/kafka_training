package de.konitzer.beispiele.einfach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Startklasse. Sie tut nichts weiter, als Spring Boot zu starten. Spring Boot findet die
 * Klasse Beitragsverarbeitung im selben Package (@Component) und startet deren @KafkaListener.
 *
 * Starten:   java -jar target/05-consumer-spring-app.jar     (Strg+C beendet)
 * Andere Gruppe oder anderes Topic, ohne neu zu bauen:
 *            java -jar target/05-consumer-spring-app.jar --spring.kafka.consumer.group-id=statistik
 */
@SpringBootApplication
public class ConsumerApp {

    public static void main(String[] args) {
        SpringApplication.run(ConsumerApp.class, args);
    }
}
