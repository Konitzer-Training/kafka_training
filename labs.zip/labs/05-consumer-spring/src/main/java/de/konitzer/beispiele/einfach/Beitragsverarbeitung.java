package de.konitzer.beispiele.einfach;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Derselbe Consumer wie 03-consumer-plain, jetzt mit Spring Boot.
 *
 * Die ganze Leseschleife (subscribe – poll – commit – wakeup beim Beenden) ist verschwunden.
 * Sie steckt in Spring Kafka: Ein "Listener Container" ruft poll() in einem eigenen Thread
 * auf und reicht jede Nachricht an die Methode mit @KafkaListener weiter. Nach der Methode
 * committet er den Offset (ack-mode=record in application.properties).
 *
 * Was von uns bleibt: die Verarbeitung einer einzelnen Nachricht.
 */
@Component   // "Spring, bitte ein Objekt davon anlegen und verwalten"
public class Beitragsverarbeitung {

    private static final Logger log = LoggerFactory.getLogger(Beitragsverarbeitung.class);

    // Für Tests und die Aufgaben: alle empfangenen Werte in Reihenfolge
    private final List<String> empfangen = new CopyOnWriteArrayList<>();

    /**
     * @KafkaListener: "Rufe diese Methode für jede Nachricht aus dem Topic auf."
     *  - id: Name des Containers (z. B. zum Pausieren). Achtung: Ohne idIsGroup = false wäre die id
     *    zugleich die Consumer Group und würde spring.kafka.consumer.group-id überschreiben!
     *  - topics: ${app.topic} wird aus application.properties ersetzt
     *
     * Der Parameter ConsumerRecord ist dieselbe Klasse wie in der poll-Schleife von 03-consumer-plain.
     * Alternativ kann man nur den Wert nehmen (String wert) oder einzelne Teile mit @Header – Kapitel 8.
     */
    @KafkaListener(id = "beitraege", idIsGroup = false, topics = "${app.topic}")
    public void verarbeite(ConsumerRecord<String, String> nachricht) {
        // Hier stünde die Fachlogik. Wirft die Methode eine Exception, wird NICHT committet,
        // und Spring versucht es (nach Standardregeln) noch einmal – Kapitel 9.
        log.info("P{} @{} key={} {}", nachricht.partition(), nachricht.offset(), nachricht.key(), nachricht.value());
        empfangen.add(nachricht.value());
    }

    public List<String> empfangen() {
        return empfangen;
    }
}
