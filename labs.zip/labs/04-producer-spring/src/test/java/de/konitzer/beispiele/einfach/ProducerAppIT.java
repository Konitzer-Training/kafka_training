package de.konitzer.beispiele.einfach;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;

/**
 * Die App läuft im Test gegen einen eingebetteten Broker (kein Docker nötig).
 * Die Programmargumente werden gesendet, mit Key, in das Topic aus app.topic.
 */
@SpringBootTest(
        args = {"V-1001:Beitrag 42,50", "V-1001:Beitrag 44,00"},
        properties = {"spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}", "app.replikation=1"})
@EmbeddedKafka(partitions = 3, topics = "beitraege")
class ProducerAppIT {

    @Autowired EmbeddedKafkaBroker broker;

    @Test
    void argumenteKommenMitKeyAn() {
        var props = KafkaTestUtils.consumerProps(broker, "test", false);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        try (var consumer = new KafkaConsumer<String, String>(props)) {
            broker.consumeFromAnEmbeddedTopic(consumer, "beitraege");
            var records = KafkaTestUtils.getRecords(consumer, Duration.ofSeconds(10), 2);
            assertThat(records.count()).isEqualTo(2);
            var liste = new java.util.ArrayList<org.apache.kafka.clients.consumer.ConsumerRecord<String, String>>();
            records.forEach(liste::add);
            assertThat(liste).allMatch(r -> r.key().equals("V-1001"));
            // gleicher Key -> gleiche Partition
            assertThat(liste.get(0).partition()).isEqualTo(liste.get(1).partition());
        }
    }
}
