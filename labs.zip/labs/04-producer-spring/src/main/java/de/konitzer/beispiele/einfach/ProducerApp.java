package de.konitzer.beispiele.einfach;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * Derselbe Producer wie 02-producer-plain, jetzt mit Spring Boot.
 *
 * Was Spring Boot uns abnimmt:
 *  - Das Properties-Objekt und "new KafkaProducer(...)": Spring Boot liest application.properties
 *    und baut daraus den Producer. Wir bekommen ihn fertig als KafkaTemplate.
 *  - Das Schließen beim Beenden (flush + close).
 *  - Das Topic anlegen: eine Bean vom Typ NewTopic reicht.
 *
 * Was gleich bleibt: send() ist asynchron, das Ergebnis muss man auswerten.
 *
 * Starten:   java -jar target/04-producer-spring-app.jar "V-1001:Beitrag 42,50" "V-1002:Beitrag 19,90"
 * Ohne Argumente sendet die App fünf Beispielnachrichten. Weitere Betriebsarten (Properties):
 *   --app.eingabe=true       Zeilen von der Tastatur, wie der Console Producer (leere Zeile beendet)
 *   --app.automatisch=true   endlos jede Sekunde eine Nachricht für V-1001 bis V-1005 (Lag erzeugen)
 *   --app.topic=test         anderes Topic – jede Property aus application.properties geht so
 */
// Diese eine Annotation macht die Klasse zur Spring-Boot-Anwendung: Auto-Konfiguration (Kafka-Producer,
// KafkaTemplate, Einstellungen aus application.properties) plus das Einsammeln der @Bean-Methoden.
@SpringBootApplication
public class ProducerApp {

    // Startpunkt wie in jedem Java-Programm. SpringApplication.run baut alles auf und ruft
    // danach den CommandLineRunner unten auf.
    public static void main(String[] args) {
        SpringApplication.run(ProducerApp.class, args);
    }

    /**
     * Topic als Code. Spring Boot legt jede NewTopic-Bean beim Start an, falls sie fehlt.
     * Existiert das Topic schon, passiert nichts.
     * Shell-Entsprechung: 01-shell/01-topic-anlegen.sh.
     *
     * @Value("${app.topic}") holt den Wert aus application.properties (oder von der Kommandozeile).
     */
    @Bean
    NewTopic beitraegeTopic(@Value("${app.topic}") String name,
                            @Value("${app.partitionen}") int partitionen,
                            @Value("${app.replikation}") short replikation) {
        return TopicBuilder.name(name)
                .partitions(partitionen)
                .replicas(replikation)
                // acks=all + min.insync.replicas=2 = die Faustregel aus Kapitel 5
                .config("min.insync.replicas", "2")
                .build();
    }

    /**
     * Das eigentliche Programm. Ein CommandLineRunner läuft genau einmal, sobald Spring Boot
     * fertig gestartet ist. Die Parameter reicht Spring Boot herein:
     *  - KafkaTemplate<String, String>: der fertig konfigurierte Producer (Key und Wert sind Text)
     *  - topic: die Einstellung app.topic
     */
    @Bean
    CommandLineRunner senden(KafkaTemplate<String, String> kafka,
                             @Value("${app.topic}") String topic,
                             @Value("${app.eingabe}") boolean eingabe,
                             @Value("${app.automatisch}") boolean automatisch,
                             @Value("${app.intervall-ms}") long intervallMs) {
        return args -> {
            System.out.println("Producer bereit. Topic: " + topic);

            if (automatisch) {
                // Betriebsart 1: Endlosschleife, jede Sekunde eine Nachricht. Gut, um Lag zu erzeugen.
                // Per Shell wäre das:  while true; do echo "V-1001:Änderung"; sleep 1; done | kafka-console-producer.sh …
                System.out.println("Automatik: alle " + intervallMs + " ms eine Nachricht für V-1001 bis V-1005. Strg+C beendet.");
                for (int i = 1; ; i++) {
                    String vertrag = "V-" + (1000 + (i - 1) % 5 + 1);   // V-1001 … V-1005, dann von vorn
                    sende(kafka, topic, vertrag + ":Beitrag " + (20 + i % 30) + ",00");
                    Thread.sleep(intervallMs);
                }
            }

            if (eingabe) {
                // Betriebsart 2: Zeilen von der Tastatur, wie der Console Producer (und 02-producer-plain)
                System.out.println("Eingabe: key:wert, z. B.  V-1001:Beitrag 42,50   (leere Zeile beendet)");
                var leser = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
                String zeile;
                while ((zeile = leser.readLine()) != null && !zeile.isBlank()) {
                    sende(kafka, topic, zeile);
                }
            } else {
                // Betriebsart 3 (Standard): Programmargumente sind die Nachrichten; ohne Argumente fünf Beispiele
                List<String> zeilen = args.length > 0 ? List.of(args) : List.of(
                        "V-1001:Beitrag 42,50", "V-1002:Beitrag 19,90", "V-1001:Beitrag 44,00",
                        "V-1003:Beitrag 99,00", "V-1002:Beitrag 21,00");
                for (String zeile : zeilen) {
                    sende(kafka, topic, zeile);
                }
            }
            // Puffer leeren und auf die Antworten warten, damit alle Ausgaben da sind, bevor die App endet
            kafka.flush();
            System.out.println("Producer beendet.");
        };
    }

    /** Eine Zeile "key:wert" senden – ohne Doppelpunkt ohne Key (dann verteilt der Producer selbst). */
    static void sende(KafkaTemplate<String, String> kafka, String topic, String zeile) {
        int trenner = zeile.indexOf(':');
        String key = trenner > 0 ? zeile.substring(0, trenner).trim() : null;
        String wert = trenner > 0 ? zeile.substring(trenner + 1).trim() : zeile.trim();

        // send() liefert ein CompletableFuture. whenComplete läuft, wenn der Broker geantwortet hat.
        // Genau wie der Callback in 02-producer-plain – nur ohne ProducerRecord und ohne Properties.
        kafka.send(topic, key, wert).whenComplete((ergebnis, fehler) -> {
            if (fehler != null) {
                System.out.printf("FEHLER   key=%-8s \"%s\" -> %s%n", key, wert, fehler.getMessage());
                return;
            }
            var meta = ergebnis.getRecordMetadata();
            System.out.printf("gesendet key=%-8s \"%s\" -> Partition %d, Offset %d%n",
                    key, wert, meta.partition(), meta.offset());
        });
    }
}
