# 04-producer-spring – Arbeitsanweisung

**Was es zeigt:** Der Producer aus `02-producer-plain`, jetzt mit Spring Boot. Die Konfiguration wandert aus dem Java-Code in `application.properties`, der Producer kommt fertig als `KafkaTemplate`, das Topic wird beim Start angelegt.

**Buch:** Kapitel 4 (Keys), 5 (acks, min.insync.replicas) und der Einstieg in Kapitel 7.

## Ausprobieren (5 Minuten)

1. Shell-Consumer starten: `01-shell\03-consumer.ps1`.
2. Producer ohne Argumente starten, er sendet fünf Beispielnachrichten:
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar
   ```
   Beobachten: V-1001 zweimal in derselben Partition, V-1002 ebenso.
3. Eigene Nachrichten mitgeben:
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar "V-1004:Beitrag 12,00"
   ```
4. Wie der Console Producer, Zeilen eintippen (leere Zeile beendet):
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.eingabe=true
   ```
5. Endlos jede Sekunde eine Nachricht, zum Beispiel um in 06 Lag zu erzeugen (Strg+C beendet):
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.automatisch=true
   ```
6. Eine Einstellung von der Kommandozeile überschreiben, ohne neu zu bauen:
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.topic=beitraege-test
   ```
   Das Topic `beitraege-test` wird dabei angelegt (NewTopic-Bean). Prüfen: `01-shell\04-topic-ansehen.ps1 -Topic beitraege-test`.

## Plain gegen Spring – was sich geändert hat

| 02-producer-plain | 04-producer-spring |
| --- | --- |
| `Properties` + `einstellungen.put(...)` | `application.properties` |
| `new KafkaProducer<>(einstellungen)` | `KafkaTemplate<String, String>` als Parameter |
| `new ProducerRecord<>(topic, key, wert)` + `producer.send(record, callback)` | `kafka.send(topic, key, wert).whenComplete(...)` |
| `try (producer) { … }` | Spring schließt beim Beenden |
| Topic per Shell anlegen | `@Bean NewTopic` |
| `-Dtopic=…` | `--app.topic=…` |

Was **nicht** anders ist: `send()` ist asynchron, Fehler sieht man nur, wenn man das Ergebnis auswertet.

## Aufgaben

1. Setzen Sie in `application.properties` `spring.kafka.producer.acks=0` und senden Sie. Welcher Offset wird gemeldet? Warum?
2. Stoppen Sie `kafka3` (`docker stop kafka3`) und senden Sie: klappt. Setzen Sie dann `min.insync.replicas` im TopicBuilder auf 3, löschen Sie das Topic (`08-topic-loeschen`) und senden Sie erneut. Was meldet die App nach `delivery.timeout.ms`? Setzen Sie `spring.kafka.producer.properties.delivery.timeout.ms=5000`, damit Sie nicht zwei Minuten warten. Danach `docker start kafka3`.
3. Ergänzen Sie einen Header `quelle=producer-spring`. Tipp: `MessageBuilder` oder `ProducerRecord` mit `kafka.send(record)`; Kapitel 7 zeigt beides.

## Ändern und bauen

- **IntelliJ:** Projekt `labs` öffnen (Wurzel-POM). `04-producer-spring → ProducerApp → main` starten. Programmargumente unter `Run → Edit Configurations → Program arguments`.
- **Nur dieses Modul bauen** (im Ordner `labs`; `-am` baut `spring-basis` mit):
  ```powershell
  .\mvnw.cmd -pl 04-producer-spring -am package -DskipTests
  ```
  Ergebnis: `04-producer-spring\target\04-producer-spring-app.jar`.
- **Mit Test** (EmbeddedKafka, kein Docker nötig, ca. 20 Sekunden):
  ```powershell
  .\mvnw.cmd -pl 04-producer-spring -am verify
  ```
- Eine Property ändern braucht **keinen** Build: `--spring.kafka.producer.acks=1` auf der Kommandozeile überschreibt die Datei.
- Eine neue Abhängigkeit kommt in die `pom.xml` dieses Moduls (`<dependencies>`-Block anlegen); die Version kommt aus dem Spring-Boot-Parent, meist ohne `<version>`.

## Fehlerbilder

| Meldung | Ursache |
| --- | --- |
| `Connection to node -1 could not be established` | Lab läuft nicht (`docker compose up -d` in `kafka-lab`) |
| `TimeoutException: Topic beitraege not present` | Topic fehlt und `auto.create` ist aus; die NewTopic-Bean hat es nicht angelegt, weil die Verbindung fehlte |
| `NOT_ENOUGH_REPLICAS` | weniger Broker im ISR als `min.insync.replicas` (Aufgabe 2) |
