# Sprechertext: Von der Shell zu Java – „Kafka in Spring Boot“

Dauer etwa 60 Minuten mit Mitmachen, 35 Minuten als reine Vorführung. Passt zum Foliensatz 09 „Kafka in Spring Boot“ und zu den Modulen `01-shell` bis `06-consumer-groups`, danach Ausblick auf 07 bis 18. Jede Szene: was auf dem Bildschirm steht, was ich sage, was die Teilnehmer tun.

Vorher: Lab läuft, `labs` gebaut, Topic `beitraege` frisch (`01-shell\08-topic-loeschen.ps1`, dann `01-topic-anlegen.ps1`), drei PowerShell-Fenster offen, Schrift groß.

---

## Szene 0: Warum dieser Weg (2 min, Folie 2)

> „Sie haben gestern alles mit Shell-Skripten gemacht: Topic anlegen, Producer, Consumer, Gruppen, Offsets. Das war kein Umweg. Jedes dieser Skripte ist ein Java-Programm, das Kafka mitliefert. Heute gehen wir denselben Weg noch einmal, aber in Java, in drei Stufen: erst nur der Kafka-Client, dann Spring Boot ganz minimal, dann Spring Boot so, wie Sie es in Produktion schreiben würden. Am Ende erkennen Sie in jeder Zeile Spring-Konfiguration den Shell-Parameter von gestern wieder.“

Folie zeigt die drei Stufen als Treppe: Shell → Plain Java → Spring Boot minimal → Spring Boot vollständig. Wenn jemand fragt „Warum nicht gleich Spring?“: „Weil Spring Ihnen die poll-Schleife versteckt. Wer sie einmal gesehen hat, versteht, warum ein Listener hängen kann und was `max.poll.records` bedeutet.“

## Szene 1: Die Shell noch einmal, als Skript (5 min, Folie 3)

Bildschirm: `01-shell\02-producer.ps1` im Editor, dann in Fenster 1 ausführen.

> „Das ist der Befehl von gestern, nur mit Kommentaren. Zwei Dinge markiere ich: `parse.key=true` mit dem Doppelpunkt, das ist der Key. Und `acks=all`, das ist die Zuverlässigkeit aus Kapitel 5. Merken Sie sich die beiden, die sehen wir gleich in Java wieder.“

Teilnehmer tippen in Fenster 1: `V-1001:Beitrag 42,50`, `V-1002:Beitrag 19,90`, `V-1001:Beitrag 44,00`. Fenster 2: `03-consumer.ps1`.

> „Der Consumer zeigt Partition und Offset. Der Producer zeigt nichts. Er weiß nicht einmal, ob die Nachricht angekommen ist. Das ist die erste Grenze der Shell, und der erste Grund für Java.“

## Szene 2: Derselbe Producer in Java, ohne Framework (8 min, Folien 4 bis 5)

Bildschirm: `02-producer-plain/PlainProducer.java`, in IntelliJ oder im Editor. Nicht scrollen, mit dem Cursor zeigen.

> „Eine Klasse, eine main-Methode, kein Spring. Drei Teile. Erstens die Konfiguration: ein Properties-Objekt. `bootstrap.servers`, das ist `--bootstrap-server`. `acks=all`, dasselbe wie eben. Neu sind die zwei Serializer, denn Kafka kennt nur Bytes, und die Shell hat das für uns versteckt. Zweitens: `new KafkaProducer`. Drittens: `send`.“

Pause bei `send`:

> „`send` kehrt sofort zurück. Die Nachricht liegt dann in einem Puffer. Ob sie ankommt, erfahren wir im Callback, und nur dort. Wer den Callback weglässt, hat ‚Fire and forget‘, und der verliert Nachrichten, ohne es zu merken. Deshalb gibt dieses Programm Partition und Offset aus, und ein Fehler steht ebenfalls da.“

Fenster 1: `java -jar 02-producer-plain\target\02-producer-plain-app.jar`, dieselben drei Zeilen tippen. Fenster 2 (Shell-Consumer läuft noch) zeigt sie.

> „Gleiche Nummern in beiden Fenstern. V-1001 beide Male in derselben Partition. Das ist Kapitel 4, der Key bestimmt die Partition, und Sie sehen es jetzt vom Producer aus.“

Mitmachen: Aufgabe 1 aus `02-producer-plain/ANLEITUNG.md` (fünf Keys, Verteilung ansehen). 3 Minuten.

## Szene 3: Der Consumer in Java, ohne Framework (8 min, Folien 6 bis 7)

Bildschirm: `03-consumer-plain/PlainConsumer.java`.

> „Beim Consumer kommt etwas dazu, was die Shell komplett versteckt: die Schleife. `subscribe` sagt ‚ich will dieses Topic‘. Dann `poll`, immer wieder. `poll` holt nicht nur Nachrichten, es sendet auch die Heartbeats und macht den Rebalance mit. Wer in dieser Schleife zu lange arbeitet, fliegt aus der Gruppe. Das ist die Ursache für neun von zehn Rebalance-Problemen in Produktion.“

Dann `commitSync`:

> „Und hier der Commit. Gestern hat der Console Consumer alle fünf Sekunden committet, ohne dass Sie es gesehen haben. Hier steht er explizit, nach der Verarbeitung. Stürzt das Programm zwischen Verarbeitung und Commit ab, kommt die Nachricht noch einmal. At least once, Kapitel 5.“

Fenster 2: Shell-Consumer beenden, `java -jar 03-consumer-plain\target\03-consumer-plain-app.jar`. Er liest alles von Anfang an. Dann Strg+C, in Fenster 1 zwei Zeilen senden, Consumer neu starten: nur die zwei neuen.

> „Das ist die Gruppe. `beitragsrechner-plain` hat sich gemerkt, wo sie war. Schauen wir nach, was Kafka gespeichert hat.“

Fenster 3: `01-shell\06-gruppe-ansehen.ps1 -Gruppe beitragsrechner-plain`. CURRENT-OFFSET zeigen.

> „Dieselbe Tabelle wie gestern. Nur dass der Consumer jetzt unser Programm ist.“

## Szene 4: Zwischenbilanz (2 min, Folie 8)

> „Halten wir fest. Was Sie gestern in der Shell getan haben, sind in Java drei Objekte: Properties, Producer oder Consumer, und Record. Mehr ist es nicht. Alles Weitere, Spring, Streams, Transaktionen, baut auf genau diesen drei auf. Was stört an dem Code? Die Konfiguration steht im Code. Die Schleife muss jeder selbst schreiben. Der Shutdown ist Handarbeit. Genau das nimmt Spring Boot ab.“

## Szene 5: Spring Boot, minimal (10 min, Folien 9 bis 11)

Bildschirm: `04-producer-spring/application.properties` und `PlainProducer.java` nebeneinander.

> „Dieselben Einstellungen. Links `einstellungen.put(ACKS_CONFIG, "all")`, rechts `spring.kafka.producer.acks=all`. Links die Serializer-Klasse, rechts die Serializer-Klasse. Die Namen hinter `spring.kafka.producer.properties.` gehen eins zu eins an den Kafka-Client. Alles, was in der Kafka-Dokumentation steht, können Sie dort eintragen.“

Dann `ProducerApp.java`:

> „`@SpringBootApplication` liest die Datei und baut den Producer. Wir bekommen ihn als `KafkaTemplate`. `kafka.send(topic, key, wert)`, und `whenComplete` ist unser Callback. Das Topic legt die `NewTopic`-Bean an, das war gestern `kafka-topics.sh --create`. Wichtig: `send` ist immer noch asynchron. Spring ändert daran nichts.“

Fenster 1: `java -jar 04-producer-spring\target\04-producer-spring-app.jar` (fünf Beispiele). Dann:

> „Und jetzt der Trick, den Sie in Produktion täglich brauchen: eine Einstellung ändern, ohne neu zu bauen.“

`java -jar ... --spring.kafka.producer.acks=1`. Läuft.

Bildschirm: `05-consumer-spring/Beitragsverarbeitung.java`.

> „Beim Consumer verschwindet die ganze Schleife. Übrig bleibt eine Methode mit `@KafkaListener`. Den Rest, subscribe, poll, commit, Shutdown, macht der Listener Container von Spring Kafka in einem eigenen Thread. Die Gruppe steht in den Properties. `ack-mode=record` heißt: nach jeder Methode wird committet, das ist unser `commitSync` von vorhin.“

Fenster 2: `05-consumer-spring` starten, Fenster 1 noch einmal den Producer.

Mitmachen: Aufgabe 1 aus `05-consumer-spring/ANLEITUNG.md` (Signatur auf `String wert` ändern, bauen, starten). 5 Minuten. Bauen mit `.\mvnw.cmd -pl 05-consumer-spring -am package -DskipTests`.

## Szene 6: Consumer Groups aus der App heraus (8 min, Folien 12 bis 13)

Bildschirm: `06-consumer-groups/Beitragsverarbeitung.java`, Methoden `onPartitionsAssigned` und `onPartitionsRevoked`.

> „Gestern haben Sie mit `--members` gesehen, wer welche Partition hat. Jetzt sagt es die App selbst. `ConsumerSeekAware` ist eine kleine Schnittstelle: Spring ruft diese Methoden beim Rebalance auf.“

Fenster 2: `06-consumer-groups` starten: `ZUGEWIESEN` mit drei Partitionen. Fenster 3: zweite Instanz: Fenster 2 zeigt `ABGEGEBEN`, Fenster 3 `ZUGEWIESEN`.

> „Nur die betroffenen Partitionen wechseln, die anderen laufen weiter. Das ist das neue Gruppenprotokoll, `group.protocol=consumer`, dieselbe Zeile wie gestern im Skript.“

Fenster 3 beenden. Dann Fenster 2 beenden und mit `--app.von-anfang=true` neu starten.

> „`seekToBeginning` im Code. Gestern war das `--reset-offsets --to-earliest`, und es ging nur bei gestoppter Gruppe. Aus der App heraus geht es beim Start.“

Mitmachen: Aufgabe 3 aus `06-consumer-groups/ANLEITUNG.md` (`acknowledge()` auskommentieren). 5 Minuten.

## Szene 7: Was jetzt fehlt, und wo es steht (5 min, Folien 14 bis 16)

> „Sie können jetzt alles, was Sie gestern in der Shell konnten, in Spring Boot. Was fehlt für Produktion? Vier Dinge. Erstens: Nachrichten sind keine Strings, sondern Objekte. Modul 07 und 08: JSON mit Jackson, ein gemeinsames Record als Vertrag zwischen Producer und Consumer. Zweitens: Was passiert bei einem Fehler? Modul 09a: Retry mit Backoff, Dead-Letter-Topic oder anhalten, mit Tests, die zeigen, welche Reihenfolge erhalten bleibt. Drittens: Datenbank und Kafka zusammen, Modul 09b Outbox, 09c Kafka-Transaktionen. Viertens: Wie teste ich das? Modul 13, von der Unit bis zum Container.“

Folie 15 zeigt die Modultabelle mit Kapitelnummern. Folie 16: Monitoring.

> „Und das Monitoring von heute Morgen: Modul 14 ist derselbe Consumer wie 05, mit einem Endpunkt, den Prometheus abholt. Zwei Abhängigkeiten in der pom, null Zeilen Code für die Kafka-Metriken. Der Lag, den Sie in Grafana gesehen haben, kommt dann aus Ihrer App.“

Wenn Zeit ist: `14-monitoring` starten, `localhost:8085/actuator/prometheus` im Browser, nach `records_lag_max` suchen.

## Szene 8: Abschluss (2 min, Folie 17)

> „Zum Mitnehmen: Jede Shell-Option hat eine Property. Jeder Producer ist asynchron, werten Sie das Ergebnis aus. Jeder Consumer ist eine Schleife, auch wenn Spring sie versteckt, und in der Schleife darf man nicht trödeln. Die Anleitungen in jedem Modulordner haben Aufgaben mit Lösungsweg. Die Tests laufen ohne Lab, mit `mvnw verify`. Und bei jedem Modul steht, wie Sie es ändern und neu bauen.“

---

## Kürzungsregeln

- 35 Minuten: Szene 2 und 3 nur vorführen, Szene 5 Mitmachen streichen, Szene 6 nur ZUGEWIESEN/ABGEGEBEN.
- 20 Minuten: Szene 1 weglassen (Rückblick mündlich), Szene 3 nur die Schleife zeigen, Szene 6 streichen, Szene 7 als Tabelle.
- Wenn IntelliJ auf dem Dozentenrechner hakt: Code im Editor zeigen, JARs aus `target` starten. Der Build ist vorher gelaufen.

## Typische Fragen

| Frage | Antwort |
| --- | --- |
| „Warum nicht gleich Spring?“ | Weil die Schleife und das asynchrone `send` dort unsichtbar sind, und die Fehler in Produktion genau dort entstehen. |
| „Brauche ich `KafkaTemplate` oder `KafkaProducer`?“ | `KafkaTemplate` wickelt den `KafkaProducer` ein; alles, was der kann, geht durch. Rohen Producer nur für Spezialfälle (eigene Partitionierung, Transaktionen von Hand). |
| „Wie viele Threads?“ | `concurrency` höchstens gleich Partitionen, sonst warten Threads. Lieber mehr Instanzen als mehr Threads, wenn der Ausfall einer Instanz begrenzt bleiben soll. |
| „Und Spring Boot 3?“ | README-Tabelle „Unterschiede zu Spring Boot 3.x“: Serializer-Namen, Jackson-Paket, Backoff-Klasse, Testcontainers-Artefakte. Alles andere ist gleich. |
| „Kann ich die Properties aus der Umgebung ziehen?“ | Ja, `SPRING_KAFKA_BOOTSTRAP_SERVERS=…` als Umgebungsvariable, Spring Boot übersetzt den Namen. Für Passwörter (Kapitel 16) der einzige richtige Weg. |
