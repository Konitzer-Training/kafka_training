# 11a-join-einfach – Arbeitsanweisung

**Was es zeigt:** Der kleinste sinnvolle Kafka-Streams-Fall: Ein Antrag und eine Risikoprüfung zum selben Vertrag (gleicher Key) kommen in zwei Topics an, in beliebiger Reihenfolge, und werden zu einer Police zusammengeführt, wenn sie höchstens fünf Minuten auseinanderliegen. Das ist die Mitmach-Vorführung aus Deck 07 (früher `kafka-einfach/join-app`).

**Buch:** Kapitel 11 (Kafka Streams), Einstieg. Die vier Topologien mit Tests stehen in `11-streams`.

## Vorführung (10 Minuten, drei Fenster)

1. **Fenster 1:** Join starten. Die drei Topics werden angelegt.
   ```powershell
   java -jar 11a-join-einfach\target\11a-join-einfach-app.jar
   ```
2. **Fenster 2:** Anträge eintippen (Producer im Eingabemodus auf dem Topic `antraege`):
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.eingabe=true --app.topic=antraege
   ```
   ```text
   V-2001:Antrag KFZ
   V-2002:Antrag Hausrat
   ```
3. **Fenster 3:** Prüfungen eintippen:
   ```powershell
   java -jar 04-producer-spring\target\04-producer-spring-app.jar --app.eingabe=true --app.topic=pruefungen
   ```
   ```text
   V-2001:geprüft ok
   ```
   In Fenster 1: `Antrag … wartet auf die Prüfung`, `Prüfung … wartet auf den Antrag`, dann `ZUSAMMEN key=V-2001 Police aus …`.
4. Erst die Prüfung für V-2002, dann (in Fenster 2) ein zweiter Antrag für V-2002: Die Reihenfolge ist egal.
5. Wo ist der Zustand? `01-shell\04-topic-ansehen.ps1 -Topic join-einfach-antrag-pruefung-this-join-store-changelog` (Tab-Taste hilft nicht, der Name steht in `kafka-topics.sh --list`).

## Aufgaben

1. Setzen Sie `app.fenster-minuten=0` (bzw. `--app.fenster-minuten=0`) und wiederholen Sie Schritt 2 und 3 mit einer Pause von 10 Sekunden. Warum entsteht keine Police?
2. Ersetzen Sie `join` durch `leftJoin`: Was kommt jetzt heraus, wenn nur der Antrag da ist? Der Test `JoinAppTest` sagt es Ihnen auch.
3. Zählen Sie Policen je Minute: `policenStream.groupByKey().windowedBy(...).count()` – Vorlage in `11-streams/Topologien.schaedenJeVertrag`.

## Ändern und bauen

- **IntelliJ:** `11a-join-einfach → JoinApp → main`.
- **Bauen:** `.\mvnw.cmd -pl 11a-join-einfach -am package -DskipTests`
- **Mit Test** (TopologyTestDriver, kein Broker, 5 Sekunden): `.\mvnw.cmd -pl 11a-join-einfach -am verify`
- Der lokale Zustand liegt im Ordner `zustand/` neben dem JAR. Nach einer Änderung der Topologie: Ordner löschen und `kafka-streams-application-reset.sh --application-id join-einfach` im Container.
