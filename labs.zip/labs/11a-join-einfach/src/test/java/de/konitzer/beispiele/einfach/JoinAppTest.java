package de.konitzer.beispiele.einfach;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.time.Instant;
import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.TopologyTestDriver;
import org.junit.jupiter.api.Test;

/**
 * Die Topologie ohne Broker testen: TopologyTestDriver (Kapitel 13). Die Zeit kontrollieren wir
 * über die Zeitstempel der Testnachrichten.
 */
class JoinAppTest {

    @Test
    void antragUndPruefungImFensterErgebenEinePolice() {
        var builder = new StreamsBuilder();
        new JoinApp().zusammenfuehren(builder, "antraege", "pruefungen", "policen", 5);

        var props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "egal:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        try (var driver = new TopologyTestDriver(builder.build(), props)) {
            var antraege = driver.createInputTopic("antraege", new StringSerializer(), new StringSerializer());
            var pruefungen = driver.createInputTopic("pruefungen", new StringSerializer(), new StringSerializer());
            var policen = driver.createOutputTopic("policen", new StringDeserializer(), new StringDeserializer());

            Instant t0 = Instant.parse("2026-11-03T09:00:00Z");
            antraege.pipeInput("V-2001", "Antrag KFZ", t0);
            pruefungen.pipeInput("V-2001", "geprüft: ok", t0.plus(Duration.ofMinutes(2)));   // im Fenster
            pruefungen.pipeInput("V-2002", "geprüft: ok", t0.plus(Duration.ofMinutes(3)));   // kein Antrag dazu

            var ergebnis = policen.readKeyValuesToList();
            assertThat(ergebnis).hasSize(1);
            assertThat(ergebnis.get(0).key).isEqualTo("V-2001");
            assertThat(ergebnis.get(0).value).contains("Antrag KFZ").contains("geprüft: ok");
        }
    }
}
