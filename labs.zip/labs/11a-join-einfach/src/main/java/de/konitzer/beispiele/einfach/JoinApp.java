package de.konitzer.beispiele.einfach;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.JoinWindows;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.StreamJoined;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.config.TopicBuilder;

/**
 * Zwei Events zusammenführen (Stream-Stream-Join) – der Einstieg in Kafka Streams.
 *
 * Die Eingänge liefert 04-producer-spring mit --app.eingabe=true --app.topic=antraege bzw. pruefungen.
 * Ausführlicher (vier Topologien, Tests mit TopologyTestDriver): Modul 11-streams.
 *
 * Ein Antrag (Topic antraege) und die Risikoprüfung (Topic pruefungen) zum selben Vertrag
 * – gleicher Key – werden zusammengeführt, wenn sie höchstens app.fenster-minuten auseinanderliegen.
 * Das Ergebnis geht als Police in das Topic policen. Die Reihenfolge der beiden Events ist egal.
 */
@SpringBootApplication
@EnableKafkaStreams
public class JoinApp {

    private static final DateTimeFormatter ZEIT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public static void main(String[] args) {
        SpringApplication.run(JoinApp.class, args);
    }

    /** Topics als Code. Beide Eingänge mit gleicher Partitionsanzahl: Voraussetzung für den Join. */
    @Bean
    NewTopic antraege(@Value("${app.topic-antraege}") String name, @Value("${app.partitionen}") int p, @Value("${app.replikation}") short r) {
        return TopicBuilder.name(name).partitions(p).replicas(r).config("min.insync.replicas", "2").build();
    }

    @Bean
    NewTopic pruefungen(@Value("${app.topic-pruefungen}") String name, @Value("${app.partitionen}") int p, @Value("${app.replikation}") short r) {
        return TopicBuilder.name(name).partitions(p).replicas(r).config("min.insync.replicas", "2").build();
    }

    @Bean
    NewTopic policen(@Value("${app.topic-policen}") String name, @Value("${app.partitionen}") int p, @Value("${app.replikation}") short r) {
        return TopicBuilder.name(name).partitions(p).replicas(r).config("min.insync.replicas", "2").build();
    }

    @Bean
    KStream<String, String> zusammenfuehren(StreamsBuilder builder,
                                            @Value("${app.topic-antraege}") String antraegeTopic,
                                            @Value("${app.topic-pruefungen}") String pruefungenTopic,
                                            @Value("${app.topic-policen}") String policenTopic,
                                            @Value("${app.fenster-minuten}") long fensterMinuten) {
        System.out.printf("%nJoin bereit: %s + %s -> %s, Zeitfenster %d min. Beenden mit Strg+C.%n%n",
                antraegeTopic, pruefungenTopic, policenTopic, fensterMinuten);

        KStream<String, String> antraege = builder.<String, String>stream(antraegeTopic)
                .peek((vertrag, antrag) -> System.out.printf("%s  Antrag     key=%-8s \"%s\" – wartet auf die Prüfung%n", jetzt(), vertrag, antrag));

        KStream<String, String> pruefungen = builder.<String, String>stream(pruefungenTopic)
                .peek((vertrag, pruefung) -> System.out.printf("%s  Prüfung    key=%-8s \"%s\" – wartet auf den Antrag%n", jetzt(), vertrag, pruefung));

        // Gleicher Key + beide Events im Zeitfenster -> ein Ergebnis. Kafka Streams hält dafür beide Seiten
        // im lokalen Zustand (RocksDB) und sichert ihn in Changelog-Topics.
        KStream<String, String> policenStream = antraege.join(
                pruefungen,
                (antrag, pruefung) -> "Police aus Antrag \"" + antrag + "\" und Prüfung \"" + pruefung + "\"",
                JoinWindows.ofTimeDifferenceWithNoGrace(Duration.ofMinutes(fensterMinuten)),
                // Benannter Zustand: interne Topics heißen dann join-einfach-antrag-pruefung-…-changelog
                StreamJoined.with(Serdes.String(), Serdes.String(), Serdes.String())
                        .withStoreName("antrag-pruefung"));

        policenStream
                .peek((vertrag, police) -> System.out.printf("%s  ZUSAMMEN   key=%-8s %s%n", jetzt(), vertrag, police))
                .to(policenTopic);

        return policenStream;
    }

    private static String jetzt() {
        return LocalTime.now().format(ZEIT);
    }
}
