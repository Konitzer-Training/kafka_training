#!/usr/bin/env bash
# Nach "--bestand.fehlerbehandlung=dlt" und einer Poison Pill: Was liegt im Dead-Letter-Topic?
docker exec -it kafka1 /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server kafka1:9092 \
    --topic bestand.vertragsaenderungen-dlt --from-beginning --timeout-ms 10000 \
    --formatter-property print.key=true --formatter-property print.headers=true
