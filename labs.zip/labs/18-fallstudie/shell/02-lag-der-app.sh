#!/usr/bin/env bash
# Lag der Spring-Instanzen (Gruppe bestandsverwaltung-app) und wer welche Partitionen hat
docker exec -it kafka1 /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 \
    --describe --group bestandsverwaltung-app
docker exec -it kafka1 /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka1:9092 \
    --describe --group bestandsverwaltung-app --members
