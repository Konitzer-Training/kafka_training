#!/usr/bin/env bash
# Gegenbeispiel zur Fallstudie: Share Group (Queue-Semantik) – siehe 01-shell/09-share-group.sh
# Dort: jede Nachricht an irgendeinen Consumer, keine Reihenfolge je Vertrag. Für Versionen falsch.
exec "$(dirname "$0")/../../01-shell/09-share-group.sh" orders queue-demo
