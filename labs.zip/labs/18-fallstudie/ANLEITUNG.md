# 18-fallstudie – Arbeitsanweisung

**Was es zeigt:** Die Fallstudie aus Deck 07 (früher `bestand-demo`): ein Quellsystem schreibt Vertragsänderungen mit Versionsnummer, die Bestandsverwaltung verbucht sie je Vertrag streng in Reihenfolge. Per HTTP lassen sich Last, Absturz und eine Poison Pill auslösen. Zwei Fehlerstrategien: anhalten (richtig bei abhängigen Versionen) oder Dead-Letter-Topic (zum Vergleich).

**Buch:** Kapitel 18 (Fallstudie), dazu 6, 9 und 14.

## Vorführung (20 Minuten)

Reihenfolge wie in `Befehle-Seminar.md`, Abschnitt 9.7 bis 9.14. Kurzfassung:

1. Instanz 1 starten, dann http://localhost:8081 öffnen:
   ```powershell
   java -jar 18-fallstudie\target\18-fallstudie-app.jar
   ```
2. Instanz 2 im zweiten Fenster: `--server.port=8082`
3. Peak, 6000 Änderungen mit 200/s:
   ```powershell
   curl.exe -X POST "http://localhost:8081/api/quelle/last?anzahl=6000&proSekunde=200"
   ```
4. Lag: `shell\02-lag-der-app.sh` oder `01-shell\06-gruppe-ansehen.ps1 -Gruppe bestandsverwaltung-app`. Grafana: beide Instanzen unter `client_id=bestand-app`.
5. Absturz von Instanz 2 (etwa 45 s Stille, dann übernimmt Instanz 1):
   ```powershell
   curl.exe -X POST http://localhost:8082/api/betrieb/absturz
   ```
6. Poison Pill: fehlerhafte Änderung an V-1001, der Container hält an:
   ```powershell
   curl.exe -X POST "http://localhost:8081/api/quelle/fehler?vertrag=V-1001"
   ```
7. Korrigieren und weiterlaufen lassen:
   ```powershell
   curl.exe -X POST http://localhost:8081/api/betrieb/korrigieren
   curl.exe -X POST http://localhost:8081/api/betrieb/starten
   ```
8. Vergleich DLT (App vorher beenden): `--bestand.fehlerbehandlung=dlt`, Schritt 6 wiederholen, `shell\03-dlt-ansehen.sh`.

Was die Fallstudie **nicht** zeigt, zeigen die Module 09a/09b/09c am Code: Retry mit Backoff, Outbox, Kafka-Transaktionen (Fahrplan Deck 07, „Die Kette am Code“).

## Aufgaben

1. Setzen Sie `spring.kafka.listener.concurrency=6` und wiederholen Sie Schritt 3. Wird der Lag schneller abgebaut? Warum ändert eine dritte Instanz dann nichts mehr?
2. Setzen Sie `bestand.verarbeitung-ms=0` und finden Sie mit `proSekunde=2000`, wo die Grenze liegt.
3. Übertragen Sie `Verbuchungsmetriken` aus `14-monitoring` in diese App und zeigen Sie die Zähler in Grafana.

## Ändern und bauen

- **IntelliJ:** `18-fallstudie → BestandDemoApplication → main`; zweite Instanz mit `--server.port=8082` (Allow multiple instances).
- **Bauen:** `.\mvnw.cmd -pl 18-fallstudie -am package -DskipTests`
- **Mit Test** (EmbeddedKafka plus HTTP, Rauchtest): `.\mvnw.cmd -pl 18-fallstudie -am verify`
- Die verbuchten Versionen liegen im Ordner `daten/versionen` neben dem JAR. Für einen frischen Lauf löschen und das Topic `bestand.vertragsaenderungen` ebenfalls (`01-shell\08-topic-loeschen.ps1 -Topic bestand.vertragsaenderungen`).
