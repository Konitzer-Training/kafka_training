package de.konitzer.bestand;

import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
public class KafkaKonfiguration {

    private static final Logger log = LoggerFactory.getLogger(KafkaKonfiguration.class);

    /** Topics als Code: Die App legt ihr Topic an, falls es fehlt. */
    @Bean
    NewTopic aenderungen(@Value("${bestand.topic}") String topic,
                         @Value("${bestand.partitionen}") int partitionen,
                         @Value("${bestand.replikation}") short replikation) {
        return TopicBuilder.name(topic).partitions(partitionen).replicas(replikation)
                .config("min.insync.replicas", "2")
                .build();
    }

    /** Dead-Letter-Topic für den Vergleich (Fehlerbehandlung "dlt"). Gleiche Partitionsanzahl wie das Quell-Topic. */
    @Bean
    NewTopic deadLetter(@Value("${bestand.topic}") String topic,
                        @Value("${bestand.partitionen}") int partitionen,
                        @Value("${bestand.replikation}") short replikation) {
        return TopicBuilder.name(topic + "-dlt").partitions(partitionen).replicas(replikation).build();
    }

    /**
     * Poison Pill. In beiden Varianten wird blockierend wiederholt:
     * 3 Versuche im Abstand von 1 s, die Partition wartet so lange. Danach entscheidet der Recoverer:
     *  - "anhalten": Container stoppen, Offset NICHT committen -> Reihenfolge bleibt, Mensch entscheidet
     *  - "dlt":      Datensatz ins Dead-Letter-Topic, weiter mit dem nächsten -> spätere Änderungen überholen
     */
    @Bean
    CommonErrorHandler fehlerbehandlung(@Value("${bestand.fehlerbehandlung}") String variante,
                                        KafkaTemplate<String, String> template,
                                        KafkaListenerEndpointRegistry registry) {
        ConsumerRecordRecoverer recoverer = "dlt".equalsIgnoreCase(variante)
                ? new DeadLetterPublishingRecoverer(template)
                : (datensatz, fehler) -> {
                    log.error("ANHALTEN: {} Offset {} (Vertrag {}) scheitert dauerhaft – Bestandsverwaltung wird gestoppt",
                            datensatz.topic() + "-" + datensatz.partition(), datensatz.offset(), datensatz.key());
                    MessageListenerContainer container = registry.getListenerContainer(Bestandsverwaltung.LISTENER_ID);
                    // Stoppen aus einem eigenen Thread – der Consumer-Thread darf sich nicht selbst stoppen
                    new Thread(() -> { if (container != null) container.stop(); }, "anhalten").start();
                    // Exception: Der Datensatz gilt als nicht verarbeitet, sein Offset wird nicht committet
                    throw new IllegalStateException("Bestandsverwaltung angehalten bei Vertrag " + datensatz.key());
                };
        DefaultErrorHandler handler = new DefaultErrorHandler(recoverer, new FixedBackOff(1000L, 2L));
        handler.setRetryListeners((datensatz, fehler, versuch) ->
                log.warn("Versuch {} fehlgeschlagen: Vertrag {} ({})", versuch, datensatz.key(),
                        fehler.getCause() != null ? fehler.getCause().getMessage() : fehler.getMessage()));
        log.info("Fehlerbehandlung: {}", "dlt".equalsIgnoreCase(variante) ? "wiederholen, dann Dead-Letter-Topic" : "wiederholen, dann anhalten");
        return handler;
    }
}
