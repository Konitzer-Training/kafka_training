package de.konitzer.bestand;

import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Das Quellsystem (Producer): erzeugt Vertragsänderungen mit fortlaufender Version je Vertrag.
 *
 * Key = Vertragsnummer -> gleiche Partition -> Reihenfolge pro Vertrag.
 * In Produktion käme die Version aus der Outbox-Tabelle des Quellsystems; hier aus daten/quelle.
 */
@Component
public class Quelle {

    private static final Logger log = LoggerFactory.getLogger(Quelle.class);

    private final KafkaTemplate<String, String> kafka;
    private final String topic;
    private final VersionsSpeicher versionen;

    final AtomicLong gesendet = new AtomicLong();
    private volatile Thread peak;

    public Quelle(KafkaTemplate<String, String> kafka, @Value("${bestand.topic}") String topic) throws IOException {
        this.kafka = kafka;
        this.topic = topic;
        this.versionen = new VersionsSpeicher("daten/quelle");
    }

    /** Eine Änderung an einem Vertrag senden; liefert die vergebene Version. */
    public synchronized int sende(String vertrag, String aenderung) {
        int version = versionen.letzteVersion(vertrag) + 1;
        versionen.speichere(vertrag, version);
        kafka.send(topic, vertrag, version + "|" + aenderung)
                .whenComplete((ergebnis, fehler) -> {
                    if (fehler != null) {
                        log.error("Senden fehlgeschlagen: {} v{}: {}", vertrag, version, fehler.getMessage());
                    }
                });
        gesendet.incrementAndGet();
        return version;
    }

    /** Peak simulieren: anzahl Änderungen mit proSekunde, verteilt auf vertraege Verträge (V-1000 ...). */
    public synchronized boolean starteLast(int anzahl, int proSekunde, int vertraege) {
        if (laeuftLast()) {
            return false;
        }
        long pauseNanos = 1_000_000_000L / Math.max(1, proSekunde);
        peak = new Thread(() -> {
            log.info("Peak: {} Änderungen mit {}/s auf {} Verträge", anzahl, proSekunde, vertraege);
            long naechste = System.nanoTime();
            for (int i = 0; i < anzahl && !Thread.currentThread().isInterrupted(); i++) {
                String vertrag = "V-" + (1000 + ThreadLocalRandom.current().nextInt(vertraege));
                sende(vertrag, ARTEN[ThreadLocalRandom.current().nextInt(ARTEN.length)]);
                naechste += pauseNanos;
                long warten = naechste - System.nanoTime();
                if (warten > 0) {
                    try {
                        Thread.sleep(warten / 1_000_000, (int) (warten % 1_000_000));
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
            log.info("Peak beendet");
        }, "peak");
        peak.start();
        return true;
    }

    public void stoppeLast() {
        Thread t = peak;
        if (t != null) {
            t.interrupt();
        }
    }

    public boolean laeuftLast() {
        Thread t = peak;
        return t != null && t.isAlive();
    }

    public void zuruecksetzen() throws IOException {
        versionen.leeren();
        gesendet.set(0);
    }

    private static final String[] ARTEN = {
            "Adresse geändert", "Bankverbindung geändert", "Beitrag angepasst", "Deckung erweitert",
            "Zahlweise geändert", "Begünstigten geändert", "Dynamik angenommen", "Name geändert"
    };
}
