package de.konitzer.bestand;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Der "Bestand": zuletzt verbuchte Version je Vertrag.
 *
 * In Produktion ist das die Datenbank der Bestandsverwaltung. Für die Demo eine Datei pro Vertrag
 * (daten/versionen/V-1001), damit der Stand einen Absturz überlebt und mehrere Instanzen ihn teilen.
 * Jede Partition hat genau einen Consumer – zwei Instanzen schreiben also nie denselben Vertrag gleichzeitig.
 */
@Component
public class VersionsSpeicher {

    private final Path verzeichnis;

    public VersionsSpeicher(@Value("${bestand.datenverzeichnis}") String verzeichnis) throws IOException {
        this.verzeichnis = Path.of(verzeichnis);
        Files.createDirectories(this.verzeichnis);
    }

    /** Zuletzt verbuchte Version, 0 wenn der Vertrag noch unbekannt ist. */
    public int letzteVersion(String vertrag) {
        Path datei = verzeichnis.resolve(vertrag);
        try {
            return Files.exists(datei) ? Integer.parseInt(Files.readString(datei).trim()) : 0;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public void speichere(String vertrag, int version) {
        try {
            Path tmp = verzeichnis.resolve(vertrag + ".tmp");
            Files.writeString(tmp, Integer.toString(version), StandardCharsets.UTF_8);
            Files.move(tmp, verzeichnis.resolve(vertrag), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** Für einen frischen Lauf: alle gespeicherten Versionen löschen. */
    public int leeren() throws IOException {
        try (var dateien = Files.list(verzeichnis)) {
            int anzahl = 0;
            for (Path p : (Iterable<Path>) dateien::iterator) {
                Files.deleteIfExists(p);
                anzahl++;
            }
            return anzahl;
        }
    }
}
