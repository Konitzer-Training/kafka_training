package de.konitzer.bestand;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Bedienung der Demo – im Browser über http://localhost:8081 oder per curl.exe:
 *   curl.exe -X POST "http://localhost:8081/api/quelle/last?anzahl=6000&proSekunde=200"
 */
@RestController
@RequestMapping("/api")
public class DemoController {

    private final Quelle quelle;
    private final Bestandsverwaltung bestandsverwaltung;
    private final VersionsSpeicher bestand;
    private final KafkaListenerEndpointRegistry registry;
    private final String fehlerbehandlung;

    public DemoController(Quelle quelle, Bestandsverwaltung bestandsverwaltung, VersionsSpeicher bestand,
                          KafkaListenerEndpointRegistry registry,
                          @Value("${bestand.fehlerbehandlung}") String fehlerbehandlung) {
        this.quelle = quelle;
        this.bestandsverwaltung = bestandsverwaltung;
        this.bestand = bestand;
        this.registry = registry;
        this.fehlerbehandlung = fehlerbehandlung;
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        MessageListenerContainer c = container();
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("bestandsverwaltungLaeuft", c.isRunning());
        s.put("partitionen", c.getAssignedPartitions() == null ? List.of()
                : c.getAssignedPartitions().stream().map(tp -> tp.partition()).sorted().toList());
        s.put("fehlerbehandlung", fehlerbehandlung);
        s.put("fehlerKorrigiert", bestandsverwaltung.isFehlerKorrigiert());
        s.put("peakLaeuft", quelle.laeuftLast());
        s.put("gesendet", quelle.gesendet.get());
        s.put("verbucht", bestandsverwaltung.verbucht.get());
        s.put("duplikate", bestandsverwaltung.duplikate.get());
        s.put("reihenfolgeVerletzt", bestandsverwaltung.luecken.get());
        return s;
    }

    @PostMapping("/quelle/aenderung")
    public Map<String, Object> aenderung(@RequestParam(defaultValue = "V-1001") String vertrag,
                                         @RequestParam(defaultValue = "Adresse geändert") String text) {
        return Map.of("vertrag", vertrag, "version", quelle.sende(vertrag, text));
    }

    /** Poison Pill plus zwei normale Folgeänderungen am selben Vertrag – zeigt, ob die Reihenfolge hält. */
    @PostMapping("/quelle/fehler")
    public Map<String, Object> fehler(@RequestParam(defaultValue = "V-1001") String vertrag) {
        int v1 = quelle.sende(vertrag, Bestandsverwaltung.FEHLERHAFT);
        int v2 = quelle.sende(vertrag, "Beitrag angepasst");
        int v3 = quelle.sende(vertrag, "Kündigung");
        return Map.of("vertrag", vertrag, "fehlerhaft", v1, "danach", List.of(v2, v3));
    }

    @PostMapping("/quelle/last")
    public Map<String, Object> last(@RequestParam(defaultValue = "6000") int anzahl,
                                    @RequestParam(defaultValue = "200") int proSekunde,
                                    @RequestParam(defaultValue = "200") int vertraege) {
        return Map.of("gestartet", quelle.starteLast(anzahl, proSekunde, vertraege));
    }

    @PostMapping("/quelle/stopp")
    public Map<String, Object> stopp() {
        quelle.stoppeLast();
        return Map.of("peak", "gestoppt");
    }

    /** Fehler in der Verarbeitung "beheben" – danach geht die fehlerhafte Änderung durch. */
    @PostMapping("/betrieb/korrigieren")
    public Map<String, Object> korrigieren() {
        bestandsverwaltung.korrigiereFehler();
        return status();
    }

    @PostMapping("/betrieb/starten")
    public Map<String, Object> starten() {
        container().start();
        return status();
    }

    @PostMapping("/betrieb/stoppen")
    public Map<String, Object> stoppen() {
        container().stop();
        return status();
    }

    /** Absturz simulieren: Prozess sofort beenden, ohne Commit und ohne sauberes Abmelden aus der Gruppe. */
    @PostMapping("/betrieb/absturz")
    public Map<String, Object> absturz() {
        new Thread(() -> {
            try {
                Thread.sleep(200);
            } catch (InterruptedException ignored) {
                // egal, wir beenden ohnehin
            }
            Runtime.getRuntime().halt(1);
        }).start();
        return Map.of("absturz", "in 0,2 s");
    }

    /** Für einen frischen Lauf: gespeicherte Versionen in Quelle und Bestand löschen (Topic vorher neu anlegen). */
    @PostMapping("/betrieb/zuruecksetzen")
    public Map<String, Object> zuruecksetzen() throws IOException {
        quelle.zuruecksetzen();
        int geloescht = bestand.leeren();
        bestandsverwaltung.setzeZurueck();
        return Map.of("geloeschteVertraege", geloescht);
    }

    private MessageListenerContainer container() {
        return registry.getListenerContainer(Bestandsverwaltung.LISTENER_ID);
    }
}
