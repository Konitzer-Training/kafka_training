package de.konitzer.bestand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Fallstudie Bestandsverwaltung (Seminar Apache Kafka, Generali, 02.–03.11.2026).
 *
 * Eine App, zwei Rollen:
 *  - Quelle (Producer): schickt Vertragsänderungen, Key = Vertragsnummer
 *  - Bestandsverwaltung (Consumer Group): verbucht sie in Reihenfolge pro Vertrag
 *
 * Bedienung im Browser: http://localhost:8081
 */
@SpringBootApplication
public class BestandDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BestandDemoApplication.class, args);
    }
}
