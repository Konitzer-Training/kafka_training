package de.konitzer.bestand;

import java.util.concurrent.atomic.AtomicLong;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Die Bestandsverwaltung als Consumer Group.
 *
 * Reihenfolge pro Vertrag:
 *  - Key = Vertragsnummer -> alle Änderungen eines Vertrags liegen in derselben Partition
 *  - pro Partition genau ein Thread (concurrency=3 bei 6 Partitionen), keine Weitergabe an einen Thread-Pool
 *
 * Idempotent über die Versionsnummer:
 *  - Version schon verbucht      -> Duplikat, überspringen (passiert nach einem Absturz: at-least-once)
 *  - Version größer als erwartet -> Lücke, eine frühere Änderung fehlt: Die Reihenfolge ist verletzt
 */
@Component
public class Bestandsverwaltung {

    static final String LISTENER_ID = "bestand";
    /** Änderungstext, der bei der Verarbeitung scheitert (Poison Pill), bis er "korrigiert" wurde. */
    static final String FEHLERHAFT = "FEHLERHAFT";

    private static final Logger log = LoggerFactory.getLogger(Bestandsverwaltung.class);

    private final VersionsSpeicher bestand;
    private final long verarbeitungMs;
    private volatile boolean fehlerKorrigiert = false;

    final AtomicLong verbucht = new AtomicLong();
    final AtomicLong duplikate = new AtomicLong();
    final AtomicLong luecken = new AtomicLong();

    public Bestandsverwaltung(VersionsSpeicher bestand, @Value("${bestand.verarbeitung-ms}") long verarbeitungMs) {
        this.bestand = bestand;
        this.verarbeitungMs = verarbeitungMs;
    }

    /** Wert eines Datensatzes: "<version>|<änderung>", z. B. "3|Adresse geändert". */
    @KafkaListener(id = LISTENER_ID, idIsGroup = false, topics = "${bestand.topic}")
    public void verarbeite(ConsumerRecord<String, String> datensatz) throws InterruptedException {
        String vertrag = datensatz.key();
        String[] teile = datensatz.value().split("\\|", 2);
        int version = Integer.parseInt(teile[0]);
        String aenderung = teile.length > 1 ? teile[1] : "";

        int letzte = bestand.letzteVersion(vertrag);
        if (version <= letzte) {
            duplikate.incrementAndGet();
            log.info("P{} @{}  {} v{}  DUPLIKAT – v{} ist schon verbucht, übersprungen",
                    datensatz.partition(), datensatz.offset(), vertrag, version, letzte);
            return;
        }
        if (version > letzte + 1) {
            luecken.incrementAndGet();
            log.warn("P{} @{}  {} v{}  REIHENFOLGE VERLETZT – erwartet v{}, Änderung(en) dazwischen fehlen",
                    datensatz.partition(), datensatz.offset(), vertrag, version, letzte + 1);
        }

        if (FEHLERHAFT.equals(aenderung) && !fehlerKorrigiert) {
            throw new IllegalStateException("Änderung an " + vertrag + " v" + version + " ist fehlerhaft");
        }

        Thread.sleep(verarbeitungMs);   // fachliche Verarbeitung
        bestand.speichere(vertrag, version);
        verbucht.incrementAndGet();
        log.info("P{} @{}  {} v{}  verbucht: {}", datensatz.partition(), datensatz.offset(), vertrag, version, aenderung);
    }

    void korrigiereFehler() {
        fehlerKorrigiert = true;
    }

    boolean isFehlerKorrigiert() {
        return fehlerKorrigiert;
    }

    void setzeZurueck() {
        fehlerKorrigiert = false;
        verbucht.set(0);
        duplikate.set(0);
        luecken.set(0);
    }
}
