package de.konitzer.bestand;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;

/** Rauchtest: Die App startet gegen einen eingebetteten Broker, nimmt Last an und verbucht sie. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "bestand.replikation=1", "bestand.verarbeitung-ms=0",
        "bestand.datenverzeichnis=target/test-versionen"})
@EmbeddedKafka(partitions = 6)
class FallstudieIT {

    @Autowired Environment env;

    // Spring Boot 4: TestRestTemplate liegt in einem eigenen Modul; RestClient aus spring-web reicht hier
    private RestClient http() {
        return RestClient.create("http://localhost:" + env.getProperty("local.server.port"));
    }

    @Test
    void lastWirdVerbucht() {
        String antwort = http().post().uri("/api/quelle/last?anzahl=50&proSekunde=1000").retrieve().body(String.class);
        assertThat(antwort).isNotNull();
        await().atMost(Duration.ofSeconds(30)).untilAsserted(() -> {
            String metriken = http().get().uri("/actuator/prometheus").retrieve().body(String.class);
            assertThat(metriken).contains("kafka_consumer_fetch_manager_records_consumed_total");
        });
    }
}
