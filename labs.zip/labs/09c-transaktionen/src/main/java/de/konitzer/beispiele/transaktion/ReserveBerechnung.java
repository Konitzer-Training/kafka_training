package de.konitzer.beispiele.transaktion;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import de.konitzer.beispiele.ereignisse.Reserve;
import de.konitzer.beispiele.ereignisse.Schadenmeldung;

/**
 * Mit spring.kafka.producer.transaction-id-prefix führt der Listener-Container jeden Datensatz in einer
 * Kafka-Transaktion aus: Was hier mit dem KafkaTemplate gesendet wird, und der Offset der gelesenen
 * Meldung werden gemeinsam festgeschrieben – oder, wenn der Listener wirft, gemeinsam verworfen.
 */
@Component
public class ReserveBerechnung {

    private static final Logger log = LoggerFactory.getLogger(ReserveBerechnung.class);

    private final KafkaTemplate<String, Object> kafka;
    private final String reservenTopic;

    ReserveBerechnung(KafkaTemplate<String, Object> kafka, @Value("${app.topic-reserven}") String reservenTopic) {
        this.kafka = kafka;
        this.reservenTopic = reservenTopic;
    }

    @KafkaListener(id = "reserven", idIsGroup = false, topics = "${app.topic-meldungen}")
    void reserveBerechnen(Schadenmeldung meldung) {
        // Das Reserve-Ereignis ist schon gesendet, wenn die Prüfung wirft – es gehört zur Transaktion
        // und wird mit ihr verworfen. Consumer mit read_committed sehen es nie.
        var reserve = new Reserve(meldung.schadennummer(), berechne(meldung.betrag()), "120 % der Meldung");
        kafka.send(reservenTopic, meldung.schadennummer(), reserve);
        // Nur für die Vorführung: Beim Abbruch verwirft der Producer, was noch im Puffer liegt – dann
        // käme nichts beim Broker an und read_uncommitted hätte nichts zu zeigen. flush() schickt es vorher.
        kafka.flush();

        if (meldung.betrag().signum() <= 0) {
            throw new IllegalArgumentException("Schadensumme muss positiv sein: " + meldung.betrag());
        }
        log.info("Reserve für {} (Vertrag {}): {} EUR", meldung.schadennummer(), meldung.vertragsnummer(),
                reserve.betrag());
    }   // Commit der Transaktion: Reserve-Ereignis und Offset der Meldung

    static BigDecimal berechne(BigDecimal schadensumme) {
        return schadensumme.multiply(new BigDecimal("1.20")).setScale(2, RoundingMode.HALF_UP);
    }
}
