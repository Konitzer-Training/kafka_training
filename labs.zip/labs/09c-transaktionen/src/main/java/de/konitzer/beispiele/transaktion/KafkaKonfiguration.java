package de.konitzer.beispiele.transaktion;

import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.listener.AfterRollbackProcessor;
import org.springframework.kafka.listener.DefaultAfterRollbackProcessor;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
class KafkaKonfiguration {

    private static final Logger log = LoggerFactory.getLogger(KafkaKonfiguration.class);

    @Bean
    NewTopic meldungen(@Value("${app.topic-meldungen}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic).partitions(3).replicas(rf).build();
    }

    @Bean
    NewTopic reserven(@Value("${app.topic-reserven}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic).partitions(3).replicas(rf).build();
    }

    /**
     * Bei Transaktionen übernimmt der AfterRollbackProcessor die Rolle des Error Handlers:
     * Nach dem Abbruch wird zurückgesetzt und wiederholt; danach wird der Datensatz übersprungen.
     */
    @Bean
    AfterRollbackProcessor<Object, Object> nachRollback(@Value("${app.wiederholungen}") long wiederholungen) {
        return new DefaultAfterRollbackProcessor<>((datensatz, fehler) ->
                log.error("ÜBERSPRUNGEN nach {} Wiederholungen: {} @{}: {}", wiederholungen, datensatz.key(),
                        datensatz.offset(), fehler.getCause() != null ? fehler.getCause().getMessage() : fehler.getMessage()),
                new FixedBackOff(500L, wiederholungen));
    }
}
