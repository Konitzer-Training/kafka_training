package de.konitzer.beispiele.transaktion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kapitel 9: Kafka-Transaktionen. Schadenmeldung lesen, Reserve berechnen, Reserve-Ereignis schreiben –
 * Lesen (Offset-Commit) und Schreiben in EINER Kafka-Transaktion.
 *
 * Start: java -jar 09c-transaktionen.jar
 */
@SpringBootApplication
public class TransaktionApp {

    public static void main(String[] args) {
        SpringApplication.run(TransaktionApp.class, args);
    }
}
