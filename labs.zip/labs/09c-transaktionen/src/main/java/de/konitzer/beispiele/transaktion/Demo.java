package de.konitzer.beispiele.transaktion;

import java.math.BigDecimal;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import de.konitzer.beispiele.ereignisse.Schadenmeldung;

/**
 * Konsolen-Demo: zwei gültige Meldungen und eine mit negativer Summe. Danach mit der Konsole vergleichen:
 *   kafka-console-consumer.sh … --topic schaden.reserven --from-beginning --isolation-level read_committed
 *   kafka-console-consumer.sh … --topic schaden.reserven --from-beginning --isolation-level read_uncommitted
 */
@Configuration
@ConditionalOnProperty(name = "app.demo", havingValue = "true", matchIfMissing = true)
class Demo {

    @Bean
    CommandLineRunner demoLauf(KafkaTemplate<String, Object> kafka, @Value("${app.topic-meldungen}") String topic) {
        return args -> {
            Thread.sleep(3000);
            System.out.println();
            System.out.println("Demo Kafka-Transaktionen. Beenden mit Strg+C.");
            System.out.println();
            // Ein transaktionaler Producer sendet nur innerhalb einer Transaktion
            kafka.executeInTransaction(t -> {
                t.send(topic, "S-5001", new Schadenmeldung("S-5001", "V-1001", new BigDecimal("1500.00"), Instant.now()));
                t.send(topic, "S-5002", new Schadenmeldung("S-5002", "V-1002", new BigDecimal("-10.00"), Instant.now()));
                t.send(topic, "S-5003", new Schadenmeldung("S-5003", "V-1003", new BigDecimal("250.00"), Instant.now()));
                return null;
            });
        };
    }
}
