package de.konitzer.beispiele.transaktion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;

import de.konitzer.beispiele.ereignisse.Schadenmeldung;

/**
 * read_committed sieht nur die Reserve der gültigen Meldung. read_uncommitted sieht auch die Reserven
 * der abgebrochenen Versuche – deshalb müssen Consumer transaktionaler Topics read_committed setzen.
 */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "app.demo=false", "app.replikation=1", "app.wiederholungen=2"
})
@EmbeddedKafka(partitions = 3)
class TransaktionIT {

    @Autowired KafkaTemplate<String, Object> kafka;
    @Autowired EmbeddedKafkaBroker broker;
    @Value("${app.topic-meldungen}") String meldungen;
    @Value("${app.topic-reserven}") String reserven;

    @Test
    void abgebrocheneTransaktionBleibtFuerReadCommittedUnsichtbar() {
        kafka.executeInTransaction(t -> {
            t.send(meldungen, "S-5001", new Schadenmeldung("S-5001", "V-1001", new BigDecimal("1500.00"), Instant.now()));
            t.send(meldungen, "S-5002", new Schadenmeldung("S-5002", "V-1002", new BigDecimal("-10.00"), Instant.now()));
            return null;
        });

        await().atMost(Duration.ofSeconds(30)).untilAsserted(() -> {
            List<ConsumerRecord<String, String>> committed = lese(reserven, "read_committed");
            assertThat(committed).extracting(ConsumerRecord::key).containsExactly("S-5001");
            assertThat(committed.get(0).value()).contains("\"betrag\":1800.00");
        });

        // 1 Versuch + 2 Wiederholungen = 3 abgebrochene Reserven für S-5002, plus die gültige
        await().atMost(Duration.ofSeconds(30)).untilAsserted(() ->
                assertThat(lese(reserven, "read_uncommitted"))
                        .extracting(ConsumerRecord::key)
                        .containsExactlyInAnyOrder("S-5001", "S-5002", "S-5002", "S-5002"));
    }

    private List<ConsumerRecord<String, String>> lese(String topic, String isolation) {
        var props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, broker.getBrokersAsString());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "test-" + System.nanoTime());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolation);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        try (var consumer = new KafkaConsumer<String, String>(props)) {
            consumer.subscribe(List.of(topic));
            var gelesen = new ArrayList<ConsumerRecord<String, String>>();
            long ende = System.currentTimeMillis() + 3000;
            while (System.currentTimeMillis() < ende) {
                consumer.poll(Duration.ofMillis(300)).forEach(gelesen::add);
            }
            return gelesen;
        }
    }
}
