package de.konitzer.beispiele.consumer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * Der Bestand: die zuletzt verbuchte Version je Vertrag.
 * In Produktion die Datenbank der Bestandsverwaltung; hier eine Map im Speicher.
 */
@Component
public class Bestand {

    private final Map<String, Integer> versionen = new ConcurrentHashMap<>();

    /** 0, wenn der Vertrag noch unbekannt ist. */
    public int letzteVersion(String vertragsnummer) {
        return versionen.getOrDefault(vertragsnummer, 0);
    }

    public void speichere(String vertragsnummer, int version) {
        versionen.put(vertragsnummer, version);
    }

    public int anzahlVertraege() {
        return versionen.size();
    }
}
