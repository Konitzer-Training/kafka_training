package de.konitzer.beispiele.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

/**
 * Minimale Fehlerbehandlung für dieses Kapitel: Eine Nachricht, die kein gültiges JSON ist,
 * meldet der ErrorHandlingDeserializer als Fehler; sie wird protokolliert und übersprungen.
 * Wiederholen, anhalten und Dead-Letter-Topic: Kapitel 9 (Modul 09a-fehlerbehandlung).
 */
@Configuration
class Fehlerbehandlung {

    private static final Logger log = LoggerFactory.getLogger(Fehlerbehandlung.class);

    @Bean
    CommonErrorHandler errorHandler() {
        return new DefaultErrorHandler((datensatz, fehler) -> log.warn("ÜBERSPRUNGEN: P{} @{} key={}: {}",
                datensatz.partition(), datensatz.offset(), datensatz.key(), ursache(fehler)),
                new FixedBackOff(0L, 0L));   // keine Wiederholung
    }

    private static String ursache(Throwable fehler) {
        Throwable t = fehler;
        while (t.getCause() != null) {
            t = t.getCause();
        }
        return t.getClass().getSimpleName() + ": " + t.getMessage();
    }
}
