package de.konitzer.beispiele.consumer;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Component;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Die Fachlogik – ohne Kafka. Der Listener ruft nur diese Klasse auf;
 * so lässt sie sich mit einem einfachen Unit-Test prüfen (Kapitel 13).
 *
 * Idempotent über die Versionsnummer:
 *  - Version schon verbucht      -> DUPLIKAT (passiert nach einem Absturz: at-least-once)
 *  - Version größer als erwartet -> LUECKE, eine frühere Änderung fehlt (wird trotzdem verbucht und gemeldet)
 */
@Component
public class Verbuchung {

    public enum Ergebnis { VERBUCHT, DUPLIKAT, LUECKE }

    private final Bestand bestand;
    private final AtomicLong verbucht = new AtomicLong();
    private final AtomicLong duplikate = new AtomicLong();
    private final AtomicLong luecken = new AtomicLong();

    public Verbuchung(Bestand bestand) {
        this.bestand = bestand;
    }

    public Ergebnis verarbeite(Vertragsaenderung aenderung) {
        int letzte = bestand.letzteVersion(aenderung.vertragsnummer());
        if (aenderung.version() <= letzte) {
            duplikate.incrementAndGet();
            return Ergebnis.DUPLIKAT;
        }
        Ergebnis ergebnis = Ergebnis.VERBUCHT;
        if (aenderung.version() > letzte + 1) {
            luecken.incrementAndGet();
            ergebnis = Ergebnis.LUECKE;
        }
        // hier stünde die fachliche Verarbeitung: Adresse, Beitrag, Bankverbindung übernehmen
        bestand.speichere(aenderung.vertragsnummer(), aenderung.version());
        verbucht.incrementAndGet();
        return ergebnis;
    }

    public long verbucht() {
        return verbucht.get();
    }

    public long duplikate() {
        return duplikate.get();
    }

    public long luecken() {
        return luecken.get();
    }
}
