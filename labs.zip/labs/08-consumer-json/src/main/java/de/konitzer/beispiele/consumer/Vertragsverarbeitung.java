package de.konitzer.beispiele.consumer;

import java.util.Collection;
import java.util.Map;

import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Der Listener: dünn. Er nimmt das JSON als Record entgegen, ruft die Verbuchung auf
 * und committet erst danach (at-least-once).
 */
@Component
public class Vertragsverarbeitung implements ConsumerSeekAware {

    static final String LISTENER_ID = "bestand";

    private static final Logger log = LoggerFactory.getLogger(Vertragsverarbeitung.class);

    private final Verbuchung verbuchung;

    Vertragsverarbeitung(Verbuchung verbuchung) {
        this.verbuchung = verbuchung;
    }

    /**
     * @Payload: der Wert, schon als Record deserialisiert.
     * @Header: Key, Partition und Offset aus den Metadaten des Datensatzes.
     */
    @KafkaListener(id = LISTENER_ID, idIsGroup = false, topics = "${app.topic}")
    void verarbeite(@Payload Vertragsaenderung aenderung,
                    @Header(KafkaHeaders.RECEIVED_KEY) String vertragsnummer,
                    @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
                    @Header(KafkaHeaders.OFFSET) long offset,
                    Acknowledgment commit) {
        Verbuchung.Ergebnis ergebnis = verbuchung.verarbeite(aenderung);
        log.info("P{} @{}  {} v{} {}  -> {}", partition, offset, vertragsnummer, aenderung.version(),
                aenderung.art(), ergebnis);

        // erst nach der Verarbeitung: Offset nach __consumer_offsets
        commit.acknowledge();
    }

    @Override
    public void onPartitionsAssigned(Map<TopicPartition, Long> partitionen, ConsumerSeekCallback callback) {
        if (!partitionen.isEmpty()) {
            log.info("ZUGEWIESEN: {}", partitionen.keySet());
        }
    }

    @Override
    public void onPartitionsRevoked(Collection<TopicPartition> partitionen) {
        if (!partitionen.isEmpty()) {
            log.info("ABGEGEBEN: {}", partitionen);
        }
    }
}
