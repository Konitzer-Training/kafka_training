package de.konitzer.beispiele.consumer;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

/**
 * Dieselbe Topic-Beschreibung wie im Producer (07): Wer zuerst startet, legt das Topic an.
 * Ohne diese Bean würde der Consumer bis zum Start des Producers "topic does not exist" warnen.
 */
@Configuration
class KafkaTopics {

    @Bean
    NewTopic vertragsaenderungen(@Value("${app.topic}") String topic,
                                 @Value("${app.replikation}") int replikation) {
        return TopicBuilder.name(topic).partitions(6).replicas(replikation)
                .config("min.insync.replicas", "2")
                .build();
    }
}
