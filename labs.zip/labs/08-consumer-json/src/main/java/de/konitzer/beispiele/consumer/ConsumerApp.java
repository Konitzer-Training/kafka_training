package de.konitzer.beispiele.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kapitel 8: Die Bestandsverwaltung liest Vertragsänderungen als JSON und verbucht sie idempotent.
 *
 * Start: java -jar 08-consumer-json.jar   (gern mehrfach – dann teilen sich die Instanzen die Partitionen)
 */
@SpringBootApplication
public class ConsumerApp {

    public static void main(String[] args) {
        SpringApplication.run(ConsumerApp.class, args);
    }
}
