package de.konitzer.beispiele.consumer;

import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Component;

/**
 * Den Listener von außen steuern – etwa aus einem Admin-Endpunkt oder einem Wartungsfenster.
 * pause(): poll() läuft weiter (kein Rebalance), liefert aber nichts. stop(): Consumer verlässt die Gruppe.
 */
@Component
public class Steuerung {

    private final KafkaListenerEndpointRegistry registry;

    Steuerung(KafkaListenerEndpointRegistry registry) {
        this.registry = registry;
    }

    public void anhalten() {
        container().pause();
    }

    public void fortsetzen() {
        container().resume();
    }

    public boolean laeuft() {
        return container().isRunning() && !container().isContainerPaused();
    }

    private MessageListenerContainer container() {
        return registry.getListenerContainer(Vertragsverarbeitung.LISTENER_ID);
    }
}
