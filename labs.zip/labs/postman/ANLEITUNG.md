# postman – die HTTP-Aufrufe des Seminars als Postman-Collection

**Was es ist:** Alles, was in `Befehle-Seminar.md` mit `curl.exe` aufgerufen wird, als Postman-Collection: die Steuerung der Fallstudie (`18-fallstudie`), die Metrik-Endpunkte der Spring-Apps, die Prometheus-API mit den PromQL-Zeilen des Seminars und der Alertmanager. Wer lieber klickt als tippt, nimmt Postman; die Skripte in `14-monitoring/shell` tun dasselbe in der Shell.

## Einrichten (2 Minuten)

1. Postman öffnen, `File → Import`, beide Dateien aus diesem Ordner auswählen: `Kafka-Seminar.postman_collection.json` und `Kafka-Lab-lokal.postman_environment.json`.
2. Oben rechts die Umgebung **Kafka-Lab lokal** wählen. Die Variablen `fallstudie`, `monitoring`, `prometheus`, `alertmanager` zeigen auf `localhost`; für einen anderen Rechner nur dort ändern.
3. Lab läuft (`docker compose up -d` in `kafka-lab`), die jeweilige App ist gestartet.

## Ablauf Fallstudie (Deck 07, 10 Minuten)

| Schritt | Request | Zu sehen |
| --- | --- | --- |
| 1 | `18-fallstudie-app.jar` starten, dann **Status** | `bestandsverwaltungLaeuft: true`, Zähler bei 0 |
| 2 | **Peak: 6000 Änderungen mit 200/s** | `{"gestartet": true}`; im Log der App `verbucht`-Zeilen; in Kafbat UI Lag der Gruppe `bestandsverwaltung-app` |
| 3 | zweite Instanz mit `--server.port=8082`, dann **Status** auf beiden | Partitionen 3 : 3 |
| 4 | **Absturz von Instanz 2** | etwa 45 s Stille, dann übernimmt Instanz 1; im Log `DUPLIKAT`-Zeilen |
| 5 | **Poison Pill** | Log: drei Versuche, `ANHALTEN`; **Status**: `bestandsverwaltungLaeuft: false` |
| 6 | **Fehler korrigieren**, **Bestandsverwaltung starten** | die drei Versionen werden nacheinander verbucht |
| 7 | **Metriken der Fallstudie** | `kafka_consumer_fetch_manager_records_lag_max`, eigene Zähler |

## Ablauf Monitoring (Deck 05)

- **14-monitoring → Nur der Lag**: Micrometer-Sicht auf eine einzelne Metrik, mit Tags (`client_id`, `topic`, `partition`).
- **Prometheus → Lag je Consumer**: dieselbe Metrik nach dem Relabeling als `kafka_consumer_records_lag_max`; beide Werte vergleichen.
- **Prometheus → Alle Alert-Regeln**: Feld `state` je Regel (`inactive`, `pending`, `firing`).
- **Prometheus → Regeln neu laden** nach einer Änderung an `kafka-lab/prometheus/rules.yml`.

## Aufgaben

1. Ergänzen Sie in der Collection einen Request, der `anzahl=2000` mit `proSekunde=2000` sendet. Wie reagiert die Gruppe (Lag, Rebalance)?
2. Bauen Sie aus **Lag je Consumer** einen Postman-Test (Reiter *Tests*), der fehlschlägt, wenn ein Wert über 1000 liegt. Das ist derselbe Gedanke wie die Alert-Regel `ConsumerLagHigh`.
3. Schreiben Sie den Request **Eine Änderung senden** als Postman-Runner mit 20 Iterationen und `vertrag` aus einer CSV-Datei. Beobachten Sie in `01-shell\06-gruppe-ansehen.ps1 -Gruppe bestandsverwaltung-app`, wie sich die Partitionen füllen.

## Was Postman nicht kann

Kafka selbst hat keine HTTP-Schnittstelle. Nachrichten schreiben und lesen geht nur über Client (Shell, Java) oder über eine App davor wie die Fallstudie. Ein REST-Proxy (Kapitel 12) wäre die Brücke; das Lab hat keinen.
