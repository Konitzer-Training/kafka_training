#!/usr/bin/env bash
# 12 – Alle Nachrichten zu einem Key finden
#
# So macht es ein Consumer in der Praxis: alles lesen, nach dem Key filtern. Kafka hat keinen
# Index über Keys; der Filter ist die Anwendung (hier grep). Weil gleicher Key gleiche Partition
# heißt, kommen die Treffer in Reihenfolge und alle aus einer Partition.

TOPIC=${1:-beitraege}
KEY=${2:-V-1001}

docker exec -i kafka1 /opt/kafka/bin/kafka-console-consumer.sh \
    --bootstrap-server kafka1:9092 \
    --topic "$TOPIC" \
    --from-beginning \
    --timeout-ms 10000 \
    --formatter-property print.key=true \
    --formatter-property print.partition=true \
    --formatter-property print.offset=true \
    --formatter-property key.separator=" | " 2>/dev/null \
  | grep -F "| $KEY |"

# Ausgabe: Partition:n | Offset:m | KEY | Wert – alle Zeilen mit derselben Partition.
# Schneller bei großen Topics: Partition mit 10-partition-fuer-key.sh ausrechnen und nur diese
# mit 11-partition-lesen.sh lesen. Bequemer: Kafbat UI → Topic → Messages → Filter nach Key.
