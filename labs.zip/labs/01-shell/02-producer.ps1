# Aufruf in PowerShell:  .\02-producer.ps1   (optional mit -Topic name)
# 02 – Nachrichten schreiben (Console Producer)
#
# Nach dem Start erscheint ein Prompt ">". Jede Zeile wird eine Nachricht.
# Eingabe im Format  key:wert  – zum Beispiel:
#     V-1001:Beitrag 42,50
#     V-1002:Beitrag 19,90
#     V-1001:Beitrag 44,00
# Beenden mit Strg+C.

param([string]$Topic = "beitraege")

docker exec -it kafka1 /opt/kafka/bin/kafka-console-producer.sh  `
    --bootstrap-server kafka1:9092  `
    --topic $Topic  `
    --reader-property parse.key=true  `
    --reader-property key.separator=:  `
    --command-property acks=all  `
    --command-property client.id=console-producer

# parse.key=true, key.separator=:   Die Zeile wird am ersten ":" in Key und Wert geteilt.
#                                   Ohne diese beiden Angaben gibt es keinen Key, und der
#                                   Producer verteilt die Nachrichten selbst auf Partitionen.
# acks=all                          Auf die Bestätigung aller Kopien im ISR warten
#                                   (Default seit Kafka 3.0, hier bewusst sichtbar).
# client.id                         Sprechender Name in Metriken und Broker-Logs.
#
# Der Console Producer zeigt NICHT, in welcher Partition und unter welchem Offset
# die Nachricht gelandet ist. Genau das ist der erste Grund für Java: 02-producer-plain
# gibt beides aus.
