#!/usr/bin/env bash
# 08 – Topic löschen (für einen frischen Durchlauf)
#
# Löscht das Topic samt aller Nachrichten und Offsets. Laufende Consumer legen es
# nicht neu an (auto.create ist im Lab aus) – erst 01 wieder ausführen.

TOPIC=${1:-beitraege}

docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh \
    --bootstrap-server kafka1:9092 \
    --delete \
    --topic "$TOPIC"
