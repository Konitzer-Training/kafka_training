# Aufruf in PowerShell:  .\12-nachrichten-zu-key.ps1 -Key V-1001   (optional -Topic name)
# 12 – Alle Nachrichten zu einem Key finden
#
# So macht es ein Consumer in der Praxis: alles lesen, nach dem Key filtern. Kafka hat keinen
# Index über Keys; der Filter ist die Anwendung (hier Select-String). Weil gleicher Key gleiche
# Partition heißt, kommen die Treffer in Reihenfolge und alle aus einer Partition.

param([string]$Topic = "beitraege", [string]$Key = "V-1001")

docker exec -i kafka1 /opt/kafka/bin/kafka-console-consumer.sh  `
    --bootstrap-server kafka1:9092  `
    --topic $Topic  `
    --from-beginning  `
    --timeout-ms 10000  `
    --formatter-property print.key=true  `
    --formatter-property print.partition=true  `
    --formatter-property print.offset=true  `
    --formatter-property key.separator=" | " 2>$null  `
  | Select-String -SimpleMatch "| $Key |"

# Ausgabe: Partition:n | Offset:m | KEY | Wert – alle Zeilen mit derselben Partition.
# Schneller bei großen Topics: Partition mit 10-partition-fuer-key.ps1 ausrechnen und nur diese
# mit 11-partition-lesen.ps1 lesen. Bequemer: Kafbat UI → Topic → Messages → Filter nach Key.
