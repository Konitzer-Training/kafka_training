# 01-shell – Arbeitsanweisung

**Was es zeigt:** Die Kafka-Befehle aus Tag 1 (Kapitel 3 bis 6) als Skripte mit Erklärungen. Jedes Skript ist ein einziger Befehl, der im Container `kafka1` läuft. Die Skripte sind der Startpunkt: Jedes Java-Modul ab 02 macht dasselbe wie eines dieser Skripte, in den Kommentaren steht jeweils „Dasselbe in Java“.

**Buch:** Kapitel 3 (Erste Schritte), 4 (verteiltes Log), 5 (Zuverlässigkeit), 6 (Consumer Groups), 20 (Befehlsreferenz).

Es gibt jedes Skript zweimal: `.ps1` für PowerShell (Windows), `.sh` für macOS, Linux und Git Bash. Inhalt und Kommentare sind gleich.

## Ablauf (15 Minuten, zwei Fenster)

| Schritt | Fenster | Skript | Zu sehen |
| --- | --- | --- | --- |
| 1 | rechts | `01-topic-anlegen` | `Created topic beitraege` |
| 2 | links | `03-consumer` | wartet |
| 3 | rechts | `02-producer`, dann `V-1001:Beitrag 42,50` usw. tippen | links: `Partition \| Offset \| Key \| Wert` |
| 4 | rechts | `04-topic-ansehen` | Leader, Replicas, Isr je Partition; letzter Offset |
| 5 | links | `05-consumer-gruppe` (Strg+C vorher bei 03) | liest neue Nachrichten, merkt sich den Stand |
| 6 | rechts | `06-gruppe-ansehen` | CURRENT-OFFSET, LOG-END-OFFSET, LAG |
| 7 | links | Strg+C, rechts drei Zeilen senden, `06-gruppe-ansehen` | LAG = 3 |
| 8 | rechts | `07-offsets-zuruecksetzen` (dry-run), dann mit `ausfuehren` | NEW-OFFSET 0 |
| 9 | links | `05-consumer-gruppe` | alles noch einmal |
| 10 | zwei Fenster | `09-share-group` | Queue-Semantik als Gegenbeispiel |

Aufrufe in PowerShell: `.\01-shell\01-topic-anlegen.ps1`, mit Parametern `.\01-topic-anlegen.ps1 -Topic orders -Partitionen 6` oder `.\05-consumer-gruppe.ps1 -Topic orders -Gruppe analytics`. In Bash: `./01-topic-anlegen.sh orders 6`. Im Seminar laufen Tag-1-Labs mit zwei Topics: `beitraege` (3 Partitionen, Erste Schritte und Consumer-Neustart) und `orders` (6 Partitionen, Replikation, Broker-Ausfall, Consumer Groups).

## Wo liegt ein Key? (Skripte 10 bis 12)

Die Frage aus dem Seminar: „Wie weiß ich, in welcher Partition V-1001 liegt?“ Drei Antworten, von der Praxis zur Theorie:

| Skript | Was es tut | Wann |
| --- | --- | --- |
| `12-nachrichten-zu-key` | liest das ganze Topic und filtert nach dem Key; alle Treffer kommen aus einer Partition, in Reihenfolge | so macht es ein Consumer: lesen und filtern, kein Rechnen |
| `11-partition-lesen` | liest genau eine Partition ab einem Offset, ohne Gruppe (`--partition`, `--offset`); das ist `assign` statt `subscribe` | Fehlersuche, Replay einer Partition, Werkzeuge |
| `10-partition-fuer-key` | rechnet die Partition vorab aus, mit derselben Funktion wie der Producer (`BuiltInPartitioner`, murmur2 modulo Partitionsanzahl); ruft `02-producer-plain` im Rechenmodus `-Drechne=` auf | verstehen, warum gleicher Key gleiche Partition heißt; Werkzeuge |

Reihenfolge zum Vorführen: `10` für fünf Keys, dann dieselben Keys mit `02-producer` senden, `03-consumer` zeigt dieselben Partitionen, `12` holt alle Zeilen zu V-1001, `11` liest nur seine Partition. Ein Consumer mit Gruppe wählt die Partition nie selbst: Der Koordinator teilt zu, die Nachricht bringt ihre Partition mit.

## Aufgaben

1. Legen Sie ein Topic mit **einer** Partition an (`01-topic-anlegen` kopieren und ändern). Senden Sie fünf Keys. Was sehen Sie in Spalte Partition?
2. `docker stop kafka3`, dann `04-topic-ansehen`. Was steht bei Isr? Senden Sie weiter: klappt es? `docker start kafka3`.
3. Zwei Fenster mit `05-consumer-gruppe`, gleiche Gruppe. Welches Fenster bekommt welche Partition? Ein Fenster schließen: Was passiert?
4. Warum zeigt `03-consumer` nach jedem Start wieder alles, `05-consumer-gruppe` aber nicht? Antwort steht im Kommentar von 03.
5. `10-partition-fuer-key` für `V-1001` bei `beitraege` (3 Partitionen) und bei `orders` (6 Partitionen): Warum verschiedene Partitionen? Was heißt das für eine nachträgliche Erhöhung der Partitionszahl?

## Ändern

Die Skripte sind Text. Ändern Sie Topic-Name, Partitionen oder Properties direkt in der Datei, kein Build nötig. Alle Optionen der Werkzeuge: `docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh --help` (entsprechend für die anderen). Buch Kapitel 20 listet die wichtigsten.

Shell-Entsprechungen in Java:

| Skript | Java-Modul |
| --- | --- |
| `01-topic-anlegen` | `04-producer-spring` (NewTopic-Bean) |
| `02-producer` | `02-producer-plain`, `04-producer-spring` |
| `03-consumer`, `05-consumer-gruppe` | `03-consumer-plain`, `05-consumer-spring` |
| `06-gruppe-ansehen`, `07-offsets-zuruecksetzen` | `06-consumer-groups` |
| `10-partition-fuer-key`, `11-partition-lesen`, `12-nachrichten-zu-key` | `02-producer-plain` (Rechenmodus `-Drechne=`), Kapitel 6 „eine Nachricht gezielt holen“ |
| `09-share-group` | kein Java-Beispiel (bewusst: Gegenbeispiel) |
