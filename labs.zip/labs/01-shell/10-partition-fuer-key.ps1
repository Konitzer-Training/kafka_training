# Aufruf in PowerShell:  .\10-partition-fuer-key.ps1 -Keys "V-1001,V-1002"   (optional -Topic name)
# 10 – Wo liegt ein Key? Die Partition vorab ausrechnen, ohne zu senden
#
# Der Producer bestimmt die Partition: murmur2(Key-Bytes) modulo Partitionsanzahl. Diese Rechnung
# steckt im Kafka-Client (BuiltInPartitioner). Kein Shell-Werkzeug von Kafka macht sie, deshalb
# ruft dieses Skript das Java-Programm 02-producer-plain im Rechenmodus auf (-Drechne=...).
# Voraussetzung: labs einmal gebaut (mvnw verify), Lab läuft (die Partitionsanzahl wird abgefragt).
#
# Ein Consumer braucht das NICHT: Jede Nachricht, die er liest, trägt ihre Partition
# (ConsumerRecord.partition()). Das Skript ist für Werkzeuge und zum Verstehen.

param([string]$Topic = "beitraege", [string]$Keys = "V-1001,V-1002,V-1003,V-1004,V-1005")

Push-Location (Join-Path $PSScriptRoot "..")
java "-Dtopic=$Topic" "-Drechne=$Keys" -jar 02-producer-plain\target\02-producer-plain-app.jar
Pop-Location

# Probieren: dieselben Keys mit 02-producer.ps1 senden und mit 03-consumer.ps1 lesen –
# die Partition stimmt. Dann das Topic mit 6 Partitionen anlegen: andere Zuordnung (Kapitel 15).
