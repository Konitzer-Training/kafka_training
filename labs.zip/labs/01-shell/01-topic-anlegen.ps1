# Aufruf in PowerShell:  .\01-topic-anlegen.ps1   (optional -Topic name -Partitionen 6)
# 01 – Ein Topic anlegen
#
# Alle Skripte in diesem Ordner rufen die Kafka-Werkzeuge IM Container kafka1 auf.
# Dort liegen sie unter /opt/kafka/bin. "docker exec" führt einen Befehl in einem
# laufenden Container aus; -it verbindet Tastatur und Bildschirm (nötig für Producer).
#
# Der Broker heißt im Docker-Netz kafka1:9092. Von außen (Java auf dem eigenen
# Rechner) heißt derselbe Broker localhost:19092 – das ist der einzige Unterschied
# zwischen den Shell-Skripten und den Java-Beispielen.
#
# Vorher: docker compose up -d im Ordner kafka-lab.

param([string]$Topic = "beitraege", [int]$Partitionen = 3)

docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh  `
    --bootstrap-server kafka1:9092  `
    --create --if-not-exists  `
    --topic $Topic  `
    --partitions $Partitionen  `
    --replication-factor 3  `
    --config min.insync.replicas=2

# --partitions 3           Drei Partitionen: Nachrichten mit gleichem Key landen in
#                          derselben Partition, verschiedene Keys verteilen sich.
# --replication-factor 3   Jede Partition liegt auf allen drei Brokern.
# min.insync.replicas=2    Ein Schreibzugriff mit acks=all gilt erst als erfolgreich,
#                          wenn mindestens zwei Kopien ihn haben.
# --if-not-exists          Kein Fehler, wenn das Topic schon da ist.
#
# Dasselbe in Java: 04-producer-spring legt das Topic beim Start an (NewTopic-Bean).
