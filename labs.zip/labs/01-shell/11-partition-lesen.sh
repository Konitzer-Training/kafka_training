#!/usr/bin/env bash
# 11 – Eine einzelne Partition lesen, ohne Consumer Group
#
# Das ist "assign" statt "subscribe": Der Consumer nimmt sich genau eine Partition und eine
# Startposition, kein Koordinator verteilt etwas, nichts wird committet. Der Weg für Werkzeuge
# und Fehlersuche ("Was liegt in Partition 1 ab Offset 0?"), nicht für die Verarbeitung.
# Welche Partition ein Key hat, sagt 10-partition-fuer-key.sh oder die Ausgabe von 03-consumer.sh.

TOPIC=${1:-beitraege}
PARTITION=${2:-0}
OFFSET=${3:-earliest}      # earliest, latest oder eine Zahl
ANZAHL=${4:-20}

docker exec -it kafka1 /opt/kafka/bin/kafka-console-consumer.sh \
    --bootstrap-server kafka1:9092 \
    --topic "$TOPIC" \
    --partition "$PARTITION" \
    --offset "$OFFSET" \
    --max-messages "$ANZAHL" \
    --timeout-ms 10000 \
    --formatter-property print.key=true \
    --formatter-property print.offset=true \
    --formatter-property key.separator=" | "

# --partition N      genau diese Partition (schließt --group aus)
# --offset           Startposition: earliest, latest oder ein konkreter Offset
# --max-messages     danach beendet sich der Consumer von selbst
# In Java: consumer.assign(List.of(new TopicPartition(topic, N))); consumer.seek(...)
