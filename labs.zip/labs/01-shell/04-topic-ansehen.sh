#!/usr/bin/env bash
# 04 – Topic ansehen: Partitionen, Leader, Replicas, ISR
#
# Zeigt je Partition, welcher Broker Leader ist, wo die Kopien liegen (Replicas)
# und welche Kopien gerade synchron sind (Isr = In-Sync Replicas).

TOPIC=${1:-beitraege}

docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh \
    --bootstrap-server kafka1:9092 \
    --describe \
    --topic "$TOPIC"

echo
echo "Letzter Offset (= Anzahl geschriebener Nachrichten) je Partition:"
docker exec -it kafka1 /opt/kafka/bin/kafka-get-offsets.sh \
    --bootstrap-server kafka1:9092 \
    --topic "$TOPIC"

# Probieren: docker stop kafka3, dann dieses Skript erneut. Isr schrumpft, ein anderer
# Broker wird Leader. docker start kafka3 bringt die Kopie zurück.
# In Java gibt es dafür kein eigenes Beispiel – das ist Betrieb, nicht Anwendung.
