# Aufruf in PowerShell:  .\09-share-group.ps1   (optional mit -Topic name -Gruppe name)
# 09 – Share Group: Kafka als Warteschlange (KIP-932, seit Kafka 4.1)
#
# Gegenstück zur Consumer Group: Jede Nachricht geht an IRGENDEINEN Consumer der Gruppe,
# mehr Consumer als Partitionen sind erlaubt, dafür gibt es KEINE Reihenfolge je Key.
# Für die Bestandsverwaltung (Versionen eines Vertrags) wäre das falsch – deshalb im Buch
# nur als Gegenbeispiel (Kapitel 6 und 18).
#
# Zwei Fenster mit diesem Skript, dann mit 02-producer.ps1 Nachrichten mit demselben Key schreiben:
# Sie verteilen sich auf beide Fenster.

param([string]$Topic = "beitraege", [string]$Gruppe = "queue-demo")

# Einmalig: Die Share Group soll von Anfang an lesen (Standard: nur neue Nachrichten)
docker exec -it kafka1 /opt/kafka/bin/kafka-configs.sh  `
    --bootstrap-server kafka1:9092  `
    --alter --entity-type groups --entity-name $Gruppe  `
    --add-config share.auto.offset.reset=earliest

docker exec -it kafka1 /opt/kafka/bin/kafka-console-share-consumer.sh  `
    --bootstrap-server kafka1:9092  `
    --topic $Topic  `
    --group $Gruppe  `
    --formatter-property print.key=true  `
    --formatter-property print.partition=true

# Gruppe ansehen:
#   kafka-share-groups.sh --bootstrap-server kafka1:9092 --describe --group queue-demo
