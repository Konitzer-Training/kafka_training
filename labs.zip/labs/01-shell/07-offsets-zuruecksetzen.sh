#!/usr/bin/env bash
# 07 – Offsets einer Gruppe zurücksetzen (Daten erneut verarbeiten)
#
# Geht nur, wenn KEIN Consumer der Gruppe läuft (05 vorher beenden).
# Ohne Argument wird nur simuliert (--dry-run). Mit "ausfuehren" wird es gemacht.

TOPIC=${1:-beitraege}
GRUPPE=${2:-beitragsrechner}
MODUS=${3:-}

if [ "$MODUS" = "ausfuehren" ]; then AKTION=--execute; else AKTION=--dry-run; fi

docker exec -it kafka1 /opt/kafka/bin/kafka-consumer-groups.sh \
    --bootstrap-server kafka1:9092 \
    --group "$GRUPPE" \
    --topic "$TOPIC" \
    --reset-offsets --to-earliest \
    $AKTION

# Andere Ziele statt --to-earliest:
#   --to-latest                       alles Alte überspringen
#   --shift-by -2                     je Partition zwei Nachrichten zurück
#   --to-datetime 2026-11-02T14:00:00.000   auf einen Zeitpunkt
#
# Dasselbe in Java: 06-consumer-groups mit --app.von-anfang=true (seekToBeginning).
