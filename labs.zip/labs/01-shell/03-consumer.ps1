# Aufruf in PowerShell:  .\03-consumer.ps1   (optional mit -Topic name)
# 03 – Nachrichten lesen (Console Consumer)
#
# Liest alle Nachrichten von Anfang an und wartet dann auf neue.
# Beenden mit Strg+C.

param([string]$Topic = "beitraege")

docker exec -it kafka1 /opt/kafka/bin/kafka-console-consumer.sh  `
    --bootstrap-server kafka1:9092  `
    --topic $Topic  `
    --from-beginning  `
    --formatter-property print.key=true  `
    --formatter-property print.partition=true  `
    --formatter-property print.offset=true  `
    --formatter-property key.separator=" | "

# --from-beginning     Ab Offset 0 jeder Partition lesen. Ohne diese Option nur neue
#                      Nachrichten (ab "jetzt").
# print.key/partition/offset   Jede Zeile zeigt: Partition | Offset | Key | Wert.
#
# Dieser Consumer hat KEINE Consumer Group (genauer: eine zufällige Wegwerf-Gruppe).
# Er merkt sich nichts. Beim nächsten Start liest er wieder alles. Was passiert,
# wenn er sich etwas merken soll, zeigt 05-consumer-gruppe.sh.
#
# Dasselbe in Java: 03-consumer-plain (ohne Spring), 05-consumer-spring (mit Spring).
