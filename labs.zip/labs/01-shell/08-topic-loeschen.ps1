# Aufruf in PowerShell:  .\08-topic-loeschen.ps1   (optional mit -Topic name)
# 08 – Topic löschen (für einen frischen Durchlauf)
#
# Löscht das Topic samt aller Nachrichten und Offsets. Laufende Consumer legen es
# nicht neu an (auto.create ist im Lab aus) – erst 01 wieder ausführen.

param([string]$Topic = "beitraege")

docker exec -it kafka1 /opt/kafka/bin/kafka-topics.sh  `
    --bootstrap-server kafka1:9092  `
    --delete  `
    --topic $Topic
