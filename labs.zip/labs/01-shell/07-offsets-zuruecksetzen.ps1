# Aufruf in PowerShell:  .\07-offsets-zuruecksetzen.ps1   (optional mit -Topic name)
# 07 – Offsets einer Gruppe zurücksetzen (Daten erneut verarbeiten)
#
# Geht nur, wenn KEIN Consumer der Gruppe läuft (05 vorher beenden).
# Ohne Argument wird nur simuliert (--dry-run). Mit "ausfuehren" wird es gemacht.

param([string]$Topic = "beitraege", [string]$Gruppe = "beitragsrechner", [string]$Modus = "")

if ($Modus -eq "ausfuehren") { $Aktion = "--execute" } else { $Aktion = "--dry-run" }

docker exec -it kafka1 /opt/kafka/bin/kafka-consumer-groups.sh  `
    --bootstrap-server kafka1:9092  `
    --group $Gruppe  `
    --topic $Topic  `
    --reset-offsets --to-earliest  `
    $Aktion

# Andere Ziele statt --to-earliest:
#   --to-latest                       alles Alte überspringen
#   --shift-by -2                     je Partition zwei Nachrichten zurück
#   --to-datetime 2026-11-02T14:00:00.000   auf einen Zeitpunkt
#
# Dasselbe in Java: 06-consumer-groups mit --app.von-anfang=true (seekToBeginning).
