# Aufruf in PowerShell:  .\06-gruppe-ansehen.ps1   (optional mit -Topic name)
# 06 – Consumer Group ansehen: Offsets und Lag
#
# CURRENT-OFFSET  bis wohin die Gruppe gelesen (committet) hat
# LOG-END-OFFSET  bis wohin das Topic geschrieben ist
# LAG             die Differenz = noch nicht verarbeitete Nachrichten
# CONSUMER-ID     welcher Consumer die Partition gerade hat ("-" = keiner)

param([string]$Gruppe = "beitragsrechner")

docker exec -it kafka1 /opt/kafka/bin/kafka-consumer-groups.sh  `
    --bootstrap-server kafka1:9092  `
    --describe  `
    --group $Gruppe

# Probieren: Consumer (05) beenden, mit 02 drei Nachrichten schreiben, dieses Skript
# erneut: LAG steigt. Consumer wieder starten: Er holt genau diese Nachrichten nach.
