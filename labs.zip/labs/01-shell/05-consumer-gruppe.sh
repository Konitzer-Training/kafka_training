#!/usr/bin/env bash
# 05 – Consumer mit Consumer Group
#
# Der Unterschied zu 03: --group. Kafka merkt sich für die Gruppe "beitragsrechner",
# bis wohin sie gelesen hat (Offset je Partition). Nach einem Neustart geht es dort
# weiter – deshalb hier KEIN --from-beginning.
#
# Zwei Fenster mit diesem Skript: Beide bekommen je einen Teil der drei Partitionen.
# Ein Fenster schließen: Das andere übernimmt alle drei (Rebalance).

TOPIC=${1:-beitraege}
GRUPPE=${2:-beitragsrechner}

docker exec -it kafka1 /opt/kafka/bin/kafka-console-consumer.sh \
    --bootstrap-server kafka1:9092 \
    --topic "$TOPIC" \
    --group "$GRUPPE" \
    --command-property group.protocol=consumer \
    --formatter-property print.key=true \
    --formatter-property print.partition=true \
    --formatter-property print.offset=true \
    --formatter-property key.separator=" | "

# group.protocol=consumer   Das neue Gruppenprotokoll (KIP-848): Rebalance ohne
#                           "Stop the world". Seit Kafka 4.0 verfügbar.
#
# Dasselbe in Java: 06-consumer-groups.
