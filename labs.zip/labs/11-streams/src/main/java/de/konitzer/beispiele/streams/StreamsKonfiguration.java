package de.konitzer.beispiele.streams;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

/** Spring baut die Topologien beim Start auf den StreamsBuilder; jede Bean gibt ihr Ergebnis auf der Konsole aus. */
@Configuration
class StreamsKonfiguration {

    private static final DateTimeFormatter ZEIT = DateTimeFormatter.ofPattern("HH:mm:ss");

    @Bean
    KStream<String, String> policen(StreamsBuilder builder, @Value("${app.fenster-minuten}") long fensterMinuten) {
        return Topologien.antragUndPruefung(builder, Duration.ofMinutes(fensterMinuten))
                .peek((vertrag, police) -> drucke("POLICE      ", vertrag, police));
    }

    @Bean
    KStream<String, String> angereichert(StreamsBuilder builder) {
        return Topologien.anreichern(builder)
                .peek((kunde, text) -> drucke("ANGEREICHERT", kunde, text));
    }

    @Bean
    KTable<String, Long> schaedenJeVertrag(StreamsBuilder builder) {
        KTable<String, Long> anzahl = Topologien.schaedenJeVertrag(builder);
        anzahl.toStream().peek((vertrag, n) -> drucke("SCHAEDEN    ", vertrag, n + " gemeldet"));
        return anzahl;
    }

    @Bean
    KStream<String, String> auffaelligkeiten(StreamsBuilder builder) {
        return Topologien.auffaelligkeiten(builder)
                .peek((vertrag, text) -> drucke("AUFFAELLIG  ", vertrag, text));
    }

    /**
     * Alle Topics mit gleicher Partitionsanzahl – Voraussetzung für die Joins. Mehrere Topics in einer Bean:
     * KafkaAdmin.NewTopics (ein einfaches NewTopic[] würde Spring nicht einsammeln).
     */
    @Bean
    KafkaAdmin.NewTopics topics(@Value("${app.partitionen}") int partitionen, @Value("${app.replikation}") int rf) {
        String[] namen = {Topologien.ANTRAEGE, Topologien.PRUEFUNGEN, Topologien.POLICEN, Topologien.KUNDEN,
                Topologien.AENDERUNGEN, Topologien.ANGEREICHERT, Topologien.SCHAEDEN, Topologien.SCHAEDEN_JE_VERTRAG,
                Topologien.AUFFAELLIG};
        NewTopic[] topics = new NewTopic[namen.length];
        for (int i = 0; i < namen.length; i++) {
            var t = TopicBuilder.name(namen[i]).partitions(partitionen).replicas(rf);
            if (namen[i].equals(Topologien.KUNDEN)) {
                t.compact();   // Stammdaten: je Key nur der letzte Stand
            }
            topics[i] = t.build();
        }
        return new KafkaAdmin.NewTopics(topics);
    }

    private static void drucke(String art, String key, Object wert) {
        System.out.printf("%s  %s key=%-8s %s%n", LocalTime.now().format(ZEIT), art, key, wert);
    }
}
