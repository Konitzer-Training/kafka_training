package de.konitzer.beispiele.streams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafkaStreams;

/**
 * Kapitel 11: Kafka Streams mit Spring Boot. Vier Topologien in einer Anwendung:
 *  - Antrag + Prüfung -> Police            (Stream-Stream-Join im Zeitfenster)
 *  - Vertragsänderung + Kunde -> angereichert (Stream-Table-Join)
 *  - Schadenmeldungen je Vertrag zählen    (KTable)
 *  - 3 Schäden in 24 h -> auffällig         (Zeitfenster)
 *
 * Start: java -jar 11-streams.jar   (app.beispieldaten=true sendet nach dem Start Beispielereignisse)
 */
@SpringBootApplication
@EnableKafkaStreams
public class StreamsApp {

    public static void main(String[] args) {
        SpringApplication.run(StreamsApp.class, args);
    }
}
