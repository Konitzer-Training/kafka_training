package de.konitzer.beispiele.streams;

import java.time.Duration;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.JoinWindows;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.StreamJoined;
import org.apache.kafka.streams.kstream.TimeWindows;

/**
 * Die Topologien als statische Methoden auf dem StreamsBuilder – ohne Spring.
 * So lassen sie sich mit dem TopologyTestDriver prüfen (Kapitel 13, Modul 13-tests).
 * Alle Werte sind hier Text; in Produktion wären es JSON-Serdes für die Records aus "ereignisse".
 */
public final class Topologien {

    public static final String ANTRAEGE = "antraege";
    public static final String PRUEFUNGEN = "pruefungen";
    public static final String POLICEN = "policen";
    public static final String KUNDEN = "kunden.stammdaten";
    public static final String AENDERUNGEN = "bestand.vertragsaenderungen";
    public static final String ANGEREICHERT = "bestand.vertragsaenderungen.angereichert";
    public static final String SCHAEDEN = "schaden.meldungen";
    public static final String SCHAEDEN_JE_VERTRAG = "schaden.anzahl-je-vertrag";
    public static final String AUFFAELLIG = "schaden.auffaelligkeiten";

    private Topologien() {
    }

    /**
     * Antrag und Risikoprüfung zum selben Vertrag (gleicher Key) werden zur Police,
     * wenn sie höchstens "fenster" auseinanderliegen. Die Reihenfolge der beiden ist egal.
     * Voraussetzung: beide Topics mit gleicher Partitionsanzahl (Co-Partitioning).
     */
    public static KStream<String, String> antragUndPruefung(StreamsBuilder builder, Duration fenster) {
        KStream<String, String> antraege = builder.stream(ANTRAEGE);
        KStream<String, String> pruefungen = builder.stream(PRUEFUNGEN);

        KStream<String, String> policen = antraege.join(
                pruefungen,
                (antrag, pruefung) -> "Police aus Antrag \"" + antrag + "\" und Prüfung \"" + pruefung + "\"",
                JoinWindows.ofTimeDifferenceWithNoGrace(fenster),
                // benannter Zustand: interne Topics heißen <application.id>-antrag-pruefung-…-changelog
                StreamJoined.with(Serdes.String(), Serdes.String(), Serdes.String())
                        .withStoreName("antrag-pruefung"));

        policen.to(POLICEN);
        return policen;
    }

    /**
     * Stream-Table-Join: Jede Vertragsänderung wird um die Stammdaten des Kunden ergänzt.
     * Die KTable hält je Kundennummer den letzten Stand. Weil die Änderung mit der Vertragsnummer
     * kommt, wechselt selectKey auf die Kundennummer – Kafka Streams partitioniert dafür intern um.
     * Wert der Änderung: "<kundennummer>|<text>", Wert des Kunden: Name.
     */
    public static KStream<String, String> anreichern(StreamsBuilder builder) {
        KTable<String, String> kunden = builder.table(KUNDEN, Materialized.as("kunden"));
        KStream<String, String> aenderungen = builder.stream(AENDERUNGEN);

        KStream<String, String> angereichert = aenderungen
                .selectKey((vertrag, aenderung) -> kundennummerAus(aenderung))
                .join(kunden, (aenderung, kunde) -> textAus(aenderung) + " | Kunde: " + kunde);

        angereichert.to(ANGEREICHERT);
        return angereichert;
    }

    /** Zählen je Key: Wie viele Schäden hat jeder Vertrag gemeldet? Key der Meldungen: Vertragsnummer. */
    public static KTable<String, Long> schaedenJeVertrag(StreamsBuilder builder) {
        KTable<String, Long> anzahl = builder.<String, String>stream(SCHAEDEN)
                .groupByKey()
                .count(Materialized.as("schaeden-je-vertrag"));

        anzahl.toStream().to(SCHAEDEN_JE_VERTRAG, Produced.with(Serdes.String(), Serdes.Long()));
        return anzahl;
    }

    /** Zeitfenster: ab drei Schäden desselben Vertrags innerhalb von 24 Stunden eine Auffälligkeit melden. */
    public static KStream<String, String> auffaelligkeiten(StreamsBuilder builder) {
        KStream<String, String> auffaellig = builder.<String, String>stream(SCHAEDEN)
                .groupByKey()
                .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofHours(24)))
                .count(Materialized.as("schaeden-24h"))
                .toStream()
                .filter((fenster, anzahl) -> anzahl >= 3)
                .map((fenster, anzahl) -> KeyValue.pair(fenster.key(), "auffällig: " + anzahl + " Schäden in 24 h"));

        auffaellig.to(AUFFAELLIG);
        return auffaellig;
    }

    static String kundennummerAus(String aenderung) {
        int trenner = aenderung.indexOf('|');
        return trenner > 0 ? aenderung.substring(0, trenner) : aenderung;
    }

    static String textAus(String aenderung) {
        int trenner = aenderung.indexOf('|');
        return trenner > 0 ? aenderung.substring(trenner + 1) : aenderung;
    }
}
