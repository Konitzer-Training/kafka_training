package de.konitzer.beispiele.streams;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

/** Sendet nach dem Start Beispielereignisse, damit auf der Konsole etwas zu sehen ist. */
@Configuration
@ConditionalOnProperty(name = "app.beispieldaten", havingValue = "true", matchIfMissing = true)
class Beispieldaten {

    @Bean
    CommandLineRunner beispieldatenSenden(KafkaTemplate<String, String> kafka) {
        return args -> {
            Thread.sleep(5000);   // warten, bis die Streams-Anwendung läuft
            System.out.println();
            System.out.println("Beispieldaten werden gesendet. Beenden mit Strg+C.");
            System.out.println();
            // Join: Antrag und Prüfung
            kafka.send(Topologien.ANTRAEGE, "V-2001", "Antrag KFZ");
            kafka.send(Topologien.PRUEFUNGEN, "V-2001", "geprüft: ok");
            kafka.send(Topologien.PRUEFUNGEN, "V-2002", "geprüft: ok");   // ohne Antrag -> keine Police
            // Anreichern: Kunde zuerst (KTable), dann die Änderung
            kafka.send(Topologien.KUNDEN, "K-100", "Erika Mustermann");
            kafka.send(Topologien.AENDERUNGEN, "V-1001", "K-100|Adresse geändert");
            // Zählen und Zeitfenster
            kafka.send(Topologien.SCHAEDEN, "V-1001", "Glasbruch");
            kafka.send(Topologien.SCHAEDEN, "V-1001", "Hagel");
            kafka.send(Topologien.SCHAEDEN, "V-1001", "Wildunfall");
            kafka.send(Topologien.SCHAEDEN, "V-1003", "Diebstahl");
            kafka.flush();
        };
    }
}
