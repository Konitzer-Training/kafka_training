package de.konitzer.beispiele.streams;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.time.Instant;
import java.util.Properties;

import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.TopologyTestDriver;
import org.junit.jupiter.api.Test;

/**
 * Kafka Streams ohne Broker: Der TopologyTestDriver verarbeitet synchron und mit kontrollierter Zeit –
 * Zeitstempel werden beim pipeInput mitgegeben, Zeitfenster lassen sich damit exakt prüfen.
 */
class TopologienTest {

    private static final Instant T0 = Instant.parse("2026-11-03T09:00:00Z");

    @Test
    void antragUndPruefungErgebenPolice() {
        var builder = new StreamsBuilder();
        Topologien.antragUndPruefung(builder, Duration.ofMinutes(5));

        try (var treiber = new TopologyTestDriver(builder.build(), konfiguration())) {
            var antraege = treiber.createInputTopic(Topologien.ANTRAEGE, new StringSerializer(), new StringSerializer());
            var pruefungen = treiber.createInputTopic(Topologien.PRUEFUNGEN, new StringSerializer(), new StringSerializer());
            var policen = treiber.createOutputTopic(Topologien.POLICEN, new StringDeserializer(), new StringDeserializer());

            antraege.pipeInput("V-2001", "Antrag KFZ", T0);
            pruefungen.pipeInput("V-2001", "geprüft", T0.plus(Duration.ofMinutes(3)));
            pruefungen.pipeInput("V-2002", "geprüft", T0.plus(Duration.ofMinutes(4)));   // kein Antrag

            assertThat(policen.readKeyValuesToList()).containsExactly(
                    KeyValue.pair("V-2001", "Police aus Antrag \"Antrag KFZ\" und Prüfung \"geprüft\""));
        }
    }

    @Test
    void pruefungNachSechsMinutenErgibtKeinePolice() {
        var builder = new StreamsBuilder();
        Topologien.antragUndPruefung(builder, Duration.ofMinutes(5));

        try (var treiber = new TopologyTestDriver(builder.build(), konfiguration())) {
            var antraege = treiber.createInputTopic(Topologien.ANTRAEGE, new StringSerializer(), new StringSerializer());
            var pruefungen = treiber.createInputTopic(Topologien.PRUEFUNGEN, new StringSerializer(), new StringSerializer());
            var policen = treiber.createOutputTopic(Topologien.POLICEN, new StringDeserializer(), new StringDeserializer());

            antraege.pipeInput("V-2001", "Antrag KFZ", T0);
            pruefungen.pipeInput("V-2001", "geprüft", T0.plus(Duration.ofMinutes(6)));

            assertThat(policen.isEmpty()).isTrue();
        }
    }

    @Test
    void aenderungWirdUmKundenAngereichert() {
        var builder = new StreamsBuilder();
        Topologien.anreichern(builder);

        try (var treiber = new TopologyTestDriver(builder.build(), konfiguration())) {
            var kunden = treiber.createInputTopic(Topologien.KUNDEN, new StringSerializer(), new StringSerializer());
            var aenderungen = treiber.createInputTopic(Topologien.AENDERUNGEN, new StringSerializer(), new StringSerializer());
            var angereichert = treiber.createOutputTopic(Topologien.ANGEREICHERT, new StringDeserializer(), new StringDeserializer());

            kunden.pipeInput("K-100", "Erika Mustermann", T0);
            aenderungen.pipeInput("V-1001", "K-100|Adresse geändert", T0.plusSeconds(1));
            aenderungen.pipeInput("V-1002", "K-999|Beitrag angepasst", T0.plusSeconds(2));   // Kunde unbekannt

            assertThat(angereichert.readKeyValuesToList()).containsExactly(
                    KeyValue.pair("K-100", "Adresse geändert | Kunde: Erika Mustermann"));
        }
    }

    @Test
    void dreiSchaedenInZwoelfStundenSindAuffaellig() {
        var builder = new StreamsBuilder();
        Topologien.schaedenJeVertrag(builder);
        Topologien.auffaelligkeiten(builder);

        try (var treiber = new TopologyTestDriver(builder.build(), konfiguration())) {
            var schaeden = treiber.createInputTopic(Topologien.SCHAEDEN, new StringSerializer(), new StringSerializer());
            var anzahl = treiber.createOutputTopic(Topologien.SCHAEDEN_JE_VERTRAG, new StringDeserializer(), new LongDeserializer());
            var auffaellig = treiber.createOutputTopic(Topologien.AUFFAELLIG, new StringDeserializer(), new StringDeserializer());

            schaeden.pipeInput("V-1001", "Glasbruch", T0);
            schaeden.pipeInput("V-1001", "Hagel", T0.plus(Duration.ofHours(6)));
            schaeden.pipeInput("V-1003", "Diebstahl", T0.plus(Duration.ofHours(7)));
            schaeden.pipeInput("V-1001", "Wildunfall", T0.plus(Duration.ofHours(12)));

            assertThat(anzahl.readKeyValuesToMap()).containsEntry("V-1001", 3L).containsEntry("V-1003", 1L);
            assertThat(auffaellig.readKeyValuesToList())
                    .containsExactly(KeyValue.pair("V-1001", "auffällig: 3 Schäden in 24 h"));
        }
    }

    private static Properties konfiguration() {
        var config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
        config.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        config.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        config.put(StreamsConfig.STATESTORE_CACHE_MAX_BYTES_CONFIG, 0);   // Ergebnisse sofort, nicht gepuffert
        return config;
    }
}
