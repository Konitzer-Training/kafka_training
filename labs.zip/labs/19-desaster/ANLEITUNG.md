# 19-desaster – Arbeitsanweisung

**Was es zeigt:** Die Desaster-Vorführung aus Tag 2 (Abschnitt 10): ein zweiter Standort, MirrorMaker 2 spiegelt Topics und übersetzt Consumer-Offsets, ein Failover der Gruppe `bestand`. Nur Skripte, keine Java-Anwendung: Desaster Recovery ist Betrieb.

**Buch:** Kapitel 19 (Desaster Recovery), Kapitel 17 (Betrieb).

## Vorführung (15 Minuten)

Vorher: Lag-Szenario aus `14-monitoring/shell/07-lag-erzeugen.sh` läuft (Quelle und `bestandsverwaltung 1`), damit es etwas zu spiegeln gibt.

1. `shell/01-dr-starten.sh`: Container `kafka-dr` und `mirror-maker` kommen dazu (etwa 30 s).
2. `shell/02-dr-topics.sh`: `primary.bestand.aenderungen`, `primary.beitraege`, … Kafbat UI: Cluster „dr“.
3. `shell/03-dr-offsets.sh`: Gruppe `bestand` existiert auch am DR-Standort, mit übersetzten Offsets.
4. Alle `bestandsverwaltung`-Fenster am Primärstandort mit Strg+C beenden.
5. `shell/04-failover.sh`: Die Gruppe liest am DR-Standort weiter, ohne Duplikate und ohne Lücke (bis auf die Latenz der Spiegelung).
6. Grafana: MirrorMaker-Metriken; Alert `MirrorMakerLagging` bei mehr als 30 s Verzögerung.
7. `shell/05-dr-stoppen.sh`.

Windows: Die Skripte sind einzelne `docker exec`-Zeilen; `01` und `05` sind `docker compose --profile dr up -d` bzw. `stop` im Ordner `kafka-lab`.

## Aufgaben

1. Stoppen Sie `mirror-maker` für zwei Minuten, lassen Sie die Quelle weiterlaufen, starten Sie ihn wieder. Wie lange dauert es, bis `primary.bestand.aenderungen` aufgeholt hat? Welche Metrik zeigt es?
2. Starten Sie eine Spring-App gegen den DR-Cluster: `java -jar 06-consumer-groups\target\06-consumer-groups-app.jar --spring.kafka.bootstrap-servers=localhost:29092 --app.topic=primary.beitraege --app.gruppe=beitragsrechner`. Welchen Offset hat sie beim Start?
3. Was fehlt in diesem Lab gegenüber einem echten DR-Konzept? (Stichworte: Schema Registry, Kafka Connect, DNS-Umschaltung, Rückweg.)
