#!/usr/bin/env bash
# 03 – Übersetzte Offsets einer Gruppe am DR-Standort (MM2 schreibt sie aus den Checkpoints)
GRUPPE=${1:-bestand}
docker exec -it kafka-dr /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server kafka-dr:9092 \
    --describe --group "$GRUPPE"
