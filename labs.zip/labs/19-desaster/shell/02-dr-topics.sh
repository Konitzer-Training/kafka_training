#!/usr/bin/env bash
# 02 – Gespiegelte Topics am DR-Standort: heißen primary.<topic>; dazu interne MM2-Topics (heartbeats, checkpoints)
docker exec -it kafka-dr /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka-dr:9092 --list
