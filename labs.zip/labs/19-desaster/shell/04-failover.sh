#!/usr/bin/env bash
# 04 – Failover: Alle Consumer der Gruppe am Primärstandort beenden, dann dieselbe Gruppe am DR-Cluster starten.
# Sie liest dort weiter, wo sie am Primärstandort aufgehört hat (übersetzter Offset).
TOPIC=${1:-bestand.aenderungen}
GRUPPE=${2:-bestand}
docker exec -it kafka-dr /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server kafka-dr:9092 \
    --topic "primary.$TOPIC" --group "$GRUPPE" \
    --command-property group.protocol=consumer \
    --formatter-property print.key=true --formatter-property print.partition=true
# Danach 03-dr-offsets.sh: Gruppe aktiv, Lag am DR-Standort.
# Spring-App auf DR umschalten: --spring.kafka.bootstrap-servers=localhost:29092 --app.topic=primary.<topic>
