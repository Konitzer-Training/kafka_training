#!/usr/bin/env bash
# 05 – Nur den DR-Standort wieder stoppen (Primärcluster läuft weiter)
cd "$(dirname "$0")/../../kafka-lab" && docker compose --profile dr stop kafka-dr mirror-maker
