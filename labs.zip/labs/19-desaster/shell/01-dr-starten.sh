#!/usr/bin/env bash
# 01 – Zweiten Standort (kafka-dr) und MirrorMaker 2 starten (Compose-Profil "dr")
# MirrorMaker 2 spiegelt alle Topics des Primärclusters nach kafka-dr als primary.<topic>
# und übersetzt die Consumer-Offsets (Kapitel 19).
cd "$(dirname "$0")/../../kafka-lab" && docker compose --profile dr up -d
