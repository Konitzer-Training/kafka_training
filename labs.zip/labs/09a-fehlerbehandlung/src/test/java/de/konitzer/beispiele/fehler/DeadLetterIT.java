package de.konitzer.beispiele.fehler;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;

import de.konitzer.beispiele.ereignisse.Dokumentauftrag;
import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** app.recoverer=dlt: Die Poison Pill wandert ins DLT, die Verarbeitung läuft weiter – und überholt. */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "app.demo=false", "app.replikation=1", "app.recoverer=dlt",
        "app.backoff.versuche=2", "app.backoff.start-ms=100", "app.retry.delay-ms=100"
})
@EmbeddedKafka(partitions = 3)
class DeadLetterIT {

    @Autowired KafkaTemplate<String, Object> kafka;
    @Autowired Bestand bestand;
    @Autowired EmbeddedKafkaBroker broker;
    @Value("${app.topic}") String topic;
    @Value("${app.topic-dokumente}") String dokumente;

    @Test
    void poisonPillLandetImDltUndSpaetereAenderungUeberholt() {
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 1, "ADRESSE", Map.of("plz", "50667"), Instant.now()));
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 2, "TARIF", Map.of("tarif", "UNBEKANNT"), Instant.now()));
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 3, "KUENDIGUNG", Map.of(), Instant.now()));

        // v3 wird verbucht, obwohl v2 fehlt: Reihenfolge verletzt
        await().atMost(Duration.ofSeconds(20)).untilAsserted(() ->
                assertThat(bestand.letzteVersion("V-1001")).isEqualTo(3));

        var dlt = Testbasis.leseAlle(broker.getBrokersAsString(), topic + "-dlt");
        assertThat(dlt).hasSize(1);
        assertThat(dlt.get(0).key()).isEqualTo("V-1001");
        assertThat(dlt.get(0).value()).contains("\"version\":2");
        // Spring verpackt die Ausnahme des Listeners; die eigentliche Ursache steht im Header …-cause-fqcn
        assertThat(new String(dlt.get(0).headers().lastHeader("kafka_dlt-exception-fqcn").value()))
                .isEqualTo("org.springframework.kafka.listener.ListenerExecutionFailedException");
        assertThat(new String(dlt.get(0).headers().lastHeader("kafka_dlt-exception-cause-fqcn").value()))
                .isEqualTo(UnbekannterTarifException.class.getName());
        assertThat(new String(dlt.get(0).headers().lastHeader("kafka_dlt-original-topic").value()))
                .isEqualTo(topic);
    }

    @Test
    void stoerungWirdWiederholtUndKlapptBeimDrittenVersuch() {
        kafka.send(topic, "V-1002", new Vertragsaenderung("V-1002", 1, "BEITRAG", Map.of("simuliere", "STOERUNG"), Instant.now()));

        await().atMost(Duration.ofSeconds(20)).untilAsserted(() ->
                assertThat(bestand.letzteVersion("V-1002")).isEqualTo(1));
        assertThat(bestand.naechsterVersuch("V-1002", 1)).isEqualTo(4);   // 3 Versuche + dieser Aufruf
    }

    @Test
    void kaputterDokumentauftragEndetImDltHandler() {
        kafka.send(dokumente, "V-1003", new Dokumentauftrag("V-1003", "POLICE"));
        kafka.send(dokumente, "V-1004", new Dokumentauftrag("V-1004", "KAPUTT"));

        await().atMost(Duration.ofSeconds(30)).untilAsserted(() ->
                assertThat(bestand.letzteVersion("DLT-V-1004")).isEqualTo(1));
        // 4 Versuche (Haupt-Topic + retry-0, -1, -2), dann DLT
        assertThat(bestand.naechsterVersuch("DOK-V-1004", 0)).isEqualTo(5);
        assertThat(bestand.naechsterVersuch("DOK-V-1003", 0)).isEqualTo(2);
        assertThat(bestand.letzteVersion("DLT-V-1003")).isZero();
    }
}
