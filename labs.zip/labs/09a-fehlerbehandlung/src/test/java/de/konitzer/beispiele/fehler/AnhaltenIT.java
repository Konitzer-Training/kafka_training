package de.konitzer.beispiele.fehler;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.context.EmbeddedKafka;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/** Poison Pill bei app.recoverer=anhalten: Die Verarbeitung steht, spätere Änderungen bleiben liegen. */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "app.demo=false", "app.replikation=1", "app.recoverer=anhalten",
        "app.backoff.versuche=2", "app.backoff.start-ms=100", "app.retry.delay-ms=100"
})
@EmbeddedKafka(partitions = 3)
class AnhaltenIT {

    @Autowired KafkaTemplate<String, Object> kafka;
    @Autowired Bestand bestand;
    @Autowired KafkaListenerEndpointRegistry registry;
    @Value("${app.topic}") String topic;

    @Test
    void poisonPillHaeltDieVerarbeitungAn() {
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 1, "ADRESSE", Map.of("plz", "50667"), Instant.now()));
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 2, "TARIF", Map.of("tarif", "UNBEKANNT"), Instant.now()));
        kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 3, "KUENDIGUNG", Map.of(), Instant.now()));

        await().atMost(Duration.ofSeconds(20)).untilAsserted(() ->
                assertThat(registry.getListenerContainer(Verbuchung.LISTENER_ID).isRunning()).isFalse());

        // v1 verbucht, v2 scheitert, v3 NICHT verbucht: Reihenfolge gewahrt
        assertThat(bestand.letzteVersion("V-1001")).isEqualTo(1);
        // dauerhafter Fehler: kein Wiederholen, genau ein Versuch
        assertThat(bestand.naechsterVersuch("V-1001", 2)).isEqualTo(2);
    }
}
