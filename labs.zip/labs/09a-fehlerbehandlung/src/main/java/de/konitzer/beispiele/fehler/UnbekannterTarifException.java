package de.konitzer.beispiele.fehler;

/** Dauerhafter Fehler: Wiederholen hilft nicht. Der Error Handler gibt die Nachricht sofort an den Recoverer. */
public class UnbekannterTarifException extends RuntimeException {

    public UnbekannterTarifException(String tarif) {
        super("Tarif unbekannt: " + tarif);
    }
}
