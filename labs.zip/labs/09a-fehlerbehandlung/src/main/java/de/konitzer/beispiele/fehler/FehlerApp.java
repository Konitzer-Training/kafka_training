package de.konitzer.beispiele.fehler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kapitel 9: Was passiert mit einer Nachricht, die nicht verarbeitet werden kann?
 *
 * Start: java -jar 09a-fehlerbehandlung.jar                       (wiederholen, dann anhalten)
 *        java -jar 09a-fehlerbehandlung.jar --app.recoverer=dlt   (wiederholen, dann Dead-Letter-Topic)
 */
@SpringBootApplication
public class FehlerApp {

    public static void main(String[] args) {
        SpringApplication.run(FehlerApp.class, args);
    }
}
