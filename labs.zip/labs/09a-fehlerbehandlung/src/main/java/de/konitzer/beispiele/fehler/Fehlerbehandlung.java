package de.konitzer.beispiele.fehler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.ExponentialBackOff;

/**
 * Der DefaultErrorHandler: zurücksetzen (seek), mit Backoff wiederholen – blockierend, die Partition
 * wartet –, und wenn die Versuche aufgebraucht sind, den Recoverer rufen.
 *
 * app.recoverer=anhalten: Container stoppen, Offset NICHT committen – Reihenfolge bleibt, Mensch entscheidet.
 * app.recoverer=dlt:      Datensatz nach <topic>-dlt, weiter mit dem nächsten – spätere Änderungen überholen.
 */
@Configuration
class Fehlerbehandlung {

    private static final Logger log = LoggerFactory.getLogger(Fehlerbehandlung.class);

    @Bean
    CommonErrorHandler errorHandler(ConsumerRecordRecoverer recoverer,
                                       @Value("${app.backoff.versuche}") int versuche,
                                       @Value("${app.backoff.start-ms}") long startMs) {
        // Spring Framework 7: ExponentialBackOff mit maxAttempts (ersetzt ExponentialBackOffWithMaxRetries)
        var backoff = new ExponentialBackOff(startMs, 2.0);   // 1 s, 2 s, 4 s, 8 s
        backoff.setMaxAttempts(versuche);                      // z. B. 4 Wiederholungen

        var handler = new DefaultErrorHandler(recoverer, backoff);
        // dauerhafte Fehler: sofort zum Recoverer
        handler.addNotRetryableExceptions(UnbekannterTarifException.class);
        handler.setRetryListeners((datensatz, fehler, versuch) ->
                log.warn("Versuch {} fehlgeschlagen: {} @{}: {}", versuch, datensatz.key(), datensatz.offset(),
                        fehler.getCause() != null ? fehler.getCause().getMessage() : fehler.getMessage()));
        return handler;
    }

    /** Dead-Letter-Topic: schreibt nach <topic>-dlt, gleiche Partition, Ausnahme und Original-Offset in Headern. */
    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "app.recoverer", havingValue = "dlt")
    ConsumerRecordRecoverer deadLetter(KafkaTemplate<Object, Object> template) {
        log.info("Fehlerbehandlung: wiederholen, dann Dead-Letter-Topic");
        return new DeadLetterPublishingRecoverer(template);
    }

    /** Anhalten: stehen bleiben, Mensch entscheidet. Nach der Korrektur startet der Container genau dort neu. */
    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "app.recoverer", havingValue = "anhalten", matchIfMissing = true)
    ConsumerRecordRecoverer anhalten(KafkaListenerEndpointRegistry registry) {
        log.info("Fehlerbehandlung: wiederholen, dann anhalten");
        return (datensatz, fehler) -> {
            log.error("ANHALTEN: Vertrag {} (P{}, Offset {}) scheitert dauerhaft: {}", datensatz.key(),
                    datensatz.partition(), datensatz.offset(), fehler.getMessage());
            var container = registry.getListenerContainer(Verbuchung.LISTENER_ID);
            // nicht aus dem Consumer-Thread stoppen
            new Thread(() -> container.stop(), "anhalten").start();
            // Ausnahme: Der Datensatz gilt als nicht verarbeitet, sein Offset wird nicht committet
            throw new IllegalStateException("Bestandsverwaltung angehalten bei " + datensatz.key());
        };
    }
}
