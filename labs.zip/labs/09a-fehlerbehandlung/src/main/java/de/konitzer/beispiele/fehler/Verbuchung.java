package de.konitzer.beispiele.fehler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Die Bestandsverwaltung. Zwei Arten von Fehlern werden simuliert:
 *  - art=TARIF mit tarif=UNBEKANNT  -> dauerhaft: UnbekannterTarifException (nicht wiederholen)
 *  - daten.simuliere=STOERUNG       -> vorübergehend: scheitert zweimal, klappt beim dritten Versuch
 *
 * Commit: ack-mode=record – Spring committet nach jedem erfolgreich verarbeiteten Datensatz.
 * Wirft der Listener, wird nicht committet; der Error Handler entscheidet, wie es weitergeht.
 */
@Component
public class Verbuchung {

    static final String LISTENER_ID = "bestand";

    private static final Logger log = LoggerFactory.getLogger(Verbuchung.class);

    private final Bestand bestand;

    Verbuchung(Bestand bestand) {
        this.bestand = bestand;
    }

    @KafkaListener(id = LISTENER_ID, idIsGroup = false, topics = "${app.topic}")
    void verarbeite(Vertragsaenderung aenderung) {
        int versuch = bestand.naechsterVersuch(aenderung.vertragsnummer(), aenderung.version());

        if ("TARIF".equals(aenderung.art()) && "UNBEKANNT".equals(aenderung.daten().get("tarif"))) {
            throw new UnbekannterTarifException(aenderung.daten().get("tarif"));
        }
        if ("STOERUNG".equals(aenderung.daten().get("simuliere")) && versuch < 3) {
            throw new VoruebergehendNichtVerfuegbarException("Tarifrechner");
        }

        bestand.speichere(aenderung.vertragsnummer(), aenderung.version());
        log.info("{} v{} {} verbucht (Versuch {})", aenderung.vertragsnummer(), aenderung.version(),
                aenderung.art(), versuch);
    }
}
