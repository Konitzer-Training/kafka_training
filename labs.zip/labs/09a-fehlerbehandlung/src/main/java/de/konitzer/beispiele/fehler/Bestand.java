package de.konitzer.beispiele.fehler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

/** Zuletzt verbuchte Version je Vertrag (im Speicher) – plus Zähler der Störungs-Versuche. */
@Component
public class Bestand {

    private final Map<String, Integer> versionen = new ConcurrentHashMap<>();
    private final Map<String, AtomicInteger> versuche = new ConcurrentHashMap<>();

    public int letzteVersion(String vertragsnummer) {
        return versionen.getOrDefault(vertragsnummer, 0);
    }

    public void speichere(String vertragsnummer, int version) {
        versionen.put(vertragsnummer, version);
    }

    /** Wievielter Versuch für diese Änderung? (Vertrag + Version) */
    public int naechsterVersuch(String vertragsnummer, int version) {
        return versuche.computeIfAbsent(vertragsnummer + "#" + version, k -> new AtomicInteger()).incrementAndGet();
    }
}
