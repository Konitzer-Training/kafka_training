package de.konitzer.beispiele.fehler;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

/** Topics als Code. Das DLT braucht mindestens so viele Partitionen wie das Quell-Topic. */
@Configuration
class KafkaTopics {

    @Bean
    NewTopic vertragsaenderungen(@Value("${app.topic}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic).partitions(3).replicas(rf).build();
    }

    @Bean
    NewTopic deadLetterTopic(@Value("${app.topic}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic + "-dlt").partitions(3).replicas(rf).build();
    }

    @Bean
    NewTopic dokumente(@Value("${app.topic-dokumente}") String topic, @Value("${app.replikation}") int rf) {
        return TopicBuilder.name(topic).partitions(3).replicas(rf).build();
    }
}
