package de.konitzer.beispiele.fehler;

import java.time.Instant;
import java.util.Map;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import de.konitzer.beispiele.ereignisse.Dokumentauftrag;
import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Konsolen-Demo. Sendet nach dem Start:
 *  V-1001 v1 ADRESSE           -> verbucht
 *  V-1001 v2 TARIF UNBEKANNT   -> Poison Pill: anhalten oder DLT (app.recoverer)
 *  V-1001 v3 KUENDIGUNG        -> anhalten: bleibt liegen | dlt: wird verbucht, obwohl v2 fehlt
 *  V-1002 v1 BEITRAG STOERUNG  -> klappt beim dritten Versuch
 *  Dokumentauftrag OK und KAPUTT -> KAPUTT läuft durch die Retry-Topics bis zum DLT
 */
@Configuration
@ConditionalOnProperty(name = "app.demo", havingValue = "true", matchIfMissing = true)
class Demo {

    @Bean
    CommandLineRunner demoLauf(KafkaTemplate<String, Object> kafka, Bestand bestand,
                           @org.springframework.beans.factory.annotation.Value("${app.topic}") String topic,
                           @org.springframework.beans.factory.annotation.Value("${app.topic-dokumente}") String dokumente) {
        return args -> {
            Thread.sleep(3000);   // kurz warten, bis der Listener seine Partitionen hat
            System.out.println();
            System.out.println("Demo: Poison Pill, Störung und ein kaputter Dokumentauftrag. Beenden mit Strg+C.");
            System.out.println();
            kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 1, "ADRESSE", Map.of("plz", "50667"), Instant.now()));
            kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 2, "TARIF", Map.of("tarif", "UNBEKANNT"), Instant.now()));
            kafka.send(topic, "V-1001", new Vertragsaenderung("V-1001", 3, "KUENDIGUNG", Map.of("zum", "2027-01-01"), Instant.now()));
            kafka.send(topic, "V-1002", new Vertragsaenderung("V-1002", 1, "BEITRAG", Map.of("simuliere", "STOERUNG"), Instant.now()));
            kafka.send(dokumente, "V-1001", new Dokumentauftrag("V-1001", "POLICE"));
            kafka.send(dokumente, "V-1002", new Dokumentauftrag("V-1002", "KAPUTT"));
            kafka.flush();
        };
    }
}
