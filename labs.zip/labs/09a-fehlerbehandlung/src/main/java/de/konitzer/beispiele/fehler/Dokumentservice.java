package de.konitzer.beispiele.fehler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.BackOff;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import de.konitzer.beispiele.ereignisse.Dokumentauftrag;

/**
 * Nicht blockierende Wiederholung mit @RetryableTopic: Die fehlerhafte Nachricht wandert nach
 * dokumente.erzeugen-retry-1000, -retry-2000, -retry-4000 (benannt nach der Wartezeit in ms); die Haupt-Partition läuft sofort weiter.
 * Ideal für unabhängige Aufträge – und tabu für Vertragsänderungen, weil die Reihenfolge verloren geht.
 */
@Component
public class Dokumentservice {

    private static final Logger log = LoggerFactory.getLogger(Dokumentservice.class);

    private final Bestand bestand;

    Dokumentservice(Bestand bestand) {
        this.bestand = bestand;
    }

    @RetryableTopic(attempts = "4",
            backOff = @BackOff(delayString = "${app.retry.delay-ms}", multiplier = 2.0),
            replicationFactor = "${app.replikation}")
    @KafkaListener(id = "dokumente", idIsGroup = false, topics = "${app.topic-dokumente}",
            properties = "spring.json.value.default.type=de.konitzer.beispiele.ereignisse.Dokumentauftrag")
    void erzeugeDokument(Dokumentauftrag auftrag, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        int versuch = bestand.naechsterVersuch("DOK-" + auftrag.vertragsnummer(), 0);
        if ("KAPUTT".equals(auftrag.vorlage())) {
            log.warn("Dokument {} für {}: Vorlage kaputt (Versuch {} aus {})", auftrag.vorlage(),
                    auftrag.vertragsnummer(), versuch, topic);
            throw new IllegalStateException("Vorlage kaputt: " + auftrag.vorlage());
        }
        log.info("Dokument {} für {} erzeugt", auftrag.vorlage(), auftrag.vertragsnummer());
    }

    @DltHandler
    void nichtErzeugbar(Dokumentauftrag auftrag, @Header(KafkaHeaders.EXCEPTION_MESSAGE) String grund) {
        log.error("DLT: Dokument {} für {} endgültig nicht erzeugbar: {}", auftrag.vorlage(),
                auftrag.vertragsnummer(), grund);
        bestand.speichere("DLT-" + auftrag.vertragsnummer(), 1);
    }
}
