package de.konitzer.beispiele.fehler;

/** Vorübergehender Fehler (Datenbank, Partnersystem): Wiederholen mit Backoff lohnt sich. */
public class VoruebergehendNichtVerfuegbarException extends RuntimeException {

    public VoruebergehendNichtVerfuegbarException(String system) {
        super(system + " vorübergehend nicht erreichbar");
    }
}
