package de.konitzer.beispiele.einfach;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;

/**
 * Eine Instanz mit drei Threads bekommt alle drei Partitionen; sechs Nachrichten mit drei Keys
 * verteilen sich auf die Partitionen, jede wird genau einmal gezählt.
 */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}", "app.threads=3"})
@EmbeddedKafka(partitions = 3, topics = "beitraege")
class ConsumerGroupsIT {

    @Autowired EmbeddedKafkaBroker broker;
    @Autowired Beitragsverarbeitung verarbeitung;

    @Test
    void dreiThreadsTeilenSichDreiPartitionen() {
        await().atMost(Duration.ofSeconds(30)).untilAsserted(() ->
                assertThat(verarbeitung.zugewiesen()).hasSize(3));

        var props = KafkaTestUtils.producerProps(broker);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        try (var producer = new KafkaProducer<String, String>(props)) {
            for (int i = 1; i <= 6; i++) {
                producer.send(new ProducerRecord<>("beitraege", "V-100" + (i % 3), "Beitrag " + i));
            }
            producer.flush();
        }

        await().atMost(Duration.ofSeconds(10)).untilAsserted(() ->
                assertThat(verarbeitung.zaehler().values().stream().mapToInt(Integer::intValue).sum()).isEqualTo(6));
    }
}
