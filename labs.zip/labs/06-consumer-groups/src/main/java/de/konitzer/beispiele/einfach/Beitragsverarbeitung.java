package de.konitzer.beispiele.einfach;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * Der Listener aus 05, erweitert um alles, was eine Consumer Group sichtbar macht:
 *  - Welche Partitionen bekomme ich? (onPartitionsAssigned / onPartitionsRevoked)
 *  - Wann ist eine Nachricht "erledigt"? (manuelles Acknowledgment)
 *  - Wie lese ich alles noch einmal? (seekToBeginning)
 *
 * ConsumerSeekAware ist eine Schnittstelle von Spring Kafka: Der Container ruft ihre Methoden
 * beim Rebalance auf und gibt uns einen "Callback", mit dem wir die Leseposition setzen können.
 */
@Component
public class Beitragsverarbeitung implements ConsumerSeekAware {

    private static final Logger log = LoggerFactory.getLogger(Beitragsverarbeitung.class);

    private final long dauerMs;
    private final boolean vonAnfang;
    // Zähler je Partition: wie viele Nachrichten diese Instanz daraus verarbeitet hat
    private final Map<Integer, Integer> zaehler = new ConcurrentHashMap<>();
    // Aktuell zugewiesene Partitionen (für Tests und die Konsolenausgabe)
    private final Set<TopicPartition> zugewiesen = ConcurrentHashMap.newKeySet();

    // Konstruktor-Injektion: Spring reicht die beiden Einstellungen beim Anlegen herein
    public Beitragsverarbeitung(@Value("${app.dauer-ms}") long dauerMs,
                                @Value("${app.von-anfang}") boolean vonAnfang) {
        this.dauerMs = dauerMs;
        this.vonAnfang = vonAnfang;
    }

    /**
     * Wie in 05, zwei Unterschiede:
     *  - groupId überschreibt hier nichts, die Gruppe kommt aus den Properties (app.gruppe)
     *  - Acknowledgment: Mit ack-mode=manual_immediate committet Spring erst, wenn wir
     *    acknowledge() rufen. Vergisst man es, wird nie committet – nach dem Neustart kommt alles wieder.
     */
    @KafkaListener(id = "beitraege", idIsGroup = false, topics = "${app.topic}")
    public void verarbeite(ConsumerRecord<String, String> nachricht, Acknowledgment ack) throws InterruptedException {
        if (dauerMs > 0) {
            Thread.sleep(dauerMs);   // simulierte Arbeit – so entsteht Lag
        }
        int anzahl = zaehler.merge(nachricht.partition(), 1, Integer::sum);
        log.info("P{} @{} key={} {}   (Nr. {} aus dieser Partition)",
                nachricht.partition(), nachricht.offset(), nachricht.key(), nachricht.value(), anzahl);
        ack.acknowledge();   // "erledigt" – jetzt wird der Offset committet
    }

    /**
     * Rebalance: Der Gruppen-Koordinator hat dieser Instanz Partitionen gegeben.
     * assignments enthält je Partition den Offset, ab dem gelesen wird (der committete Stand).
     * Mit dem Callback können wir das ändern – hier: --app.von-anfang=true springt auf Offset 0.
     * Shell-Entsprechung: 01-shell/07-offsets-zuruecksetzen.sh (geht dort nur bei gestoppter Gruppe).
     */
    @Override
    public void onPartitionsAssigned(Map<TopicPartition, Long> assignments, ConsumerSeekCallback callback) {
        zugewiesen.addAll(assignments.keySet());
        log.info("ZUGEWIESEN: {}", assignments);
        if (vonAnfang) {
            callback.seekToBeginning(assignments.keySet());
            log.info("von Anfang: Leseposition auf 0 gesetzt");
        }
    }

    /** Rebalance: Partitionen gehen an eine andere Instanz (z. B. weil ein zweites Fenster gestartet wurde). */
    @Override
    public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
        zugewiesen.removeAll(partitions);
        log.info("ABGEGEBEN: {}", partitions);
    }

    public Set<TopicPartition> zugewiesen() {
        return zugewiesen;
    }

    public Map<Integer, Integer> zaehler() {
        return zaehler;
    }
}
