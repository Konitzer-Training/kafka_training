package de.konitzer.beispiele.einfach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Startklasse für die Consumer-Group-Vorführung.
 *
 * Starten (mehrere Fenster, gleiche Gruppe):
 *   java -jar target/06-consumer-groups-app.jar
 *   java -jar target/06-consumer-groups-app.jar
 * Andere Gruppe:            --app.gruppe=statistik
 * Drei Threads in einer JVM: --app.threads=3
 * Langsam verarbeiten:      --app.dauer-ms=2000   (Lag beobachten mit 01-shell/06-gruppe-ansehen)
 * Alles noch einmal lesen:  --app.von-anfang=true
 */
@SpringBootApplication
public class ConsumerApp {

    public static void main(String[] args) {
        SpringApplication.run(ConsumerApp.class, args);
    }
}
