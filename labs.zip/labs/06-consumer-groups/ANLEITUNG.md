# 06-consumer-groups – Arbeitsanweisung

**Was es zeigt:** Was in Kapitel 6 mit `kafka-consumer-groups.sh` von außen sichtbar war, jetzt aus der Anwendung heraus: Zuweisung und Rebalance, manuelles Commit, Lag, Offset-Reset per `seekToBeginning`.

**Buch:** Kapitel 6 (Consumer Groups und Offsets), Kapitel 8 (Acknowledgment).

## Vorführung (10 Minuten, drei Fenster)

Vorher: Topic gefüllt, zum Beispiel mit `04-producer-spring` ohne Argumente (fünf Nachrichten).

1. **Fenster 1:** Consumer starten.
   ```powershell
   java -jar 06-consumer-groups\target\06-consumer-groups-app.jar
   ```
   Zu sehen: `ZUGEWIESEN: {beitraege-0=…, beitraege-1=…, beitraege-2=…}`, dann die Nachrichten.
2. **Fenster 2:** Zweiten Consumer derselben Gruppe starten (gleicher Befehl).
   Zu sehen in Fenster 1: `ABGEGEBEN: [beitraege-…]`, in Fenster 2: `ZUGEWIESEN` mit den abgegebenen Partitionen. Das ist der Rebalance, mit dem neuen Protokoll ohne Stillstand der übrigen Partitionen.
3. **Fenster 3:** Nachrichten senden: `04-producer-spring` ohne Argumente. Jede landet in genau einem der beiden Fenster, abhängig vom Key.
4. Fenster 2 mit Strg+C beenden: Fenster 1 bekommt die Partitionen zurück.
5. **Lag sehen:** Fenster 1 beenden und mit `--app.dauer-ms=2000` neu starten. In Fenster 3 zehn Nachrichten senden, dann:
   ```powershell
   01-shell\06-gruppe-ansehen.ps1 -Gruppe beitragsrechner
   ```
   `LAG` ist größer als 0 und sinkt alle zwei Sekunden um 1.
6. **Alles noch einmal:** Fenster 1 beenden, mit `--app.von-anfang=true` starten. Alle Nachrichten kommen erneut, der Zähler je Partition beginnt bei 1.
7. **Zweite Gruppe:** `--app.gruppe=statistik` in einem weiteren Fenster: bekommt alle Partitionen und alle Nachrichten, unabhängig von `beitragsrechner`.

## Was im Code zu sehen ist

| Im Code | Shell-Entsprechung |
| --- | --- |
| `onPartitionsAssigned` / `onPartitionsRevoked` | `kafka-consumer-groups.sh --describe --members` |
| `ack.acknowledge()` | automatischer Commit alle 5 s im Console Consumer |
| `callback.seekToBeginning(...)` | `07-offsets-zuruecksetzen … ausfuehren` (dort nur bei gestoppter Gruppe) |
| `--app.threads=3` | drei Fenster mit `05-consumer-gruppe` |
| `--app.gruppe=statistik` | `05-consumer-gruppe -Gruppe statistik` |

## Aufgaben

1. Starten Sie `--app.threads=3` in **einem** Fenster. Wie viele `[Thread]`-Namen sehen Sie in den Logzeilen? Welche Partition gehört zu welchem Thread?
2. Starten Sie vier Instanzen derselben Gruppe. Was bekommt die vierte? Warum ist das kein Fehler?
3. Kommentieren Sie `ack.acknowledge()` aus, bauen Sie neu, starten Sie, beenden Sie, starten Sie noch einmal. Erklären Sie mit `06-gruppe-ansehen`, was passiert ist.
4. Lassen Sie in `verarbeite` jede Nachricht mit `Beitrag 99,00` eine Exception werfen, **vor** `acknowledge()`. Was macht Spring mit dem Offset? Beobachten Sie `06-gruppe-ansehen`.

## Ändern und bauen

- **IntelliJ:** `06-consumer-groups → ConsumerApp → main`. Mehrere Instanzen: `Run → Edit Configurations → Modify options → Allow multiple instances`.
- **Nur dieses Modul bauen:**
  ```powershell
  .\mvnw.cmd -pl 06-consumer-groups -am package -DskipTests
  ```
- **Mit Test** (EmbeddedKafka):
  ```powershell
  .\mvnw.cmd -pl 06-consumer-groups -am verify
  ```
- Alle Vorführ-Schalter (`app.threads`, `app.dauer-ms`, `app.von-anfang`, `app.gruppe`) sind Properties: auf der Kommandozeile mit `--` überschreiben, kein Build nötig.
