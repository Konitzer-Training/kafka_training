# labs – Lab-Umgebung und alle Beispiele zum Seminar und zum Buch

Im Ordner `kafka-lab` liegt die Docker-Umgebung (drei Broker, Kafbat UI, Prometheus, Alertmanager, Grafana, optional DR-Standort mit MirrorMaker 2; README dort). Alles andere ist ein Maven-Projekt, ein Modul je Thema, von den Shell-Skripten des ersten Tages bis zur Fallstudie. Jedes Modul hat eine `ANLEITUNG.md` mit Ablauf, Aufgaben und dem Weg zum Ändern und Bauen. Alle Beispiele laufen gegen den Lab-Cluster (`localhost:19092,19093,19094`), die Tests laufen ohne Lab.

Spring Boot 4.1.2, Spring Kafka 4.1.2, Kafka-Client 4.2, Jackson 3, Java 17 (läuft mit JDK 17 bis 25). Die Module 02 und 03 kommen ohne Spring aus.

Die früheren Ordner `kafka-einfach` und `bestand-demo` sind hier aufgegangen (04/06, 11a, 18) und werden nicht mehr gepflegt.

## Stufe 0: Von der Shell zu Java (Tag 1, Kapitel 3 bis 6)

Sprechertext für diesen Block: `SPRECHERTEXT.md` (Foliensatz 09 „Kafka in Spring Boot“).

| Modul | Kapitel | Zeigt | Tests |
| --- | --- | --- | --- |
| `01-shell` | 3–6 | Die Befehle von Tag 1 als Skripte (`.ps1` und `.sh`) mit Erklärungen: Topic, Producer, Consumer, Gruppe, Lag, Offset-Reset, Share Group | – |
| `02-producer-plain` | 3, 4 | Der Console Producer in Java, nur `kafka-clients`: Properties, `KafkaProducer`, `send` mit Callback | Testcontainers: gleicher Key → gleiche Partition |
| `03-consumer-plain` | 3, 6 | Der Console Consumer in Java: subscribe, poll, commitSync, Wakeup beim Beenden | Testcontainers: liest alles, committet |
| `04-producer-spring` | 4, 5, 7 | Dasselbe mit Spring Boot: `application.properties`, `KafkaTemplate`, `NewTopic`; Betriebsarten Argumente, Eingabe, Automatik | EmbeddedKafka |
| `05-consumer-spring` | 6, 8 | `@KafkaListener` statt Schleife, `ack-mode=record` | EmbeddedKafka |
| `06-consumer-groups` | 6 | `ConsumerSeekAware` (ZUGEWIESEN/ABGEGEBEN), `Acknowledgment`, `seekToBeginning`, Threads, Lag | EmbeddedKafka: 3 Threads, 3 Partitionen |

## Stufe 2: Spring Boot für Produktion (Tag 2, Kapitel 7 bis 16)

| Modul | Kapitel | Zeigt | Tests |
| --- | --- | --- | --- |
| `ereignisse` | 7 | Die Records `Vertragsaenderung`, `Schadenmeldung`, `Reserve`, `Dokumentauftrag` – der Vertrag zwischen Producer und Consumer | – |
| `07-producer-json` | 7 | `JacksonJsonSerializer`, Ergebnis von `send()` auswerten, synchron senden, Header, `ProducerListener` | Testcontainers: Drahtformat, Header, Partition; Broker nicht erreichbar |
| `08-consumer-json` | 8 | `ErrorHandlingDeserializer` + `JacksonJsonDeserializer`, `@Payload`/`@Header`, idempotente `Verbuchung`, `pause()`/`resume()` | siehe `13-tests` |
| `09a-fehlerbehandlung` | 9 | `DefaultErrorHandler` mit `ExponentialBackOff`, Recoverer **anhalten** oder **DLT**, `@RetryableTopic` + `@DltHandler` | EmbeddedKafka, 4 Tests |
| `09b-outbox` | 9 | Transactional Outbox mit JPA/H2 und Polling-Relay | EmbeddedKafka, 2 Tests |
| `09c-transaktionen` | 9 | Kafka-Transaktion lesen → verarbeiten → schreiben, `read_committed`, `AfterRollbackProcessor` | EmbeddedKafka |
| `11a-join-einfach` | 11 | Einstieg Kafka Streams: Antrag + Prüfung → Police (Stream-Stream-Join), die Mitmach-Vorführung aus Deck 07 | TopologyTestDriver |
| `11-streams` | 11 | Vier Topologien: Join, Anreichern (KTable), Zählen, Zeitfenster | TopologyTestDriver, 4 Tests |
| `13-tests` | 13 | Die Testpyramide: Unit, `@EmbeddedKafka`, Testcontainers, `TopologyTestDriver` | 6 Tests gegen 08 und 11 |
| `14-monitoring` | 14 | Kafka-Client-Metriken und eigene Zähler (`Verbuchungsmetriken`) unter `/actuator/prometheus`; Shell-Skripte: Gesundheitscheck, JMX, PromQL, Alerts, Lag erzeugen | EmbeddedKafka + HTTP |
| `15-performance` | 15 | Perf-Test-Skripte aus Tag 2 und ein Lasttest-Producer mit `linger.ms`, `batch.size`, Kompression, `acks` zum Vergleichen | EmbeddedKafka |
| `16-feldverschluesselung` | 16 | Serializer/Deserializer mit AES-GCM für das Feld `iban`, Schlüssel-ID im Header, Crypto-Shredding | ohne Kafka, 3 Tests |

## Werkzeuge

| Ordner | Zweck |
| --- | --- |
| `kafka-lab` | Docker-Compose-Stack für beide Tage, `docker compose up -d` dort; Hilfsskripte `bin/mit-metriken`, `bin/bestandsverwaltung`; Prometheus-Regeln und Grafana-Dashboard |
| `postman` | Die HTTP-Aufrufe des Seminars (Fallstudie, Metrik-Endpunkte, Prometheus-API, Alertmanager) als Postman-Collection plus Umgebung, Anleitung mit Ablauf und Aufgaben |

## Stufe 3: Fallstudie und Betrieb (Kapitel 18 und 19)

| Modul | Kapitel | Zeigt | Tests |
| --- | --- | --- | --- |
| `18-fallstudie` | 18 | Bestandsverwaltung mit Versionen, Steuerung per HTTP (Last, Absturz, Poison Pill), anhalten oder DLT, Metriken für Grafana (früher `bestand-demo`) | EmbeddedKafka + HTTP (Rauchtest) |
| `19-desaster` | 19 | Nur Skripte: DR-Standort und MirrorMaker 2 starten, gespiegelte Topics, übersetzte Offsets, Failover | – |

## Bauen und testen

```bash
./mvnw verify          # macOS/Linux
.\mvnw.cmd verify      # Windows
```

- `*Test.java` läuft ohne Infrastruktur (Surefire). `*IT.java` läuft in `verify` (Failsafe): EmbeddedKafka braucht nichts, Testcontainers (02, 03, 07, 13) braucht ein laufendes Docker.
- Der Lab-Cluster muss für die Tests **nicht** laufen. Für die Konsolen-Demos schon.
- Ausführbare JARs liegen nach dem Build unter `<modul>/target/<modul>-app.jar`.
- Ein Modul allein: `.\mvnw.cmd -pl 05-consumer-spring -am package -DskipTests` (`-am` baut die Abhängigkeiten mit). Details je Modul in der `ANLEITUNG.md`.
- IntelliJ: `File → Open` auf diesen Ordner (Wurzel-POM), dann die `*App`-Klasse des Moduls starten.

Projektaufbau: `pom.xml` (Wurzel: Module, Plugins) → `spring-basis/pom.xml` (gemeinsame Spring-Abhängigkeiten) → die Spring-Module. `02` und `03` hängen direkt an der Wurzel.

## Konsolen-Demos gegen den Lab-Cluster

Vorher `docker compose up -d` im Ordner `labs\kafka-lab`. Die Reihenfolge je Stufe steht in der jeweiligen `ANLEITUNG.md`; die Kette für den Nachmittag von Tag 2 (09a → 09b → 09c) im Fahrplan, Deck 07.

Für einen frischen Lauf: `01-shell/08-topic-loeschen` für `beitraege` und die Topics der Stufe 2 (`bestand.vertragsaenderungen`, `bestand.vertragsaenderungen.fehler*`, `dokumente.erzeugen*`, `schaden.*`, `antraege`, `pruefungen`, `policen`, `kunden.stammdaten`, `perf`, `streams-beispiele-*`, `join-einfach-*`). Die Apps legen ihre Topics beim Start neu an.

## Unterschiede zu Spring Boot 3.x

| Spring Boot 4.1 / Spring Kafka 4.1 | Spring Boot 3.x / Spring Kafka 3.x |
| --- | --- |
| `JacksonJsonSerializer`, `JacksonJsonDeserializer` (Jackson 3, Package `tools.jackson`) | `JsonSerializer`, `JsonDeserializer` (Jackson 2, `com.fasterxml.jackson`) |
| `spring-boot-starter-jackson`, `spring-boot-starter-webmvc` | `spring-boot-starter-json`, `spring-boot-starter-web` |
| `ExponentialBackOff` mit `setMaxAttempts()` (Spring Framework 7) | `ExponentialBackOffWithMaxRetries` |
| `@RetryableTopic(backOff = @BackOff(delayString = …))` aus `org.springframework.kafka.annotation` | `backoff = @Backoff(delayExpression = …)` aus Spring Retry |
| Testcontainers 2: `testcontainers-kafka`, `testcontainers-junit-jupiter` | Testcontainers 1: `kafka`, `junit-jupiter` |
| `org.testcontainers.kafka.KafkaContainer` (Image `apache/kafka`) | `org.testcontainers.containers.KafkaContainer` (Confluent-Image) |
| `TestRestTemplate` in eigenem Modul `spring-boot-resttestclient`; hier stattdessen `RestClient` | `TestRestTemplate` in `spring-boot-starter-test` |

## Was absichtlich fehlt

- **Avro und Schema Registry** – das Lab hat keine Registry; Kapitel 10 beschreibt es im Text.
- **Apache Camel** – ein zweites Framework würde vom Kafka-Verhalten ablenken.
- **Debezium als Outbox-Relay** – Kapitel 12 beschreibt es; das Polling-Relay in `09b-outbox` zeigt das Prinzip.
- **Java für Desaster Recovery** – Failover ist Betrieb; `19-desaster` zeigt ihn mit den Werkzeugen.
