package de.konitzer.beispiele.producer;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Integrationstest gegen das echte Broker-Image. Prüft das Drahtformat: Was liegt
 * wirklich im Topic? Ein Consumer in einer anderen Sprache müsste damit zurechtkommen.
 */
@SpringBootTest(properties = {"app.demo=false", "app.replikation=1"})
@Testcontainers
class BestandssystemIT {

    @Container
    @ServiceConnection
    static KafkaContainer kafka = new KafkaContainer("apache/kafka:4.4.0");

    @Autowired
    Bestandssystem bestandssystem;

    @Test
    void schreibtJsonOhneTypHeader() throws Exception {
        var meta = bestandssystem.veroeffentlicheSynchron(new Vertragsaenderung("V-1001", 1, "ADRESSE",
                Map.of("plz", "50667"), Instant.parse("2026-11-03T09:00:00Z"))).getRecordMetadata();

        ConsumerRecord<String, String> gelesen = leseEine(meta.topic(), meta.partition(), meta.offset());

        assertThat(gelesen.key()).isEqualTo("V-1001");
        assertThat(gelesen.value())
                .contains("\"vertragsnummer\":\"V-1001\"")
                .contains("\"version\":1")
                .contains("\"plz\":\"50667\"")
                .contains("2026-11-03T09:00:00Z");
        // spring.json.add.type.headers=false: kein Java-Klassenname in den Headern
        assertThat(gelesen.headers().lastHeader("__TypeId__")).isNull();
    }

    @Test
    void headerKommenAn() throws Exception {
        var meta = bestandssystem.veroeffentlicheMitHeadern(new Vertragsaenderung("V-1002", 1, "BEITRAG",
                Map.of("beitrag", "49,90"), Instant.now()), "korr-4711").get().getRecordMetadata();

        ConsumerRecord<String, String> gelesen = leseEine(meta.topic(), meta.partition(), meta.offset());

        assertThat(new String(gelesen.headers().lastHeader("quelle").value())).isEqualTo("bestandssystem");
        assertThat(new String(gelesen.headers().lastHeader("korrelations-id").value())).isEqualTo("korr-4711");
    }

    @Test
    void gleicherKeyGleichePartition() throws Exception {
        int erste = bestandssystem.adresseGeaendert("V-2001", 1, "10115").get().getRecordMetadata().partition();
        int zweite = bestandssystem.beitragAngepasst("V-2001", 2, "20,00").get().getRecordMetadata().partition();

        assertThat(zweite).isEqualTo(erste);
    }

    /** Liest genau einen Datensatz roh als Text – ohne Spring, ohne JSON-Deserializer. */
    private static ConsumerRecord<String, String> leseEine(String topic, int partition, long offset) {
        var props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getBootstrapServers());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        try (var consumer = new KafkaConsumer<String, String>(props)) {
            var tp = new org.apache.kafka.common.TopicPartition(topic, partition);
            consumer.assign(List.of(tp));
            consumer.seek(tp, offset);
            var records = consumer.poll(Duration.ofSeconds(10));
            assertThat(records.count()).isGreaterThan(0);
            return records.iterator().next();
        }
    }
}
