package de.konitzer.beispiele.producer;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Instant;
import java.util.Map;

import org.apache.kafka.common.errors.TimeoutException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Producer bei nicht erreichbarem Broker: Der Fehler wird gemeldet, nicht verschluckt.
 *
 * Zwei Wege, auf denen er ankommt:
 *  - send() wirft sofort (KafkaException), wenn der Producer nach max.block.ms keine Metadaten hat
 *  - oder die Zukunft scheitert nach delivery.timeout.ms (ExecutionException)
 * In beiden Fällen ist die Ursache eine TimeoutException. Kurze Timeouts halten den Test schnell;
 * in Produktion bleiben es 60 s (max.block.ms) und 2 min (delivery.timeout.ms).
 */
@SpringBootTest(properties = {
        "app.demo=false",
        "spring.kafka.bootstrap-servers=localhost:1",
        "spring.kafka.producer.properties.delivery.timeout.ms=3000",
        "spring.kafka.producer.properties.request.timeout.ms=1000",
        "spring.kafka.producer.properties.max.block.ms=2000",
        "spring.kafka.admin.fail-fast=false",
        "spring.kafka.admin.auto-create=false"
})
class BrokerNichtErreichbarIT {

    @Autowired
    Bestandssystem bestandssystem;

    @Test
    void sendenMeldetFehlerStattZuSchweigen() {
        assertThatThrownBy(() -> bestandssystem.veroeffentliche(
                new Vertragsaenderung("V-1001", 1, "ADRESSE", Map.of("plz", "50667"), Instant.now())).get())
                .hasRootCauseInstanceOf(TimeoutException.class);
    }
}
