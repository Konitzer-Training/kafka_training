package de.konitzer.beispiele.producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kapitel 7: Das Bestandssystem veröffentlicht Vertragsänderungen als JSON.
 *
 * Start: java -jar 07-producer-json.jar
 * Die Demo sendet einige Änderungen, zeigt Partition und Offset und beendet sich.
 */
@SpringBootApplication
public class ProducerApp {

    public static void main(String[] args) {
        SpringApplication.run(ProducerApp.class, args);
    }
}
