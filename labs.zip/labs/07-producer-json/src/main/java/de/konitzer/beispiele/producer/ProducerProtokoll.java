package de.konitzer.beispiele.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.support.ProducerListener;

/**
 * Ein ProducerListener sieht jedes Ergebnis aller Sendevorgänge des KafkaTemplate –
 * eine Stelle für Protokoll und Metriken, unabhängig davon, ob der Aufrufer das Ergebnis auswertet.
 */
@Configuration
class ProducerProtokoll {

    private static final Logger log = LoggerFactory.getLogger(ProducerProtokoll.class);

    @Bean
    ProducerListener<Object, Object> producerListener() {
        return new ProducerListener<>() {
            @Override
            public void onError(ProducerRecord<Object, Object> nachricht, RecordMetadata meta, Exception fehler) {
                log.error("Senden fehlgeschlagen: Topic {}, Key {}: {}", nachricht.topic(), nachricht.key(),
                        fehler.getMessage());
            }
        };
    }
}
