package de.konitzer.beispiele.producer;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Konsolen-Demo: drei Verträge, je zwei Änderungen. Zu sehen ist, dass alle Änderungen
 * eines Vertrags in derselben Partition landen und ihre Offsets dort aufsteigen.
 */
@Configuration
@ConditionalOnProperty(name = "app.demo", havingValue = "true", matchIfMissing = true)
class Demo {

    @Bean
    CommandLineRunner demoLauf(Bestandssystem bestandssystem) {
        return args -> {
            System.out.println();
            System.out.println("Demo: 3 Verträge, je 2 Änderungen, dann eine mit Headern und eine synchron.");
            System.out.println();
            for (String vertrag : new String[] {"V-1001", "V-1002", "V-1003"}) {
                bestandssystem.adresseGeaendert(vertrag, 1, "50667");
                bestandssystem.beitragAngepasst(vertrag, 2, "49,90");
            }
            bestandssystem.veroeffentlicheMitHeadern(
                    new Vertragsaenderung("V-1001", 3, "BANKVERBINDUNG", Map.of("iban", "DE02…"), Instant.now()),
                    UUID.randomUUID().toString());
            var meta = bestandssystem.veroeffentlicheSynchron(
                    new Vertragsaenderung("V-1001", 4, "KUENDIGUNG", Map.of("zum", "2027-01-01"), Instant.now()))
                    .getRecordMetadata();
            System.out.printf("%nsynchron bestätigt: V-1001 v4 -> Partition %d, Offset %d%n", meta.partition(), meta.offset());
            bestandssystem.flush();
            System.out.println("Demo beendet. Nachlesen: kafka-console-consumer.sh --topic bestand.vertragsaenderungen"
                    + " --from-beginning --formatter-property print.key=true --formatter-property print.partition=true");
        };
    }
}
