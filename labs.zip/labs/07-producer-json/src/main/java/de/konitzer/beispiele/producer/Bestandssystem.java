package de.konitzer.beispiele.producer;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;

/**
 * Das Bestandssystem als Producer.
 *
 * Key = Vertragsnummer: Alle Änderungen eines Vertrags landen in derselben Partition
 * und bleiben dort in Reihenfolge. Der Wert ist das Record als JSON.
 */
@Service
public class Bestandssystem {

    private static final Logger log = LoggerFactory.getLogger(Bestandssystem.class);

    private final KafkaTemplate<String, Vertragsaenderung> kafka;
    private final String topic;

    Bestandssystem(KafkaTemplate<String, Vertragsaenderung> kafka, @Value("${app.topic}") String topic) {
        this.kafka = kafka;
        this.topic = topic;
    }

    /**
     * Senden ist asynchron: send() kehrt sofort zurück. Ob die Nachricht angekommen ist,
     * steht erst im Ergebnis – deshalb wird es immer ausgewertet. Ohne diese Auswertung
     * gingen Fehler (z. B. NOT_ENOUGH_REPLICAS nach delivery.timeout.ms) still verloren.
     */
    public CompletableFuture<SendResult<String, Vertragsaenderung>> veroeffentliche(Vertragsaenderung aenderung) {
        return kafka.send(topic, aenderung.vertragsnummer(), aenderung)
                .whenComplete((ergebnis, fehler) -> {
                    if (fehler != null) {
                        log.error("Vertrag {} v{} nicht veröffentlicht: {}", aenderung.vertragsnummer(),
                                aenderung.version(), ursache(fehler));
                        // hier entscheiden: erneut einplanen, Fehlertabelle, Alarm
                        return;
                    }
                    var meta = ergebnis.getRecordMetadata();
                    log.info("Vertrag {} v{} {} -> Partition {}, Offset {}", aenderung.vertragsnummer(),
                            aenderung.version(), aenderung.art(), meta.partition(), meta.offset());
                });
    }

    public CompletableFuture<SendResult<String, Vertragsaenderung>> adresseGeaendert(String vertrag, int version, String plz) {
        return veroeffentliche(new Vertragsaenderung(vertrag, version, "ADRESSE", Map.of("plz", plz), Instant.now()));
    }

    public CompletableFuture<SendResult<String, Vertragsaenderung>> beitragAngepasst(String vertrag, int version, String beitrag) {
        return veroeffentliche(new Vertragsaenderung(vertrag, version, "BEITRAG", Map.of("beitrag", beitrag), Instant.now()));
    }

    /**
     * Synchron senden: wenn das Ergebnis feststehen muss, bevor es weitergeht
     * (z. B. bevor eine Datenbank-Transaktion committet wird). Kostet Durchsatz.
     */
    public SendResult<String, Vertragsaenderung> veroeffentlicheSynchron(Vertragsaenderung aenderung)
            throws InterruptedException, ExecutionException, TimeoutException {
        return veroeffentliche(aenderung).get(10, TimeUnit.SECONDS);
    }

    /**
     * Header tragen Metadaten, die nicht in die Nutzdaten gehören: Herkunft, Korrelations-ID,
     * Schema-Version. Consumer in jeder Sprache können sie lesen, ohne das JSON zu parsen.
     */
    public CompletableFuture<SendResult<String, Vertragsaenderung>> veroeffentlicheMitHeadern(
            Vertragsaenderung aenderung, String korrelationsId) {
        var nachricht = new ProducerRecord<>(topic, aenderung.vertragsnummer(), aenderung);
        nachricht.headers().add("quelle", "bestandssystem".getBytes(StandardCharsets.UTF_8));
        nachricht.headers().add("korrelations-id", korrelationsId.getBytes(StandardCharsets.UTF_8));
        return kafka.send(nachricht);
    }

    /** Auf die Bestätigung aller noch gepufferten Nachrichten warten – vor dem Beenden. */
    public void flush() {
        kafka.flush();
    }

    static String ursache(Throwable fehler) {
        Throwable t = fehler;
        while (t.getCause() != null) {
            t = t.getCause();
        }
        return t.getClass().getSimpleName() + ": " + t.getMessage();
    }
}
