package de.konitzer.beispiele.producer;

import java.time.Duration;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

/**
 * Topics als Code: Spring legt das Topic beim Start an, falls es fehlt.
 * Bestehende Topics werden nicht verändert (Partitionen werden nie verringert).
 */
@Configuration
class KafkaTopics {

    @Bean
    NewTopic vertragsaenderungen(@Value("${app.topic}") String topic,
                                 @Value("${app.replikation}") int replikation) {
        return TopicBuilder.name(topic)
                .partitions(6)
                .replicas(replikation)
                .config("min.insync.replicas", "2")
                .config("retention.ms", String.valueOf(Duration.ofDays(14).toMillis()))
                .build();
    }
}
