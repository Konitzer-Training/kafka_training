package de.konitzer.beispiele.outbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Kapitel 9: Das Outbox-Muster. Das Bestandssystem ändert den Vertrag in seiner Datenbank (H2)
 * und schreibt das Ereignis in derselben Transaktion in die Tabelle outbox. Ein Relay sendet es nach Kafka.
 *
 * Start: java -jar 09b-outbox.jar
 *        java -jar 09b-outbox.jar --app.relay=false   (Relay aus: Einträge bleiben in der Outbox liegen)
 */
@SpringBootApplication
@EnableScheduling
public class OutboxApp {

    public static void main(String[] args) {
        SpringApplication.run(OutboxApp.class, args);
    }
}
