package de.konitzer.beispiele.outbox;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Das Relay: liest ungesendete Einträge, sendet sie nach Kafka, markiert sie.
 *
 * At-least-once: Stürzt die Anwendung nach dem Senden und vor dem Markieren ab, wird der Eintrag
 * noch einmal gesendet. Deshalb trägt jedes Ereignis eine Version, und der Consumer ist idempotent.
 * Läuft das Relay auf mehreren Instanzen, braucht es eine Sperre (SKIP LOCKED, ShedLock) – oder CDC.
 */
@Component
@ConditionalOnProperty(name = "app.relay", havingValue = "true", matchIfMissing = true)
public class OutboxRelay {

    private static final Logger log = LoggerFactory.getLogger(OutboxRelay.class);

    private final OutboxRepository outbox;
    private final KafkaTemplate<String, String> kafka;
    private final String topic;

    OutboxRelay(OutboxRepository outbox, KafkaTemplate<String, String> kafka, @Value("${app.topic}") String topic) {
        this.outbox = outbox;
        this.kafka = kafka;
        this.topic = topic;
    }

    @Scheduled(fixedDelayString = "${app.relay-intervall-ms}")
    public void senden() throws Exception {
        for (OutboxEintrag eintrag : outbox.findTop100ByGesendetAmIsNullOrderByErstelltAm()) {
            var meta = kafka.send(topic, eintrag.getAggregatId(), eintrag.getNutzdaten())
                    // bewusst synchron: erst markieren, wenn Kafka bestätigt hat; Reihenfolge je Vertrag halten
                    .get(10, TimeUnit.SECONDS)
                    .getRecordMetadata();
            eintrag.setGesendetAm(Instant.now());
            outbox.save(eintrag);
            log.info("Outbox -> Kafka: {} {} -> Partition {}, Offset {}", eintrag.getAggregatId(), eintrag.getTyp(),
                    meta.partition(), meta.offset());
        }
    }
}
