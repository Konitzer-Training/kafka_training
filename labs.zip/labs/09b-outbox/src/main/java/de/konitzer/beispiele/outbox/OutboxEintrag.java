package de.konitzer.beispiele.outbox;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Ein Ereignis, das noch nach Kafka muss. Liegt in derselben Datenbank wie der Vertrag,
 * wird in derselben Transaktion geschrieben – ein Commit für beides oder für keins.
 */
@Entity
@Table(name = "outbox")
public class OutboxEintrag {

    @Id
    private UUID id;
    /** Vertragsnummer = späterer Kafka-Key */
    @Column(name = "aggregat_id", nullable = false)
    private String aggregatId;
    @Column(nullable = false)
    private String typ;
    /** das Ereignis als JSON */
    @Column(nullable = false, length = 4000)
    private String nutzdaten;
    @Column(name = "erstellt_am", nullable = false)
    private Instant erstelltAm;
    @Column(name = "gesendet_am")
    private Instant gesendetAm;

    protected OutboxEintrag() {
    }

    public OutboxEintrag(String aggregatId, String typ, String nutzdaten) {
        this.id = UUID.randomUUID();
        this.aggregatId = aggregatId;
        this.typ = typ;
        this.nutzdaten = nutzdaten;
        this.erstelltAm = Instant.now();
    }

    public UUID getId() {
        return id;
    }

    public String getAggregatId() {
        return aggregatId;
    }

    public String getTyp() {
        return typ;
    }

    public String getNutzdaten() {
        return nutzdaten;
    }

    public Instant getErstelltAm() {
        return erstelltAm;
    }

    public Instant getGesendetAm() {
        return gesendetAm;
    }

    public void setGesendetAm(Instant gesendetAm) {
        this.gesendetAm = gesendetAm;
    }
}
