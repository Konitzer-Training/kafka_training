package de.konitzer.beispiele.outbox;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Der Vertrag in der Datenbank des Bestandssystems. Die Version zählt jede Änderung. */
@Entity
@Table(name = "vertrag")
public class Vertrag {

    @Id
    private String vertragsnummer;
    private String plz;
    private int version;

    protected Vertrag() {
    }

    public Vertrag(String vertragsnummer, String plz) {
        this.vertragsnummer = vertragsnummer;
        this.plz = plz;
    }

    public String getVertragsnummer() {
        return vertragsnummer;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }

    public int getVersion() {
        return version;
    }

    public void erhoeheVersion() {
        version++;
    }
}
