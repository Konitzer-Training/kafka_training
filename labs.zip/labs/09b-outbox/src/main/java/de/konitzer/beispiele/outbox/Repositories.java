package de.konitzer.beispiele.outbox;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

interface VertragRepository extends JpaRepository<Vertrag, String> {
}

interface OutboxRepository extends JpaRepository<OutboxEintrag, UUID> {

    /** die ältesten ungesendeten zuerst – so bleibt die Reihenfolge je Vertrag erhalten */
    List<OutboxEintrag> findTop100ByGesendetAmIsNullOrderByErstelltAm();

    long countByGesendetAmIsNull();
}
