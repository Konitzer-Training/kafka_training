package de.konitzer.beispiele.outbox;

import java.time.Instant;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.konitzer.beispiele.ereignisse.Vertragsaenderung;
import tools.jackson.databind.json.JsonMapper;

/**
 * Die fachliche Änderung und der Outbox-Eintrag in EINER Datenbank-Transaktion.
 * Kafka kommt hier nicht vor – das übernimmt das Relay.
 */
@Service
public class Bestandssystem {

    private final VertragRepository vertraege;
    private final OutboxRepository outbox;
    private final JsonMapper json;

    Bestandssystem(VertragRepository vertraege, OutboxRepository outbox, JsonMapper json) {
        this.vertraege = vertraege;
        this.outbox = outbox;
        this.json = json;
    }

    @Transactional
    public int adresseAendern(String vertragsnummer, String neuePlz) {
        Vertrag vertrag = vertraege.findById(vertragsnummer).orElseGet(() -> new Vertrag(vertragsnummer, null));
        vertrag.setPlz(neuePlz);
        vertrag.erhoeheVersion();
        vertraege.save(vertrag);

        var ereignis = new Vertragsaenderung(vertragsnummer, vertrag.getVersion(), "ADRESSE",
                Map.of("plz", neuePlz), Instant.now());
        outbox.save(new OutboxEintrag(vertragsnummer, "ADRESSE", json.writeValueAsString(ereignis)));

        if ("00000".equals(neuePlz)) {
            // simulierter Fehler nach dem Speichern: Rollback nimmt Vertrag UND Outbox-Eintrag zurück
            throw new IllegalArgumentException("PLZ ungültig: " + neuePlz);
        }
        return vertrag.getVersion();
    }   // ein Commit: Vertrag und Outbox-Eintrag – oder keins von beiden
}
