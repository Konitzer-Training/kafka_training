package de.konitzer.beispiele.outbox;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Konsolen-Demo: zwei Änderungen, eine ungültige (Rollback), dann der Stand der Outbox. */
@Configuration
@ConditionalOnProperty(name = "app.demo", havingValue = "true", matchIfMissing = true)
class Demo {

    @Bean
    CommandLineRunner demoLauf(Bestandssystem bestandssystem, OutboxRepository outbox, VertragRepository vertraege) {
        return args -> {
            System.out.println();
            System.out.println("Demo Outbox. Beenden mit Strg+C.");
            System.out.printf("V-1001: Adresse -> 50667, Version %d%n", bestandssystem.adresseAendern("V-1001", "50667"));
            System.out.printf("V-1001: Adresse -> 10115, Version %d%n", bestandssystem.adresseAendern("V-1001", "10115"));
            try {
                bestandssystem.adresseAendern("V-1002", "00000");
            } catch (IllegalArgumentException e) {
                System.out.println("V-1002: " + e.getMessage() + " -> Rollback, kein Vertrag, kein Outbox-Eintrag");
            }
            System.out.printf("Verträge in der Datenbank: %d, Outbox-Einträge: %d (davon ungesendet: %d)%n",
                    vertraege.count(), outbox.count(), outbox.countByGesendetAmIsNull());
            System.out.println("Das Relay sendet alle " + "0,5 s" + " – siehe Log-Zeilen \"Outbox -> Kafka\".");
        };
    }
}
