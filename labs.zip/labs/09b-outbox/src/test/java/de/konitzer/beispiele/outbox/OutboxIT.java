package de.konitzer.beispiele.outbox;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;

import java.time.Duration;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;

/** Datenbank und Kafka hängen zusammen: Was committet ist, kommt an; was zurückgerollt ist, nie. */
@SpringBootTest(properties = {
        "spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "app.demo=false", "app.relay-intervall-ms=100"
})
@EmbeddedKafka(partitions = 3, topics = "bestand.vertragsaenderungen")
class OutboxIT {

    @Autowired Bestandssystem bestandssystem;
    @Autowired OutboxRepository outbox;
    @Autowired VertragRepository vertraege;
    @Autowired EmbeddedKafkaBroker broker;
    @Value("${app.topic}") String topic;

    @Test
    void aenderungKommtUeberDieOutboxInKafkaAn() {
        int version = bestandssystem.adresseAendern("V-1001", "50667");

        assertThat(version).isEqualTo(1);
        assertThat(vertraege.findById("V-1001")).get().extracting(Vertrag::getPlz).isEqualTo("50667");

        var props = KafkaTestUtils.consumerProps(broker, "test", false);
        // KafkaTestUtils nimmt Integer-Keys an – wir haben Text
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        try (var consumer = new KafkaConsumer<String, String>(props)) {
            broker.consumeFromAnEmbeddedTopic(consumer, topic);
            var record = KafkaTestUtils.getSingleRecord(consumer, topic, Duration.ofSeconds(10));
            assertThat(record.key()).isEqualTo("V-1001");
            assertThat(record.value()).contains("\"version\":1").contains("\"plz\":\"50667\"");
        }
        await().atMost(Duration.ofSeconds(5)).untilAsserted(() ->
                assertThat(outbox.countByGesendetAmIsNull()).isZero());
    }

    @Test
    void rollbackNimmtVertragUndOutboxEintragZurueck() {
        assertThatThrownBy(() -> bestandssystem.adresseAendern("V-1002", "00000"))
                .isInstanceOf(IllegalArgumentException.class);

        assertThat(vertraege.findById("V-1002")).isEmpty();
        assertThat(outbox.findAll()).noneMatch(e -> e.getAggregatId().equals("V-1002"));
    }
}
